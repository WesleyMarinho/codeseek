( function () {
	// Add an observer to monitor changes in the DOM
	const observer = new MutationObserver( mutations => {
		mutations.forEach( mutation => {
			// Check if #edd-batch-success has been added
			if ( mutation.addedNodes.length > 0 ) {
				const successElement = document.getElementById( 'edd-batch-success' );
				if ( successElement ) {
					// Show .edd-upgrade__action elements
					const upgradeActions = document.querySelectorAll( '.edd-upgrade__action' );
					upgradeActions.forEach( action => {
						action.style.display = 'block'; // Or any other desired display value
					} );

					// Disable #recurring-submit
					const recurringSubmit = document.querySelector( '.edd-migration.allowed input[type="submit"]' );
					if ( recurringSubmit ) {
						recurringSubmit.disabled = true;
					}

					observer.disconnect();
				}
			}
		} );
	} );

	// Start observing the document body for changes
	const targetNode = document.body;
	const config = { childList: true, subtree: true }; // Observe direct children and descendants
	observer.observe( targetNode, config );
} )();
