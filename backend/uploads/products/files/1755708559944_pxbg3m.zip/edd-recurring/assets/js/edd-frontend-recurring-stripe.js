/* global eddStripe, edd_stripe_vars, wp */

const eddStripe = window.eddStripe;
const api = eddStripe._plugin;

/**
 * DOM ready.
 */
document.addEventListener( 'DOMContentLoaded', function () {
	const updatePaymentMethodForm = document.getElementById( 'edd-recurring-form' );
	const updatePaymentMethodFormSubmit = document.getElementById( 'edd-recurring-update-submit' );

	if ( ! updatePaymentMethodForm ) {
		return;
	}

	setupPaymentMethods();
	setupPaymentForm();

	updatePaymentMethodForm.addEventListener( 'submit', onUpdatePaymentMethod );

	/**
	 * Sets up payment method selectors.
	 */
	function setupPaymentMethods () {
		api.paymentMethods();

		// Attempt to select the method used.
		const defaultPaymentMethod = document.getElementById( 'edd_recurring_stripe_default_payment_method' ).value;
		const defaultPaymentMethodOption = document.getElementById( defaultPaymentMethod );

		if ( ! defaultPaymentMethodOption ) {
			return;
		}

		const paymentMethodChangeEvent = new Event( 'change', { bubbles: true, cancelable: false } );
		defaultPaymentMethodOption.dispatchEvent( paymentMethodChangeEvent );

		defaultPaymentMethodOption.checked = true;
	};

	/**
	 * Enables form.
	 */
	function setupPaymentForm () {
		eddStripe.cardElement = api.mountCardElement(
			eddStripe.elements(),
			'#edd-recurring-form #edd-stripe-card-element'
		);
	};

	/**
	 * Disables form.
	 */
	function disableForm () {
		updatePaymentMethodFormSubmit.disabled = true;
		const loading = document.createElement( 'span' );
		loading.classList.add( 'edd-loading-ajax', 'edd-loading' );
		updatePaymentMethodForm.appendChild( loading );
	}

	/**
	 * Enables form.
	 */
	function enableForm () {
		updatePaymentMethodFormSubmit.disabled = false;
		updatePaymentMethodForm.removeChild( updatePaymentMethodForm.querySelector( '.edd-loading-ajax' ) );
	}

	/**
	 * Shows exceptions.
	 */
	function handleException ( error ) {
		// Reenable form.
		enableForm();
		updatePaymentMethodForm.addEventListener( 'submit', onUpdatePaymentMethod );

		const notice = api.generateNotice( ( error && error.message ) ? error.message : edd_stripe_vars.generic_error );

		// Hide previous messages.
		document.querySelectorAll( '.edd-stripe-alert' ).forEach( function ( el ) {
			el.remove();
		} );

		updatePaymentMethodForm.appendChild( notice );
	}

	/**
	 * Attaches a PaymentMethod to a Subscription.
	 *
	 * @param {String} subscriptionId \Stripe\Subscription ID.
	 * @param {String} paymentMethodId \Stripe\PaymentMethod ID.
	 * @return {Promise} jQuery Promise.
	 */
	function updateSubscriptionPaymentMethod ( subscriptionId, paymentMethod, billingAddress ) {
		const requestData = {
			subscription_id: subscriptionId,
			payment_method_id: paymentMethod.id,
			payment_method_exists: paymentMethod.exists,
			billing_address: billingAddress,
			nonce: document.getElementById( 'edd_recurring_update_nonce' ).value,
		};

		// Include update token if available (for non-logged-in users)
		const updateTokenElement = document.querySelector( '[name="update_token"]' );
		if ( updateTokenElement && updateTokenElement.value ) {
			requestData.update_token = updateTokenElement.value;
		}

		return api.apiRequest( 'edd_recurring_update_subscription_payment_method', requestData );
	}

	/**
	 * Handles form submission.
	 *
	 * @param {Event} e submit event.
	 */
	async function onUpdatePaymentMethod ( e ) {
		const form = e.target;
		const subscriptionId = eddRecurringStripeVars.subscription_id;

		if ( ! subscriptionId ) {
			return;
		}

		e.preventDefault();
		disableForm();

		// Retrieve the paymentIntentId element once.
		const paymentIntentIdElement = document.querySelector( '[name="edd_recurring_stripe_payment_intent"]' );
		const paymentIntentIdValue = paymentIntentIdElement ? paymentIntentIdElement.value : null;

		try {
			// Retrieve or create a PaymentMethod. Convert jQuery promise to native if necessary.
			const paymentMethod = await Promise.resolve( api.getPaymentMethod( form, eddStripe.cardElement ) );

			// Update an existing Subscription default_payment_method
			// Convert jQuery promise to native.
			const ajaxResponse = await Promise.resolve(
				updateSubscriptionPaymentMethod(
					subscriptionId,
					paymentMethod,
					api.getBillingDetails( form ).address
				)
			);

			// Check if the AJAX response contains a SetupIntent that requires action (e.g. 3DS)
			if (
				ajaxResponse &&
				ajaxResponse.setup_intent &&
				( ajaxResponse.setup_intent.status === 'requires_action' ||
					ajaxResponse.setup_intent.status === 'requires_confirmation' )
			) {
				const setupIntentToHandle = ajaxResponse.setup_intent;
				let siError = null; // Initialize siError

				try {
					const resultFromHandleIntent = await api.handleIntent( setupIntentToHandle );

					// Check the structure of resultFromHandleIntent to determine success/failure
					if ( resultFromHandleIntent && resultFromHandleIntent.error ) {
						// Case 1: The result object has an 'error' property.
						siError = resultFromHandleIntent.error;
					} else if ( resultFromHandleIntent && resultFromHandleIntent.id && resultFromHandleIntent.object === 'setup_intent' ) {
						// Case 2: The result looks like a SetupIntent object.
						if ( resultFromHandleIntent.status !== 'succeeded' ) {
							// It's a SetupIntent, but not in 'succeeded' state. Treat as an error for proceeding.
							const message = ( resultFromHandleIntent.last_setup_error && resultFromHandleIntent.last_setup_error.message )
								? resultFromHandleIntent.last_setup_error.message
								: ( ( typeof edd_stripe_vars !== 'undefined' && edd_stripe_vars.sca_error ) || ( typeof edd_stripe_vars !== 'undefined' && edd_stripe_vars.generic_error ) || 'The payment method setup did not succeed.' );
							siError = { message: message };
						}
						// If resultFromHandleIntent.status IS 'succeeded', siError remains null (this is the success path).
					} else {
						// Case 3: Unexpected result structure from api.handleIntent.
						const message = ( typeof edd_stripe_vars !== 'undefined' && edd_stripe_vars.generic_error ) || 'An unexpected error occurred while setting up the payment method.';
						siError = { message: message };
					}
				} catch ( e ) {
					// Catch if api.handleIntent() itself throws an exception (e.g., network error).
					siError = e; // e might already be an error object with a message.
				}

				if ( siError ) {
					// If SetupIntent failed and we have an original payment method ID, attempt to revert.
					if ( ajaxResponse.original_payment_method_id ) {
						try {
							await api.apiRequest( 'edd_recurring_revert_failed_pm_update', {
								subscription_id: subscriptionId,
								original_payment_method_id: ajaxResponse.original_payment_method_id,
								nonce: eddRecurringStripeVars.revert_pm_nonce,
							} );
						} catch ( revertError ) {
							console.error( 'EDD Recurring Stripe: Failed to attempt revert payment method (endpoint may be missing):', revertError );
						}
					}
					throw siError; // Throw the original SetupIntent error to be caught by the main catch block.
				}
				// If here, SetupIntent was successful.
				// Clear any "confirmation required" messages and potentially show a success message before form submission.
				const notice = form.querySelector( '.edd-stripe-alert, .edd-alert' );
				if ( notice ) {
					notice.remove();
				}
			}

			// If there's an old PaymentIntent ID (from a previously failed payment), attempt to resolve it.
			if ( paymentIntentIdValue ) {
				// Retrieve the latest intent failure. Convert jQuery promise to native.
				const originalPaymentIntent = await Promise.resolve( api.retrieveIntent( paymentIntentIdValue, 'payment_intent' ) );

				// Handle any further PaymentIntent actions, attempting to use the new payment method.
				// api.handleIntent returns a native Promise
				const handledPaymentIntentResult = await api.handleIntent( originalPaymentIntent, {
					payment_method: paymentMethod.id, // The ID of the (potentially newly confirmed) payment method
				} );

				if ( handledPaymentIntentResult.error ) {
					// Throw the error to be caught by the main catch block
					throw handledPaymentIntentResult.error;
				}
			}

			// If all steps were successful, remove the event listener and submit the form.
			form.removeEventListener( 'submit', onUpdatePaymentMethod );
			form.submit();

		} catch ( error ) {
			// Catch any errors from the async operations or manual throws.
			handleException( error );
		}
	}
} );
