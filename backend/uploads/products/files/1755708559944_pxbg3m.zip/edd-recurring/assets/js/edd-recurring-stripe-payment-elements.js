document.addEventListener( 'DOMContentLoaded', function () {
	const eddRecurringStripePEVars = window.eddRecurringStripePaymentElementsVars || {};
	const {
		ajax_url,
		revert_pm_nonce,
		subscription_id,
		currency,
		customer_email,
		customer_name,
	} = eddRecurringStripePEVars;

	const eddStripeVars = window.edd_stripe_vars || {};
	const coreElementsCustomizations = eddStripeVars.elementsCustomizations || {};

	const eddStripeGlobal = window.eddStripe;
	const api = eddStripeGlobal ? eddStripeGlobal._plugin : null;

	const paymentElementMount = document.getElementById( 'edd-recurring-stripe-payment-element' );
	const isDebugMode = typeof eddStripeVars !== 'undefined' && eddStripeVars.debuggingEnabled;

	if ( !eddStripeVars.publishable_key || !paymentElementMount || !currency ) {
		return;
	}

	if ( ! api ) {
		handleError( 'Critical payment processing components are missing. Please contact support.' );
		return;
	}

	const stripe = Stripe( eddStripeVars.publishable_key );

	// Construct appearance options from core EDD Stripe vars
	const appearanceRules = ( coreElementsCustomizations.rules && typeof coreElementsCustomizations.rules === 'object' && !Array.isArray( coreElementsCustomizations.rules ) )
		? coreElementsCustomizations.rules
		: {};

	const appearanceVariables = ( coreElementsCustomizations.variables && typeof coreElementsCustomizations.variables === 'object' && !Array.isArray( coreElementsCustomizations.variables ) )
		? coreElementsCustomizations.variables
		: {};

	const appearance = {
		theme: coreElementsCustomizations.theme || 'stripe',
		variables: appearanceVariables,
		rules: appearanceRules,
		labels: coreElementsCustomizations.labels || 'above',
	};

	const elementGroupOptions = {
		mode: 'setup',
		currency: currency.toLowerCase(),
		paymentMethodCreation: 'manual',
		appearance: appearance,
		fonts: coreElementsCustomizations.fonts || [],
		paymentMethodTypes: [ 'card', 'link' ],
	};

	const elements = stripe.elements( elementGroupOptions );

	const coreFieldsConfig = coreElementsCustomizations.fields || {};

	const paymentElementCreateOptions = {
		layout: coreElementsCustomizations.layout || { type: 'tabs', defaultCollapsed: false },
		wallets: coreElementsCustomizations.wallets || { applePay: 'auto', googlePay: 'auto' },
		terms: coreElementsCustomizations.terms || null,
		business: {
			name: eddStripeVars.store_name,
		},
		defaultValues: {
			billingDetails: {
				email: customer_email,
				name: customer_name,
			}
		},
		fields: {
			...coreFieldsConfig,
			billingDetails: {
				...( coreFieldsConfig.billingDetails || {} ),
				address: 'auto',
				name: 'auto',
				email: 'auto',
				phone: 'auto'
			}
		}
	};

	const paymentElement = elements.create( 'payment', paymentElementCreateOptions );
	paymentElement.mount( paymentElementMount );

	const form = document.getElementById( 'edd-recurring-form' );
	const submitButton = form ? form.querySelector( 'input[type="submit"]' ) : null;
	const errorContainer = document.getElementById( 'edd-recurring-stripe-payment-error' );

	if ( !form || !submitButton || !errorContainer ) {
		return;
	}

	const handleSubmit = async function ( event ) {
		if ( paymentElementMount.offsetParent === null ) {
			return;
		}

		event.preventDefault();
		setLoading( true );
		clearErrors();

		// Retrieve the paymentIntentId from the hidden input early, if it exists.
		const paymentIntentIdElement = document.querySelector( 'input[name="edd_recurring_stripe_payment_intent"]' );
		const paymentIntentIdValue = paymentIntentIdElement ? paymentIntentIdElement.value : null;

		try {
			const { error: submitError } = await elements.submit();
			if ( submitError ) {
				handleError( submitError.message );
				setLoading( false );
				return;
			}

			const { paymentMethod, error: createPMError } = await stripe.createPaymentMethod( {
				elements,
				params: {
					billing_details: {
						email: customer_email,
						name: customer_name,
					}
				}
			} );

			if ( createPMError ) {
				handleError( createPMError.message );
				setLoading( false );
				return;
			}

			if ( paymentMethod ) {

				// Get the nonce from the hidden field for BOTH AJAX calls now, as per Loader.php verification.
				const nonceElement = document.getElementById( 'edd_recurring_update_nonce' );
				if ( !nonceElement ) {
					handleError( 'Critical security token missing. Please refresh and try again.' );
					setLoading( false );
					return;
				}
				const nonceForAjax = nonceElement.value;

				const formData = new URLSearchParams();
				formData.append( 'action', 'edd_recurring_update_pm_elements' );
				formData.append( 'subscription_id', subscription_id );
				formData.append( 'payment_method_id', paymentMethod.id );
				formData.append( 'nonce', nonceForAjax ); // Use nonce from the hidden field
				formData.append( 'payment_method_exists', 'false' );

				// Include update token if available (for non-logged-in users)
				const updateTokenElement = document.querySelector( '[name="update_token"]' );
				if ( updateTokenElement && updateTokenElement.value ) {
					formData.append( 'update_token', updateTokenElement.value );
				}

				fetch( ajax_url, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded',
					},
					body: formData,
				} )
					.then( response => response.json() )
					.then( async response => {
						if ( response.success ) {
							const originalStripePM = response.data.original_payment_method_id;

							if ( response.data.setup_intent && response.data.setup_intent.client_secret ) {
								const { error: confirmSetupError, setupIntent } = await stripe.confirmSetup( {
									elements,
									clientSecret: response.data.setup_intent.client_secret,
									confirmParams: {
										return_url: window.location.href,
									},
									redirect: 'if_required'
								} );

								if ( confirmSetupError ) {
									handleError( 'Could not confirm your new payment method: ' + confirmSetupError.message );
									await revertPaymentMethod( originalStripePM );
								} else if ( setupIntent && setupIntent.status === 'succeeded' ) {

									// Attempt to pay outstanding invoice if one exists
									if ( paymentIntentIdValue ) {
										try {
											const originalPaymentIntent = await Promise.resolve( api.retrieveIntent( paymentIntentIdValue, 'payment_intent' ) );
											if ( originalPaymentIntent && originalPaymentIntent.client_secret ) {
												if ( isDebugMode ) console.log( 'EDD Recurring Stripe PE: Attempting to confirm payment for outstanding invoice (after SI). PM ID:', paymentMethod.id );
												const { error: confirmPaymentError } = await stripe.confirmPayment( {
													clientSecret: originalPaymentIntent.client_secret,
													confirmParams: {
														return_url: window.location.href.split( '#' )[ 0 ] + '#payment-attempted',
														payment_method: paymentMethod.id,
													},
													redirect: 'if_required'
												} );
												if ( confirmPaymentError ) {
													handleError( 'Attempted to pay outstanding invoice but failed: ' + confirmPaymentError.message + ' Your payment method has been updated for future renewals.', true );
													if ( isDebugMode ) console.error( 'EDD Recurring Stripe PE: Error confirming payment for outstanding invoice (after SI):', confirmPaymentError );
												}
											} else {
												if ( isDebugMode ) console.warn( 'EDD Recurring Stripe PE: Could not retrieve outstanding Payment Intent or its client_secret (after SI).' );
											}
										} catch ( retrieveError ) {
											handleError( 'Error retrieving details for outstanding payment (after SI): ' + retrieveError.message, true );
										}
									}
									await triggerFinalUpdate( subscription_id, paymentMethod.id );
								} else {
									handleError( 'Payment method confirmation status: ' + ( setupIntent ? setupIntent.status : 'unknown' ) + '.' );
									await revertPaymentMethod( originalStripePM );
								}
							} else {
								// Attempt to pay outstanding invoice if one exists
								if ( paymentIntentIdValue ) {
									try {
										const originalPaymentIntent = await Promise.resolve( api.retrieveIntent( paymentIntentIdValue, 'payment_intent' ) );
										if ( originalPaymentIntent && originalPaymentIntent.client_secret ) {
											if ( isDebugMode ) console.log( 'EDD Recurring Stripe PE: Attempting to confirm payment for outstanding invoice (no SI). PM ID:', paymentMethod.id );
											const { error: confirmPaymentError } = await stripe.confirmPayment( {
												clientSecret: originalPaymentIntent.client_secret,
												confirmParams: {
													return_url: window.location.href.split( '#' )[ 0 ] + '#payment-attempted',
													payment_method: paymentMethod.id,
												},
												redirect: 'if_required'
											} );
											if ( confirmPaymentError ) {
												handleError( 'Attempted to pay outstanding invoice but failed: ' + confirmPaymentError.message + ' Your payment method has been updated for future renewals.', true );
												if ( isDebugMode ) console.error( 'EDD Recurring Stripe PE: Error confirming payment for outstanding invoice (no SI):', confirmPaymentError );
											}
										}
									} catch ( retrieveError ) {
										handleError( 'Error retrieving details for outstanding payment (no SI): ' + retrieveError.message, true );
									}
								}
								await triggerFinalUpdate( subscription_id, paymentMethod.id );
							}
						} else {
							handleError( response.data.message || 'Could not update payment method.' );
							setLoading( false );
						}
					} )
					.catch( ( error ) => {
						handleError( 'An error occurred while updating your payment method. Please try again.' );
						setLoading( false );
					} );
			} else {
				setLoading( false );
				handleError( 'Could not create payment method details. Please try re-entering your information.' );
			}
		} catch ( e ) {
			handleError( 'An unexpected error occurred: ' + e.message );
			setLoading( false );
		}
	};

	form.addEventListener( 'submit', handleSubmit );

	async function triggerFinalUpdate ( stripeSubscriptionId, stripePaymentMethodId ) {
		const nonceElement = document.getElementById( 'edd_recurring_update_nonce' );
		if ( !nonceElement ) {
			handleError( 'Could not find nonce for final update. Please contact support.' );
			setLoading( false );
			return;
		}
		const nonce = nonceElement.value;

		const requestData = {
			subscription_id: stripeSubscriptionId,
			payment_method_id: stripePaymentMethodId,
			payment_method_exists: 'true',
			nonce: nonce,
		};

		// Include update token if available (for non-logged-in users)
		const updateTokenElement = document.querySelector( '[name="update_token"]' );
		if ( updateTokenElement && updateTokenElement.value ) {
			requestData.update_token = updateTokenElement.value;
		}

		try {
			await Promise.resolve( api.apiRequest( 'edd_recurring_update_subscription_payment_method', requestData ) );

			form.removeEventListener( 'submit', handleSubmit );
			form.submit();

		} catch ( error ) {
			let message = 'Failed to finalize payment method update on the site.';
			if ( error && error.message ) {
				message = error.message;
			} else if ( typeof error === 'string' ) {
				message = error;
			}
			handleError( message );
			setLoading( false );
		}
	}

	async function revertPaymentMethod ( paymentMethodToRevertTo ) {
		if ( !paymentMethodToRevertTo ) {
			handleError( 'Could not revert payment method: Original payment method ID not available. Please contact support.', true );
			setLoading( false );
			return;
		}

		const formData = new URLSearchParams();
		formData.append( 'action', 'edd_recurring_revert_failed_pm_update' );
		formData.append( 'subscription_id', subscription_id );
		formData.append( 'original_payment_method_id', paymentMethodToRevertTo );
		formData.append( 'nonce', revert_pm_nonce );

		try {
			const response = await fetch( ajax_url, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: formData,
			} );
			const revertResponse = await response.json();
			if ( ! revertResponse.success ) {
				handleError( 'Failed to restore your previous payment method: ' + ( revertResponse.data.message || 'Unknown error.' ) + ' Please contact support.', true );
			}
		} catch ( error ) {
			handleError( 'An error occurred while attempting to restore your previous payment method. Please contact support.', true );
		} finally {
			setLoading( false );
		}
	}

	function setLoading ( isLoading ) {
		if ( !form || !submitButton ) return;

		submitButton.disabled = isLoading;

		const existingSpinner = form.querySelector( '.edd-recurring-pm-spinner' );
		if ( existingSpinner ) {
			existingSpinner.remove();
		}

		if ( isLoading ) {
			const spinner = document.createElement( 'span' );
			spinner.classList.add( 'edd-loading' );
			spinner.classList.add( 'edd-loading-ajax' );
			spinner.classList.add( 'edd-recurring-pm-spinner' );
			form.appendChild( spinner );
		}
	}

	function clearErrors () {
		errorContainer.innerHTML = '';
		errorContainer.style.display = 'none';
	}

	function handleError ( message, isAdditionalInfo = false ) {
		const p = document.createElement( 'p' );
		p.textContent = message;
		if ( !isAdditionalInfo ) {
			errorContainer.innerHTML = '';
		}
		errorContainer.appendChild( p );
		errorContainer.style.display = 'block';
	}
} );
