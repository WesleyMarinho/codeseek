<?php
/**
 * Plugin Name: Easy Digital Downloads - Recurring Payments
 * Plugin URI: https://easydigitaldownloads.com/downloads/edd-recurring/
 * Description: Sell subscriptions with Easy Digital Downloads.
 * Author: Easy Digital Downloads
 * Author URI: https://easydigitaldownloads.com
 * Version: 2.13.1
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: edd-recurring
 * Domain Path: languages
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

define( 'EDD_RECURRING_STORE_API_URL', 'https://easydigitaldownloads.com' );
define( 'EDD_RECURRING_PRODUCT_NAME', 'Recurring Payments' );

if ( ! defined( 'EDD_RECURRING_PLUGIN_DIR' ) ) {
	define( 'EDD_RECURRING_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'EDD_RECURRING_PLUGIN_URL' ) ) {
	define( 'EDD_RECURRING_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'EDD_RECURRING_PLUGIN_FILE' ) ) {
	define( 'EDD_RECURRING_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'EDD_RECURRING_VERSION' ) ) {
	define( 'EDD_RECURRING_VERSION', '2.13.1' );
}

define( 'EDD_RECURRING_MINIMUM_PHP', '7.4' );

/**
 * The main function responsible for returning the one true EDD_Recurring Instance
 * to functions everywhere.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * Example: <?php $recurring = EDD_Recurring(); ?>
 *
 * @since v1.0
 *
 * @return EDD\Recurring\Plugin|void The one true EDD_Recurring Instance (provided requirements have been met).
 */
function EDD_Recurring() {
	return EDD\Recurring\Plugin::instance();
}

require_once __DIR__ . '/vendor/autoload.php';
\EDD\ExtensionUtils\v1\ExtensionLoader::loadOrQuit(
	__FILE__,
	'EDD_Recurring',
	array(
		'php'                    => EDD_RECURRING_MINIMUM_PHP,
		'easy-digital-downloads' => '3.2.12',
		'wp'                     => '5.8',
	)
);

/**
 * Alias the EDD\Recurring\Plugin class to the EDD_Recurring class.
 *
 * @since 2.13.0
 */
class_alias( EDD\Recurring\Plugin::class, 'EDD_Recurring' );

/**
 * On activation, set a flag to say that we need to run the installation process.
 * We don't actually run the activation here because we haven't yet checked the
 * system requirements.
 *
 * @see edd_recurring_install()
 */
register_activation_hook(
	__FILE__,
	function () {
		if ( ! get_option( 'edd_recurring_version' ) ) {
			update_option( 'edd_recurring_run_install', time() );
		}
	}
);
