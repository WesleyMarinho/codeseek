<?php
/**
 * Recurring Email Functions
 *
 * @package    edd-recurring
 * @subpackage Emails
 * @copyright  Copyright (c) 2022, Easy Digital Downloads
 * @license    GPL2+
 * @since      2.12.0
 */

namespace EDD\Recurring\Emails;

/**
 * Registers new email tags for recurring products.
 *
 * @since 2.12.0
 * @return void
 */
function register_email_tags() {

	$new_tags = array(
		'subscription_details' => array(
			'description' => __( 'Include the details for purchased subscription(s).', 'edd-recurring' ),
			'callback'    => __NAMESPACE__ . '\subscription_details',
			'label'       => __( 'Subscription Details', 'edd-recurring' ),
			'contexts'    => array( 'order', 'subscription' ),
		),
		'subscription_id'      => array(
			'description' => __( 'Include the subscription ID.', 'edd-recurring' ),
			'callback'    => __NAMESPACE__ . '\subscription_id',
			'label'       => __( 'Subscription ID', 'edd-recurring' ),
			'contexts'    => array( 'order', 'subscription' ),
		),
	);

	// Add tags for subscription notices if core EDD email templates are registered.
	if ( edd_recurring_are_email_templates_registered() ) {
		$subscription_tags = array(
			'name'                => array(
				'description' => __( 'Include the name of the customer.', 'edd-recurring' ),
				'callback'    => function ( $subscription_id, $subscription = null ) {
					if ( ! $subscription instanceof \EDD\Recurring\Subscriptions\Subscription ) {
						$subscription = edd_recurring_get_subscription( $subscription_id );
					}
					if ( empty( $subscription->customer->name ) ) {
						return '';
					}

					return $subscription->customer->name;
				},
				'label'       => __( 'Customer Name', 'edd-recurring' ),
				'contexts'    => array( 'subscription' ),
			),
			'subscription_link'   => array(
				'description' => __( 'Include the link to the subscription management page. This is intended for store administrators only.', 'edd-recurring' ),
				'callback'    => function ( $subscription_id ) {
					return edd_get_admin_url(
						array(
							'page' => 'edd-subscriptions',
							'id'   => $subscription_id,
						)
					);
				},
				'label'       => __( 'Subscription Link', 'edd-recurring' ),
				'contexts'    => array( 'subscription' ),
				'recipients'  => array( 'admin' ),
			),
			'subscription_name'   => array(
				'description' => __( 'Include the name of the subscription.', 'edd-recurring' ),
				'callback'    => __NAMESPACE__ . '\subscription_name',
				'label'       => __( 'Subscription Name', 'edd-recurring' ),
				'contexts'    => array( 'subscription' ),
			),
			'expiration'          => array(
				'description' => __( 'Include the expiration date of the subscription.', 'edd-recurring' ),
				'callback'    => function ( $subscription_id, $email_object = null ) {
					if ( ! $email_object instanceof \EDD\Recurring\Subscriptions\Subscription ) {
						$email_object = edd_recurring_get_subscription( $subscription_id );
					}
					if ( empty( $email_object->expiration ) ) {
						return '';
					}

					$expiration = strtotime( $email_object->expiration );

					return date_i18n( get_option( 'date_format' ), $expiration );
				},
				'label'       => __( 'Subscription Expiration', 'edd-recurring' ),
				'contexts'    => array( 'subscription' ),
			),
			'subscription_id'     => array(
				'description' => __( 'Include the ID of the subscription.', 'edd-recurring' ),
				'callback'    => function ( $subscription_id ) {
					return $subscription_id;
				},
				'label'       => __( 'Subscription ID', 'edd-recurring' ),
				'contexts'    => array( 'subscription' ),
			),
			'subscription_period' => array(
				'description' => __( 'Include the period of the subscription.', 'edd-recurring' ),
				'callback'    => function ( $subscription_id, $email_object = null ) {
					if ( ! $email_object instanceof \EDD\Recurring\Subscriptions\Subscription ) {
						$email_object = edd_recurring_get_subscription( $subscription_id );
					}

					return ! empty( $email_object->period ) ? $email_object->period : '';
				},
				'label'       => __( 'Subscription Period', 'edd-recurring' ),
				'contexts'    => array( 'subscription' ),
			),
			'amount'              => array(
				'description' => __( 'Include the amount of the subscription.', 'edd-recurring' ),
				'callback'    => function ( $subscription_id, $email_object = null, $context = 'order' ) {
					if ( 'subscription' === $context && ! $email_object instanceof \EDD\Recurring\Subscriptions\Subscription ) {
						$email_object = edd_recurring_get_subscription( $subscription_id );
					}
					if ( empty( $email_object->recurring_amount ) ) {
						return '';
					}

					return edd_currency_filter( edd_format_amount( $email_object->recurring_amount ), edd_get_payment_currency_code( $email_object->parent_payment_id ) );
				},
				'label'       => __( 'Subscription Amount', 'edd-recurring' ),
				'contexts'    => array( 'subscription' ),
			),
			'update_payment_link' => array(
				'description' => __( 'Generate a secure link for customers with Stripe subscriptions to update their payment methods without requiring them to log in.', 'edd-recurring' ),
				'callback'    => function ( $subscription_id, $email_object = null ) {
					$link = \EDD\Recurring\Subscriptions\Update\Link::generate_for_subscription( $email_object );

					return $link ? sprintf( '<a href="%s">%s</a>', $link, __( 'Update Payment Method', 'edd-recurring' ) ) : '';
				},
				'label'       => __( 'Update Payment Link', 'edd-recurring' ),
				'contexts'    => array( 'subscription' ),
				'recipients'  => array( 'customer' ),
			),
		);

		$new_tags = array_merge( $new_tags, $subscription_tags );
	}

	foreach ( $new_tags as $tag => $args ) {
		edd_add_email_tag(
			$tag,
			$args['description'],
			$args['callback'],
			$args['label'],
			$args['contexts'],
			$args['recipients'] ?? array()
		);
	}
}
add_action( 'edd_add_email_tags', __NAMESPACE__ . '\register_email_tags', 100 );

/**
 * Gets the recurring details for the purchase receipt email.
 *
 * @since 2.12.0
 * @param int                    $object_id    The order ID. As of 2.12.4 this can also be a subscription ID.
 * @param null|\EDD\Recurring\Subscriptions\Subscription $email_object The subscription object.
 * @param string                 $context      The context of the email.
 * @return string
 */
function subscription_details( $object_id, $email_object = null, $context = 'order' ) {
	if ( empty( $object_id ) ) {
		return '{subscription_details}';
	}
	if ( 'subscription' === $context ) {
		if ( ! $email_object instanceof \EDD\Recurring\Subscriptions\Subscription ) {
			$email_object = edd_recurring_get_subscription( $object_id );
		}
		if ( empty( $email_object->product_id ) ) {
			return '';
		}

		return sprintf(
			'%s: %s<br /><i>%s</i>',
			edd_get_download_name( $email_object->product_id, $email_object->price_id ),
			edd_currency_filter( edd_format_amount( $email_object->recurring_amount ), edd_get_payment_currency_code( $email_object->parent_payment_id ) ),
			edd_recurring_get_subscription_billing_text(
				array(
					'period' => $email_object->period,
					'times'  => $email_object->bill_times,
				)
			)
		);
	}
	$cart_items = edd_get_payment_meta_cart_details( $object_id );
	$output     = '';

	// Loop through purchases see which are recurring
	foreach ( $cart_items as $item ) {

		// If the item isn't recurring, skip it.
		if ( empty( $item['item_number']['options']['recurring'] ) ) {
			continue;
		}

		$output .= sprintf(
			'<li>%s: %s<br /><i>%s</i></li>',
			get_download_name( $item ),
			edd_currency_filter( edd_format_amount( $item['item_price'] ), edd_get_payment_currency_code( $object_id ) ),
			edd_recurring_get_subscription_billing_text( get_recurring_args( $item ) )
		);
	}

	if ( empty( $output ) ) {
		return '';
	}

	return '<ul>' . $output . '</ul>';
}

/**
 * Gets the subscription ID for the email tag.
 *
 * @since 2.12.0
 * @param int $email_object_id The email object ID.
 * @return string
 */
function subscription_id( $email_object_id ) {
	// If this a renewal order a subscription, get the subscription ID from the order meta.
	$sub_id = edd_get_order_meta( $email_object_id, 'subscription_id', true );
	if ( $sub_id ) {
		return $sub_id;
	}

	$is_initial_order = edd_get_order_meta( $email_object_id, '_edd_subscription_payment', true );
	if ( ! $is_initial_order ) {
		return '';
	}
	$subs = edd_recurring_get_subscriptions(
		array(
			'parent_payment_id' => $email_object_id,
			'order'             => 'ASC',
		)
	);
	if ( empty( $subs ) ) {
		return '';
	}

	$sub = reset( $subs );

	return $sub->id;
}

/**
 * Gets the download name for the email.
 *
 * @since 2.12.0
 * @param array $item The cart item.
 * @return string
 */
function get_download_name( $item ) {
	$price_id = null;
	if ( isset( $item['item_number']['options']['price_id'] ) && edd_has_variable_prices( $item['id'] ) ) {
		$price_id = $item['item_number']['options']['price_id'];
	}

	return edd_get_download_name( $item['id'], $price_id );
}

/**
 * Parses the individual item recurring parameters with defaults.
 *
 * @since 2.12.0
 * @param array $item The cart item.
 * @return array
 */
function get_recurring_args( $item ) {
	$recurring      = array(
		'period'       => false,
		'times'        => false,
		'trial_period' => false,
		'trial_unit'   => false,
	);
	$item_recurring = maybe_unserialize( $item['item_number']['options']['recurring'] );

	return wp_parse_args( $item_recurring, $recurring );
}

/**
 * Gets the subscription name for the email.
 *
 * @since 2.12.4
 * @param int                                            $object_id    The order ID. As of 2.12.4 this can also be a subscription ID.
 * @param null|\EDD\Recurring\Subscriptions\Subscription $email_object The subscription object.
 * @return string
 */
function subscription_name( $object_id, $email_object = null ) {
	if ( ! $email_object instanceof \EDD\Recurring\Subscriptions\Subscription ) {
		$email_object = edd_recurring_get_subscription( $object_id );
	}
	if ( empty( $email_object->product_id ) || ! $email_object instanceof \EDD\Recurring\Subscriptions\Subscription ) {
		return '';
	}

	return edd_get_download_name( $email_object->product_id, $email_object->price_id );
}
