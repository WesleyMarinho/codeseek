<?php
/**
 * Deprecated classes.
 *
 * @package EDD\Recurring\Deprecated
 * @copyright   Copyright (c) 2024, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.12.4
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Legacy `EDD_Recurring_Emails` class was refactored and moved to the new `EDD\Recurring\Legacy\Emails` class.
 * This alias is a safeguard to those developers who use our EDD_Recurring_Emails class directly.
 * The legacy class will be removed in the future.
 *
 * @since 2.12.4
 */
class_alias( \EDD\Recurring\Legacy\Emails::class, 'EDD_Recurring_Emails' );

/**
 * Legacy `EDD_Recurring_Reminders` class was refactored and moved to the new `EDD\Recurring\Legacy\Reminders` class.
 * This alias is a safeguard to those developers who use our EDD_Recurring_Reminders class directly.
 * The legacy class will be removed in the future.
 *
 * @since 2.12.4
 */
class_alias( \EDD\Recurring\Legacy\Reminders::class, 'EDD_Recurring_Reminders' );

/**
 * Legacy `EDD_Recurring_Cron` class was refactored and moved to the new `EDD\Recurring\Cron\Handler` class.
 * This alias is a safeguard to those developers who use our EDD_Recurring_Cron class directly.
 * The legacy class will be removed in the future.
 *
 * @since 2.13.0
 */
class_alias( \EDD\Recurring\Cron\Handler::class, 'EDD_Recurring_Cron' );

/**
 * Legacy `EDD_Recurring_DB` class was refactored and moved to the new `EDD\Recurring\Legacy\Database` class.
 * This alias is a safeguard to those developers who use our EDD_Recurring_DB class directly.
 * The legacy class will be removed in the future.
 *
 * @since 2.13.0
 */
class_alias( \EDD\Recurring\Legacy\Database::class, 'EDD_Subscriptions_DB' );

/**
 * Legacy `EDD_Subscription` class was refactored and moved to the new `EDD\Recurring\Subscriptions\Subscription` class.
 * This alias is a safeguard to those developers who use our EDD_Subscription class directly.
 * The legacy class will be removed in the future.
 *
 * @since 2.13.0
 */
class_alias( \EDD\Recurring\Subscriptions\Subscription::class, 'EDD_Subscription' );

/**
 * Legacy `EDD_Recurring_Summary_Widget` class was refactored and moved to the new `EDD\Recurring\Admin\Dashboard\Widget` class.
 * This alias is a safeguard to those developers who use our EDD_Recurring_Summary_Widget class directly.
 * The legacy class will be removed in the future.
 *
 * @since 2.13.0
 */
class_alias( \EDD\Recurring\Admin\Dashboard\Widget::class, 'EDD_Recurring_Summary_Widget' );
