<?php
/**
 * Integrates EDD Recurring with the EDD Invoices extension
 *
 * @package     EDD\Recurring\Integrations
 * @copyright   Copyright (c) 2016, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.5.3
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class EDD_Recurring_Invoices
 *
 * @since 2.5.3
 */
class EDD_Recurring_Invoices {

	/**
	 * Get things started
	 *
	 * @since  2.5.3
	 * @return void
	 */
	public function __construct() {
		add_filter( 'edd_invoices_acceptable_payment_statuses', array( $this, 'add_acceptable_payment_statuses' ), 10, 1 );
	}

	/**
	 * Add the payment statuses created and used by Recurring to the list of acceptable statuses when EDD Invoices is deciding if it should show the "Generate Invoice" option.
	 *
	 * @since  2.5.3
	 * @param  array $acceptable_statuses  The array containing all of the acceptable payment statuses.
	 * @return array
	 */
	public function add_acceptable_payment_statuses( $acceptable_statuses ) {
		$acceptable_statuses[] = 'edd_subscription';

		return $acceptable_statuses;
	}
}
