<?php
/**
 * Handle subscription cancellation options on EDD Payments when applying a refund.
 *
 * This class is for working with payments in EDD.
 *
 * @package     EDD Recurring
 * @subpackage  Refunds
 * @copyright   Copyright (c) 2019, Sandhills Development
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.9.3
 */

add_action( 'edd_after_submit_refund_table', 'edd_recurring_show_cancel_checkbox' );
add_action( 'edd_refund_order', 'edd_recurring_cancel_subscription_on_order_refund' );

/**
 * Shows the checkbox to cancel a subscription in the refund modal.
 *
 * @since 2.10.4
 * @param \EDD\Orders\Order $order The order object (EDD 3.0).
 * @return void
 */
function edd_recurring_show_cancel_checkbox( $order ) {
	$subscriptions = edd_recurring_get_order_subscriptions( $order );

	// If there are no subscriptions linked to the order, do nothing.
	if ( ! $subscriptions ) {
		return;
	}

	?>
	<div class="edd-form-group edd-recurring-cancel-sub">
	<?php
	foreach ( $subscriptions as $sub ) {
		$label = sprintf(
			/* translators: 1. The subscription ID 2. The download name. */
			__( 'Cancel Subscription ID #%1$d (%2$s)', 'edd-recurring' ),
			$sub->id,
			edd_get_download_name( $sub->product_id )
		);
		?>
		<div class="edd-form-group__control">
			<input type="checkbox" id="edd_recurring_cancel_subscription_<?php echo esc_attr( $sub->id ); ?>" name="edd_recurring_cancel_subscription[<?php echo esc_attr( $sub->id ); ?>]" class="edd-form-group__input" value="<?php echo esc_attr( $sub->id ); ?>" />
			<label for="edd_recurring_cancel_subscription_<?php echo esc_attr( $sub->id ); ?>"><?php echo esc_html( $label ); ?></label>
		</div>
		<?php
	}
	?>
	</div>
	<?php
}

/**
 * Cancels a subscription during the refund process in EDD 3.0.
 *
 * @since 2.10.4
 * @param int $order_id The original order ID.
 * @return void
 */
function edd_recurring_cancel_subscription_on_order_refund( $order_id ) {
	if ( ! current_user_can( 'manage_subscriptions' ) ) {
		return;
	}

	if ( empty( $_POST['data'] ) ) {
		return;
	}

	// Get our data out of the serialized string.
	parse_str( $_POST['data'], $form_data );
	if ( empty( $form_data['edd_recurring_cancel_subscription'] ) || ! is_array( $form_data['edd_recurring_cancel_subscription'] ) ) {
		return;
	}
	$order = edd_get_order( $order_id );
	if ( empty( $order ) ) {
		return;
	}
	$subs = edd_recurring_get_order_subscriptions( $order );
	if ( ! $subs ) {
		return;
	}

	foreach ( $subs as $sub ) {
		if ( ! $sub instanceof \EDD\Recurring\Subscriptions\Subscription ) {
			continue;
		}
		if ( ! in_array( $sub->id, $form_data['edd_recurring_cancel_subscription'] ) ) {
			continue;
		}

		$recurring = edd_recurring();
		remove_action( 'edd_subscription_cancelled', array( $recurring::$emails, 'send_subscription_cancelled' ) );
		remove_action( 'edd_subscription_cancelled', array( $recurring::$emails, 'send_subscription_cancelled_admin' ) );

		// Run the cancel method in the EDD\Recurring\Subscriptions\Subscription class. This also cancels the sub at the gateway.
		$sub->cancel();

		$note = edd_add_note(
			array(
				'object_type' => 'order',
				'object_id'   => $order_id,
				/* translators: the subscription ID. */
				'content'     => sprintf( __( 'Subscription %d cancelled because of refund.', 'edd-recurring' ), $sub->id ),
				'user_id'     => get_current_user_id(),
			)
		);
	}
}
