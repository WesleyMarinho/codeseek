<?php
/**
 * @var EDD_Subscription $sub
 */

if ( ! current_user_can( 'view_subscriptions' ) ) {
	edd_set_error( 'edd-no-access', __( 'You are not permitted to view this data.', 'edd-recurring' ) );
}

$sub_id = filter_input( INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT );
if ( ! $sub_id ) {
	edd_set_error( 'edd-invalid_subscription', __( 'Invalid subscription ID provided.', 'edd-recurring' ) );
}

$sub = edd_recurring_get_subscription( $sub_id );
if ( ! $sub ) {
	edd_set_error( 'edd-invalid_subscription', __( 'Invalid subscription ID provided.', 'edd-recurring' ) );
}

if ( edd_get_errors() ) {
	?>
	<div class="wrap">
	<h1><?php esc_html_e( 'Subscription Details', 'edd-recurring' ); ?></h1>
		<div class="error settings-error">
			<?php edd_print_errors(); ?>
		</div>
	</div>
	<?php
	return;
}

$currency_code = edd_get_payment_currency_code( $sub->parent_payment_id );

$current_view      = isset( $_GET['view'] ) ? sanitize_text_field( $_GET['view'] ) : 'general';
$subscription_tabs = edd_recurring_get_subscription_tabs();
if ( ! array_key_exists( $current_view, $subscription_tabs ) ) {
	$current_view = 'general';
}
?>
<div class="wrap">
	<h1><?php esc_html_e( 'Subscription Details', 'edd_recurring' ); ?></h1>

	<div id="edd-item-wrapper" class="edd-item-has-tabs edd-clearfix edd-recurring-subscription__item-wrapper edd-vertical-sections edd-sections-wrap">
		<ul id="edd-item-tab-wrapper-list" class="customer-tab-wrapper-list section-nav">
			<?php
			foreach ( $subscription_tabs as $tab_key => $subscription_tab ) :
				if ( ! is_callable( $subscription_tab['view'] ) && ! file_exists( __DIR__ . "/tab-{$subscription_tab['view']}.php" ) ) {
					continue;
				}
				$active = $tab_key === $current_view;
				$url    = '';
				$class  = 'section-title';
				if ( $active ) {
					$class .= ' section-title--is-active active';
				} else {
					$class .= ' inactive';
				}
				?>

				<li class="<?php echo esc_attr( $class ); ?>">
					<?php
					if ( ! $active ) :
						$url = add_query_arg(
							array(
								'post_type' => 'download',
								'page'      => 'edd-subscriptions',
								'view'      => urlencode( $tab_key ),
								'id'        => urlencode( $sub->id ),
							),
							admin_url( 'edit.php' )
						)
						?>
					<?php endif; ?>
					<a href="<?php echo esc_url( $url ); ?>">
						<span class="dashicons <?php echo sanitize_html_class( $subscription_tab['dashicon'] ); ?>" aria-hidden="true"></span>
						<span class="edd-item-tab-label"><?php echo esc_attr( $subscription_tab['title'] ); ?></span>
					</a>
				</li>

			<?php endforeach; ?>
		</ul>
		<div class="subscription-details__id">
			#<?php echo esc_html( $sub->id ); ?>
			<?php
			if ( 'active' !== $sub->status ) {
				echo ' &mdash; ' . esc_html( $sub->get_status_label() );
			}
			?>
		</div>
		<div id="edd-item-card-wrapper" class="section-wrap edd-subscription-card-wrapper section-content">
			<div class="info-wrapper item-section">
				<?php
				$payments = $sub->get_renewal_orders();
				if ( array_key_exists( $current_view, $subscription_tabs ) && is_callable( $subscription_tabs[ $current_view ]['view'] ) ) {
					call_user_func( $subscription_tabs[ $current_view ]['view'], $sub );
				} elseif ( file_exists( __DIR__ . "/tab-{$current_view}.php" ) ) {
					require_once "tab-{$current_view}.php";
				} else {
					?>
					<div class="error settings-error inline">
						<p><?php esc_html_e( 'Invalid subscription tab.', 'edd-recurring' ); ?></p>
					</div>
					<?php
				}
				?>
			</div>
		</div>

	</div>
</div>
