<?php
/**
 * Export Actions
 *
 * @package   EDD\Recurring\Admin\Exports
 * @copyright Copyright (c) 2021, Sandhills Development, LLC
 * @license   GPL2+
 * @since     2.11.8
 */

namespace EDD_Recurring\Admin\Export;

/**
 * This is really hacky, but important until EDD core better supports namespaced classes.
 * During the download, `EDD\Recurring\Admin\Exports\Subscriptions` get converted to:
 * `EDD\\\\Recurring\\\\Admin\\\\Exports\\\\Subscriptions` . This breaks the `class_exists()`
 * check in EDD core ( @see edd_process_batch_export_download() ). Therefore, we hook in before
 * that runs to strip slashes, which makes everything work again. Dumb, but temporarily necessary.
 *
 * @link https://github.com/easydigitaldownloads/easy-digital-downloads/issues/8887
 * @todo Remove when the EDD core minimum is 3.3.8.
 *
 * @since 2.11.8
 */
add_action(
	'edd_download_batch_export',
	function () {
		if ( isset( $_REQUEST['class'] ) && \EDD\Recurring\Admin\Exports\Subscriptions::class === stripslashes( $_REQUEST['class'] ) ) {
			$_REQUEST['class'] = \EDD\Recurring\Admin\Exports\Subscriptions::class;
		}
	},
	-100
);

/**
 * Adds the Export Subscriptions form to the Export page.
 *
 * @since 2.11.8
 * @todo Remove when the EDD core minimum is 3.3.8.
 */
add_action(
	'edd_reports_tab_export_content_bottom',
	function () {
		if ( did_action( 'edd_export_form' ) ) {
			return;
		}
		?>
		<div class="postbox edd-export-payment-history">
			<h2 class="hndle"><span><?php esc_html_e( 'Export Subscriptions', 'edd-recurring' ); ?></span></h2>
			<div class="inside">
				<p><?php esc_html_e( 'Download a CSV of all subscriptions. The datepickers can be used to filter by subscription start date; only subscriptions started within that range will be included.', 'edd-recurring' ); ?></p>

				<form id="edd-export-subscriptions" class="edd-export-form edd-import-export-form" method="post">
					<?php export_form( 'subscriptions_export' ); ?>
					<?php wp_nonce_field( 'edd_ajax_export', 'edd_ajax_export' ); ?>
					<input type="hidden" name="edd-export-class" value="<?php echo esc_attr( \EDD\Recurring\Admin\Exports\Subscriptions::class ); ?>"/>
					<button type="submit" class="button button-secondary"><?php esc_html_e( 'Generate CSV', 'edd-recurring' ); ?></button>
				</form>

			</div><!-- .inside -->
		</div><!-- .postbox -->
		<?php
	}
);

/**
 * Registers the Export Subscriptions exporter.
 *
 * @since 2.13.0
 */
add_action(
	'edd_export_init',
	function ( $registry ) {
		$registry->register_exporter(
			'subscriptions_export',
			array(
				'label'       => __( 'Subscriptions', 'edd-recurring' ),
				'description' => __( 'Download a CSV of all subscriptions. The datepickers can be used to filter by subscription start date; only subscriptions started within that range will be included.', 'edd-recurring' ),
				'class'       => \EDD\Recurring\Admin\Exports\Subscriptions::class,
			)
		);
	}
);

/**
 * Adds the Export Subscriptions form to the Export page.
 *
 * @since 2.13.0
 */
function export_form( $exporter_id ) {
	if ( 'subscriptions_export' !== $exporter_id ) {
		return;
	}
	?>
	<label for="edd-subscriptions-export-product" class="screen-reader-text">
		<?php esc_html_e( 'Select Product', 'edd-recurring' ); ?>
	</label>
	<?php
	add_filter( 'edd_product_dropdown_args', 'edd_recurring_product_dropdown_recurring_only' );
	$products = new \EDD\HTML\ProductSelect(
		array(
			'name'            => 'product_id',
			'id'              => 'edd-subscriptions-export-product',
			'selected'        => 'all',
			'show_option_all' => sprintf( __( 'All %s', 'edd-recurring' ), edd_get_label_plural() ),
			'chosen'          => true,
			/* translators: the plural post type label */
			'placeholder'     => sprintf( __( 'All %s', 'edd-recurring' ), edd_get_label_plural() ),
		)
	);
	$products->output();
	remove_filter( 'edd_product_dropdown_args', 'edd_recurring_product_dropdown_recurring_only' );
	?>

	<span class="edd-from-to-wrapper">
		<label for="edd-subscriptions-export-start" class="screen-reader-text">
			<?php esc_html_e( 'Set start date', 'edd-recurring' ); ?>
		</label>
		<?php
		echo EDD()->html->date_field(
			array(
				'id'          => 'edd-subscriptions-export-start',
				'name'        => 'start',
				'placeholder' => __( 'Choose start date', 'edd-recurring' ),
			)
		);
		?>

		<label for="edd-subscriptions-export-end" class="screen-reader-text">
			<?php esc_html_e( 'Set end date', 'edd-recurring' ); ?>
		</label>
		<?php
		echo EDD()->html->date_field(
			array(
				'id'          => 'edd-subscriptions-export-end',
				'name'        => 'end',
				'placeholder' => __( 'Choose end date', 'edd-recurring' ),
			)
		);
		?>
	</span>

	<label for="edd-subscriptions-status" class="screen-reader-text">
		<?php esc_html_e( 'Filter by status', 'edd-recurring' ); ?>
	</label>
	<?php
	$select = new \EDD\HTML\Select(
		array(
			'id'               => 'edd-subscriptions-status',
			'name'             => 'status',
			'options'          => edd_recurring_get_subscription_statuses(),
			'show_option_none' => false,
			'selected'         => 'all',
		)
	);
	$select->output();
}
add_action( 'edd_export_form', __NAMESPACE__ . '\export_form' );
