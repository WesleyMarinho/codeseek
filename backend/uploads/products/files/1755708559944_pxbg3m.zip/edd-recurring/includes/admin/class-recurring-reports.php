<?php

/**
 * Class EDD_Recurring_Reports
 *
 * @since 2.4
 *
 */
class EDD_Recurring_Reports {


	/**
	 * Get it started
	 */
	public function __construct() {

		// EDD 3.0+ Graph Reports.
		add_action( 'edd_reports_init', array( $this, 'register_reports' ) );
	}

	/**
	 * Registers reports with EDD
	 *
	 * @param EDD\Reports\Data\Report_Registry $reports
	 *
	 * @since 2.10.1
	 * @return void
	 */
	public function register_reports( $reports ) {
		try {
			$options = EDD\Reports\get_dates_filter_options();
			$dates   = EDD\Reports\get_filter_value( 'dates' );
			$label   = $options[ $dates['range'] ];

			$reports->add_report(
				'recurring_subscriptions',
				array(
					'label'     => __( 'Subscriptions', 'edd-recurring' ),
					'icon'      => 'update',
					'priority'  => 60,
					'endpoints' => array(
						'tiles'  => array(
							'recurring_subscription_created_number',
							'recurring_subscription_renewals_number',
							'recurring_subscription_renewals_refunded_number',
							'recurring_subscription_total_active',
							'recurring_subscription_mrr',
							'recurring_subscription_arr',
						),
						'charts' => array(
							'recurring_subscription_renewals_chart',
						),
					),
				)
			);

			$reports->register_endpoint(
				'recurring_subscription_created_number',
				array(
					'label' => __( 'New Subscriptions', 'edd-recurring' ),
					'views' => array(
						'tile' => array(
							'data_callback' => 'edd_recurring_subscriptions_created_number_callback',
							'display_args'  => array(
								'comparison_label' => $label,
							),
						),
					),
				)
			);

			$reports->register_endpoint(
				'recurring_subscription_renewals_number',
				array(
					'label' => __( 'Subscription Renewals', 'edd-recurring' ),
					'views' => array(
						'tile' => array(
							'data_callback' => 'edd_recurring_renewals_number_callback',
							'display_args'  => array(
								'comparison_label' => $label,
							),
						),
					),
				)
			);

			$reports->register_endpoint(
				'recurring_subscription_renewals_refunded_number',
				array(
					'label' => __( 'Refunded Subscription Renewals', 'edd-recurring' ),
					'views' => array(
						'tile' => array(
							'data_callback' => 'edd_recurring_renewals_refunded_number_callback',
							'display_args'  => array(
								'comparison_label' => $label,
							),
						),
					),
				)
			);

			$reports->register_endpoint(
				'recurring_subscription_total_active',
				array(
					'label' => __( 'Active Subscriptions', 'edd-recurring' ),
					'views' => array(
						'tile' => array(
							'data_callback' => function () {
								global $wpdb;

								return absint(
									$wpdb->get_var( "SELECT count(*) FROM {$wpdb->prefix}edd_subscriptions WHERE status IN {$this->get_active_subscription_statuses()} AND expiration >= CURRENT_DATE()" )
								);
							},
							'display_args'  => array(
								'comparison_label' => __( 'Now', 'edd-recurring' ),
							),
						),
					),
				)
			);

			$reports->register_endpoint(
				'recurring_subscription_mrr',
				array(
					'label' => __( 'Monthly Recurring Revenue (MRR)', 'edd-recurring' ),
					'views' => array(
						'tile' => array(
							'data_callback' => function () {
								return edd_currency_filter(
									edd_format_amount(
										edd_sanitize_amount(
											EDD\Recurring\Admin\Reports\RecurringRevenue::get_mrr()
										)
									)
								);
							},
							'display_args'  => array(
								'comparison_label' => __( 'Now', 'edd-recurring' ),
							),
						),
					),
				)
			);

			$reports->register_endpoint(
				'recurring_subscription_arr',
				array(
					'label' => __( 'Annual Recurring Revenue (ARR)', 'edd-recurring' ),
					'views' => array(
						'tile' => array(
							'data_callback' => function () {
								return edd_currency_filter(
									edd_format_amount(
										edd_sanitize_amount(
											EDD\Recurring\Admin\Reports\RecurringRevenue::get_arr()
										)
									)
								);
							},
							'display_args'  => array(
								'comparison_label' => __( 'Now', 'edd-recurring' ),
							),
						),
					),
				)
			);

			$reports->register_endpoint(
				'recurring_subscription_renewals_chart',
				array(
					'label' => __( 'Subscription Renewals', 'edd-recurring' ),
					'views' => array(
						'chart' => array(
							'data_callback' => 'EDD_Recurring_Reports_Chart::get_chart_data',
							'type'          => 'line',
							'options'       => array(
								'datasets' => array(
									'created'  => array(
										'label'            => __( 'New Subscriptions', 'edd-recurring' ),
										'borderColor'      => 'rgb(1,125,92,.75)',
										'backgroundColor'  => 'rgba(1,125,92,0.1)',
										'fill'             => true,
										'borderWidth'      => 2,
										'borderCapStyle'   => 'round',
										'borderJoinStyle'  => 'round',
										'pointRadius'      => 4,
										'pointHoverRadius' => 6,
										'pointBackgroundColor' => 'rgb(255,255,255)',
									),
									'renewals' => array(
										'label'            => __( 'Subscription Renewals', 'edd-recurring' ),
										'borderColor'      => 'rgb(1,96,135,.75)',
										'backgroundColor'  => 'rgba(1,96,135,0.1)',
										'fill'             => true,
										'borderWidth'      => 2,
										'borderCapStyle'   => 'round',
										'borderJoinStyle'  => 'round',
										'pointRadius'      => 4,
										'pointHoverRadius' => 6,
										'pointBackgroundColor' => 'rgb(255,255,255)',
									),
									'refunds'  => array(
										'label'            => __( 'Refunded Subscription Renewals', 'edd-recurring' ),
										'borderColor'      => 'rgb(214,54,56,.75)',
										'backgroundColor'  => 'rgba(214,54,56,0.1)',
										'fill'             => true,
										'borderWidth'      => 2,
										'borderCapStyle'   => 'round',
										'borderJoinStyle'  => 'round',
										'pointRadius'      => 4,
										'pointHoverRadius' => 6,
										'pointBackgroundColor' => 'rgb(255,255,255)',
									),
								),
							),
						),
					),
				)
			);

		} catch ( \Exception $e ) {

		}
	}

	/**
	 * Get the active subscription statuses placeholder.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	private function get_active_subscription_statuses() {
		$statuses = edd_recurring_get_active_subscription_statuses();
		$statuses = array_map(
			function ( $status ) {
				return "'{$status}'";
			},
			$statuses
		);

		return '(' . implode( ',', $statuses ) . ')';
	}
}
new EDD_Recurring_Reports();
