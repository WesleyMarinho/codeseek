<?php
/**
 * @var EDD_Subscription $sub
 */

$link = \EDD\Recurring\Subscriptions\Update\Link::generate_for_subscription( $sub );
if ( empty( $link ) ) {
	return;
}

?>
<div class="edd-recurring-subscription-section edd-recurring-subscription__info">
	<h2><?php esc_html_e( 'Tools', 'edd-recurring' ); ?></h2>

	<div class="edd-recurring-subscription-table">
		<div class="edd-recurring-subscription-table_column">
			<div class="edd-recurring-subscription-table_column-header"><?php esc_html_e( 'Update Card Link', 'edd-recurring' ); ?></div>
			<div class="edd-recurring-subscription-table_column-content">
				<?php
				$input = new \EDD\HTML\Text(
					array(
						'id'       => 'update-card-link',
						'value'    => $link,
						'class'    => array( 'large-text', 'code' ),
						'disabled' => true,
						'readonly' => true,
					)
				);
				echo $input->output();
				?>
			</div>
		</div>
	</div>

</div> <!-- ends __info !-->
