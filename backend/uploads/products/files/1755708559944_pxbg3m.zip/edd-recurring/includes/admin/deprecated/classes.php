<?php
/**
 * Deprecated admin classes.
 *
 * @package     EDD\Recurring\Admin\Deprecated
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

/**
 * Legacy `EDD_Subscription_Reports_Table` class was refactored and moved to the new `EDD\Recurring\Admin\Subscriptions\ListTable` class.
 * This alias is a safeguard to those developers who use our EDD_Subscription_Reports_Table class directly.
 * The legacy class will be removed in the future.
 *
 * @since 2.13.0
 */
class_alias( \EDD\Recurring\Admin\Subscriptions\ListTable::class, 'EDD_Subscription_Reports_Table' );
