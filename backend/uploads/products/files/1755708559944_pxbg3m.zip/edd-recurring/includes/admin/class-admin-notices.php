<?php
/**
 * Recurring admin notices
 *
 * @package     EDD\Recurring\Admin
 * @copyright   Copyright Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Admin Notices
 */
class EDD_Recurring_Admin_Notices {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'admin_notices', array( $this, 'notices' ) );
	}

	/**
	 * Initialize
	 *
	 * @deprecated 2.13.0
	 */
	public function init() {}

	/**
	 * Display admin notices.
	 *
	 * @return void
	 */
	public function notices() {

		if ( ! edd_is_admin_page( 'edd-subscriptions' ) ) {
			return;
		}

		if ( empty( $_GET['edd-message'] ) ) {
			return;
		}

		$type    = 'updated';
		$message = '';

		switch ( strtolower( $_GET['edd-message'] ) ) {

			case 'updated':
				$message = __( 'Subscription updated successfully.', 'edd-recurring' );

				break;

			case 'created':
				$message = __( 'Subscription created successfully.', 'edd-recurring' );
				break;

			case 'deleted':
				$message = __( 'Subscription deleted successfully.', 'edd-recurring' );

				break;

			case 'cancelled':
				$message = __( 'Subscription cancelled successfully.', 'edd-recurring' );
				break;

			case 'cancel-failed':
				$message = __( 'Subscription could not be cancelled.', 'edd-recurring' );
				$type    = 'error';
				break;

			case 'subscription-note-added':
				$message = __( 'Subscription note added successfully.', 'edd-recurring' );

				break;

			case 'subscription-note-not-added':
				$message = __( 'Subscription note could not be added.', 'edd-recurring' );
				$type    = 'error';
				break;

			case 'renewal-added':
				$message = __( 'Renewal payment recorded successfully.', 'edd-recurring' );

				break;

			case 'renewal-not-added':
				$message = __( 'Renewal payment could not be recorded.', 'edd-recurring' );
				$type    = 'error';

				break;

			case 'retry-success':
				$message = __( 'Retry succeeded! The subscription has been renewed successfully.', 'edd-recurring' );

				break;

			case 'retry-failed':
				/* translators: %s: error message */
				$message = sprintf( __( 'Retry failed. %s', 'edd-recurring' ), sanitize_text_field( urldecode( $_GET['error-message'] ) ) );
				$type    = 'error';

				break;

			case 'reactivated':
				$message = __( 'Subscription reactivated successfully.', 'edd-recurring' );
				break;
		}

		if ( ! empty( $message ) ) {
			echo '<div class="' . esc_attr( $type ) . '"><p>' . $message . '</p></div>';
		}
	}
}
$edd_recurring_admin_notices = new EDD_Recurring_Admin_Notices();
