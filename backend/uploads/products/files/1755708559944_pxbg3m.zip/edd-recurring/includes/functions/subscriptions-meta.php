<?php
/**
 * EDD Recurring Subscription Functions
 *
 * @package     EDD\Recurring\Functions
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Adds a meta row to the database for a subscription.
 *
 * @since 2.13.0
 * @param int    $subscription_id The subscription ID.
 * @param string $meta_key        The meta key.
 * @param mixed  $meta_value      The meta value.
 * @param bool   $unique          Whether the meta key should be unique.
 * @return bool
 */
function edd_recurring_add_subscription_meta( $subscription_id, $meta_key, $meta_value, $unique = false ) {
	return add_metadata( 'edd_subscription', $subscription_id, $meta_key, $meta_value, $unique );
}

/**
 * Remove meta data matching criteria from an subscription.
 *
 * You can match based on the key, or key and value. Removing based on key and value, will keep from removing duplicate
 * meta data with the same key. It also allows removing all meta data matching key, if needed.
 *
 * @since 2.13.0
 *
 * @param int    $subscription_id   Order ID.
 * @param string $meta_key   Meta data name.
 * @param mixed  $meta_value Optional. Meta data value. Must be serializable if non-scalar. Default empty.
 *
 * @return bool True on success, false on failure.
 */
function edd_recurring_delete_subscription_meta( $subscription_id, $meta_key, $meta_value = '' ) {
	return delete_metadata( 'edd_subscription', $subscription_id, $meta_key, $meta_value );
}

/**
 * Retrieve subscription meta field for an subscription.
 *
 * @since 2.13.0
 *
 * @param int    $subscription_id  Order ID.
 * @param string $key       Optional. The meta key to retrieve. By default, returns data for all keys. Default empty.
 * @param bool   $single    Optional, default is false. If true, return only the first value of the specified meta_key.
 *                          This parameter has no effect if meta_key is not specified.
 *
 * @return mixed Will be an array if $single is false. Will be value of meta data field if $single is true.
 */
function edd_recurring_get_subscription_meta( $subscription_id, $key = '', $single = false ) {
	return get_metadata( 'edd_subscription', $subscription_id, $key, $single );
}

/**
 * Update subscription meta field based on subscription ID.
 *
 * Use the $prev_value parameter to differentiate between meta fields with the
 * same key and subscription ID.
 *
 * If the meta field for the subscription does not exist, it will be added.
 *
 * @since 2.13.0
 *
 * @param int    $subscription_id   Order ID.
 * @param string $meta_key   Meta data key.
 * @param mixed  $meta_value Meta data value. Must be serializable if non-scalar.
 * @param mixed  $prev_value Optional. Previous value to check before removing. Default empty.
 *
 * @return int|bool Meta ID if the key didn't exist, true on successful update, false on failure.
 */
function edd_recurring_update_subscription_meta( $subscription_id, $meta_key, $meta_value, $prev_value = '' ) {
	return update_metadata( 'edd_subscription', $subscription_id, $meta_key, $meta_value, $prev_value );
}

/**
 * Delete everything from subscription meta matching meta key.
 *
 * @since 2.13.0
 * @param string $meta_key Key to search for when deleting.
 * @return bool Whether the subscription meta key was deleted from the database.
 */
function edd_recurring_delete_subscription_meta_by_key( $meta_key ) {
	return delete_metadata( 'edd_subscription', null, $meta_key, '', true );
}
