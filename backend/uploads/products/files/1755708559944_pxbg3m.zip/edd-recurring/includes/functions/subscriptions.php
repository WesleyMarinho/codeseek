<?php
/**
 * EDD Recurring Subscription Functions
 *
 * @package     EDD\Recurring\Functions
 * @copyright   Copyright (c) 2024, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Recurring\Database\Queries\Subscription;

/**
 * Gets a subscription object.
 *
 * @since 2.12.3
 * @param int $id The subscription ID.
 * @return false|EDD_Subscription
 */
function edd_recurring_get_subscription( $id ) {
	// Check the cache for this subscription.
	$subscription = wp_cache_get( $id, 'edd_subscription_objects', false, $found );

	/**
	 * A false value could either mean we found a value in cache that was false, or no value was found in cache,
	 * so we need to check the $found value to know for sure.
	 *
	 * If $found is true, that means we had a value (and that value could be false, so we'll return it).
	 */
	if ( $found ) {
		return $subscription;
	}

	$subscriptions = new Subscription();
	$subscription  = $subscriptions->get_item( $id );

	wp_cache_set( $id, $subscription, 'edd_subscription_objects', 5 * MINUTE_IN_SECONDS );

	return $subscription;
}

/**
 * Gets a subscription object by a specific field.
 *
 * @since 2.12.3
 * @param string $field The field to search by.
 * @param string $value The value to search for.
 * @return false|EDD_Subscription
 */
function edd_recurring_get_subscription_by( $field, $value ) {
	if ( 'id' === $field ) {
		return edd_recurring_get_subscription( $value );
	}

	global $wpdb;

	$subscription_id = $wpdb->get_var(
		$wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}edd_subscriptions WHERE {$field} = %s LIMIT 1",
			$value
		)
	);

	if ( ! $subscription_id ) {
		return false;
	}

	return edd_recurring_get_subscription( $subscription_id );
}

/**
 * Trash a subscription.
 *
 * @since 2.13.0
 * @param int $subscription_id The subscription ID.
 * @return bool
 */
function edd_recurring_trash_subscription( $subscription_id ) {
	return edd_recurring_update_subscription(
		$subscription_id,
		array(
			'status' => 'trash',
		)
	);
}

/**
 * Gets a list of subscriptions from the database.
 *
 * @since 2.13.0
 * @param array $args Optional arguments.
 * @return array
 */
function edd_recurring_get_subscriptions( $args = array() ) {

	$args          = wp_parse_args(
		$args,
		array(
			'number' => 20,
		)
	);
	$subscriptions = new Subscription();

	return $subscriptions->query( $args );
}

/**
 * Counts the number of subscriptions in the database.
 *
 * @since 2.13.0
 * @param array $args Optional arguments.
 * @return int
 */
function edd_recurring_count_subscriptions( $args = array() ) {

	$args          = wp_parse_args(
		$args,
		array(
			'count' => true,
		)
	);
	$subscriptions = new Subscription( $args );

	return absint( $subscriptions->found_items );
}

/**
 * Adds a subscription to the database.
 *
 * @since 2.13.0
 * @param array $data {
 *    Array of subscription data.
 *    @type int    $customer_id
 *    @type string $period
 *    @type string $initial_amount
 *    @type string $initial_tax_rate
 *    @type string $initial_tax
 *    @type string $recurring_amount
 *    @type string $recurring_tax_rate
 *    @type string $recurring_tax
 *    @type string $bill_times
 *    @type string $transaction_id
 *    @type string $parent_payment_id
 *    @type string $product_id
 *    @type string $price_id
 *    @type string $created
 *    @type string $expiration
 *    @type string $trial_period
 *    @type string $status
 *    @type string $profile_id
 *    @type string $notes
 * }
 * @return int|false ID of the newly created subscription, or false on failure.
 */
function edd_recurring_add_subscription( $data = array() ) {
	$subscriptions = new Subscription();

	return $subscriptions->add_item( $data );
}

/**
 * Deletes a subscription from the database.
 *
 * @since 2.13.0
 * @param int $subscription_id The subscription ID.
 * @return bool
 */
function edd_recurring_delete_subscription( int $subscription_id ) {
	$subscriptions = new Subscription();
	$deleted       = $subscriptions->delete_item( $subscription_id );

	if ( ! $deleted ) {
		return false;
	}

	$notes = edd_get_notes(
		array(
			'object_id'   => $subscription_id,
			'object_type' => 'subscription',
			'number'      => 99999,
		)
	);

	foreach ( $notes as $note ) {
		edd_delete_note( $note->id );
	}

	return true;
}

/**
 * Updates a subscription in the database.
 *
 * @since 2.13.0
 * @param int   $subscription_id The subscription ID.
 * @param array $data            Array of subscription data.
 * @return bool
 */
function edd_recurring_update_subscription( int $subscription_id, $data = array() ) {
	$subscriptions = new Subscription();

	return $subscriptions->update_item( $subscription_id, $data );
}
