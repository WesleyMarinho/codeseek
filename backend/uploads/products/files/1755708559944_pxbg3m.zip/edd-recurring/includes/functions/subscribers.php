<?php
/**
 * EDD Recurring Subscriber Functions
 *
 * @package     EDD Recurring
 * @subpackage  Functions
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Gets a subscriber object.
 *
 * @since 2.12.3
 * @param string|int $id_or_email The user ID or email address.
 * @param bool       $by_user_id  Whether the ID is a user ID.
 *
 * @return EDD_Recurring_Subscriber|bool
 */
function edd_recurring_get_subscriber( $id_or_email, $by_user_id = false ) {
	if ( empty( $id_or_email ) ) {
		return false;
	}

	$cache_key  = md5( wp_json_encode( array( $id_or_email, $by_user_id ) ) );
	$subscriber = wp_cache_get( $cache_key, 'edd_recurring_subscriber', false, $found );

	if ( $found ) {
		return $subscriber;
	}

	$subscriber = new EDD_Recurring_Subscriber( $id_or_email, $by_user_id );

	if ( empty( $subscriber->id ) ) {
		$subscriber = false;
	}

	wp_cache_set( $cache_key, $subscriber, 'edd_recurring_subscriber', 5 * MINUTE_IN_SECONDS );

	return $subscriber;
}
