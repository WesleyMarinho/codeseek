<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $edd_recurring_stripe;

class EDD_Recurring_Stripe extends EDD_Recurring_Gateway {

	/**
	 * Gateway ID
	 *
	 * @var string
	 */
	public $id = 'stripe';

	/**
	 * Store \EDD_Payment object once retrieved.
	 *
	 * @since 2.9.0
	 * @deprecated 2.12.0
	 *
	 * @type \EDD_Payment
	 */
	private $payment;

	/**
	 * Ensures Easy Digital Downloads - Stripe Payment Gateway is active.
	 *
	 * @since unknown
	 */
	public function __construct() {
		if ( ! defined( 'EDDS_PLUGIN_DIR' ) ) {
			return;
		}

		parent::__construct();

		// Ensure Stripe 2.7.0+ is available.
		add_filter( 'edd_enabled_payment_gateways', array( $this, '_require_stripe_270' ), 20 );
		add_action( 'admin_notices', array( $this, '_require_stripe_270_notice' ) );
	}

	/**
	 * Registers gateway and hooks.
	 *
	 * @since unknown
	 */
	public function init() {
		if ( 'payment-elements' !== edds_get_elements_mode() ) {
			$this->supports[] = 'mixed_cart';
		}

		// Make sure the user is logged in if they are using an already existing user email.
		add_action( 'edds_pre_process_purchase_form', array( $this, 'require_login_for_existing_users' ) );

		// Watch for subscription payment method updates.
		add_action( 'wp_ajax_edd_recurring_update_subscription_payment_method', array( $this, 'update_subscription_payment_method' ) );
		add_action( 'wp_ajax_nopriv_edd_recurring_update_subscription_payment_method', array( $this, 'update_subscription_payment_method' ) );

		// Tell EDD Auto Register to log its newly-created user in.
		add_filter( 'edd_auto_register_login_user', array( $this, 'auto_register' ) );

		// Bail early if the \Stripe\Customer currency does not match the stores.
		add_action( 'edds_process_purchase_form_before_intent', array( $this, 'check_customer_currency' ), 10, 2 );

		// Purchase flow:

		// 0. Adjust \Stripe\PaymentIntent behavior for the parent \EDD_payment.
		add_filter( 'edds_create_payment_intent_args', array( $this, 'create_payment_intent_args' ), 10, 2 );

		// 1. Create \EDD_Subscription(s) on initial gateway processing.
		// 2. Create \Stripe\Subscription(s).
		// Remove any \EDD_Subscription(s) that no longer have a corresponding \Stripe\Subscription.
		$hook = 'edds_payment_created';
		if ( 'payment-elements' === edd_get_option( 'stripe_elements_mode', 'card-elements' ) ) {
			$hook = 'edds_order_created';
		}
		add_action( $hook, array( $this, 'process_purchase_form' ), 20, 2 );

		// 3. Capture original \Stripe\PaymentIntent using an amount equal to the number of \Stripe\Subscription(s) created.
		add_action( 'edds_capture_payment_intent', array( $this, 'capture_payment_intent' ) );

		// 4. Transition created \EDD_Subscriptions to their next status.
		add_action( 'edds_payment_complete', array( $this, 'complete_subscriptions' ) );

		add_action( 'edd_pre_refund_payment', array( $this, 'process_refund' ) );
		add_action( 'edd_recurring_stripe_check_txn', array( $this, 'check_transaction_id' ) );
		add_action( 'edd_recurring_setup_subscription', array( $this, 'maybe_check_subscription' ) );
		add_action( 'edd_subscription_completed', array( $this, 'cancel_on_completion' ), 10, 2 );

		// Ensure expiration date on renewal matches next invoice billing date.
		add_filter( 'edd_subscription_renewal_expiration', array( $this, 'set_renewal_expiration' ), 10, 3 );
		add_action( 'edd_recurring_setup_subscription', array( $this, 'check_renewal_expiration' ), 10, 1 );
	}

	/**
	 * Removes Stripe from active gateways if the base gateway < 2.7.0
	 *
	 * @since 2.9.0
	 *
	 * @param array $enabled_gateways Enabled gateways that allow purchasing.
	 * @return array
	 */
	public function _require_stripe_270( $enabled_gateways ) {
		if (
			isset( $enabled_gateways['stripe'] ) &&
			defined( 'EDD_STRIPE_VERSION' ) &&
			! version_compare( EDD_STRIPE_VERSION, '2.6.20', '>' )
		) {
			unset( $enabled_gateways['stripe'] );
		}

		return $enabled_gateways;
	}

	/**
	 * Adds notice if the base gateway < 2.7.0
	 *
	 * @since 2.9.0
	 */
	public function _require_stripe_270_notice() {
		remove_filter( 'edd_enabled_payment_gateways', array( $this, '_require_stripe_270' ), 20 );
		$enabled_gateways = edd_get_enabled_payment_gateways();
		add_filter( 'edd_enabled_payment_gateways', array( $this, '_require_stripe_270' ), 20 );

		if (
			isset( $enabled_gateways['stripe'] ) &&
			defined( 'EDD_STRIPE_VERSION' ) &&
			! version_compare( EDD_STRIPE_VERSION, '2.6.20', '>' )
		) {
			echo '<div class="notice notice-error">';

			echo wpautop(
				wp_kses(
					sprintf(
					/* translators: %1$s Opening strong tag, do not translate. %2$s Closing strong tag, do not translate. */
						__( '%1$sCredit card payments with Stripe are currently disabled.%2$s', 'edd-recurring' ),
						'<strong>',
						'</strong>'
					)
					. '<br />' .
					sprintf(
					/* translators: %1$s Opening code tag, do not translate. %2$s Closing code tag, do not translate. */
						__( 'To continue accepting recurring credit card payments with Stripe please update the Stripe Payment Gateway extension to version %1$s2.7%2$s.', 'edd-recurring' ),
						'<code>',
						'</code>'
					),
					array(
						'br'     => true,
						'strong' => true,
						'code'   => true,
					)
				)
			);

			echo '</div>';
		}
	}

	/**
	 * Require existing emails to log in prior to making a recurring purchase.
	 * This replaces the "require_login" function in the base gateway class because of
	 * some re-ordering which had to take place with PaymentIntents.
	 *
	 * @since 2.9.3
	 * @throws \Exception If a user account exists for the email in question and the user is logged out, throw an Exception.
	 * @return void
	 */
	public function require_login_for_existing_users() {

		$purchase_data = edd_get_purchase_session();

		if ( ! edd_recurring()->is_purchase_recurring( $purchase_data ) ) {
			return;
		}

		// Check if this email is already attached to a WP user.
		if ( email_exists( $purchase_data['user_email'] ) ) {
			// Check if the user exists and is not logged in.
			if ( ! is_user_logged_in() ) {
				/* translators: %1$s Email address of an existing account used during checkout. */
				throw new \Exception( sprintf( __( 'A customer account for %1$s already exists. Please log in to complete your purchase.', 'edd-recurring' ), esc_html( $purchase_data['user_email'] ) ) );
			}
		}
	}

	// Override methods that are automatically called in the parent class.
	public function process_checkout( $purchase_data ) {}
	public function complete_signup() {}
	public function create_payment_profiles() {}
	public function record_signup() {}

	/**
	 * Ensure subsequent API requests use the correct information.
	 *
	 * @since 2.9.0
	 */
	public function setup_stripe_api() {
		_doing_it_wrong(
			__METHOD__,
			__( 'Use edds_api_request() to make Stripe API requests.', 'edd-recurring' ),
			'2.10.0'
		);
	}

	/**
	 * Tell Auto Register to log the user in.
	 *
	 * @since  2.9.0
	 * @param  bool $should_log_in_user This indicates whether the user should be automatically logged in when their user is created by EDD Auto Register.
	 * @return bool
	 */
	public function auto_register( $should_log_in_user ) {

		// If this is a manual payment, do not log the newly created user in, as it would just switch from the admin to the customer user.
		if ( isset( $_POST['manual_purchases'] ) ) { //phpcs:ignore WordPress.Security.NonceVerification.Missing
			return $should_log_in_user;
		}

		$purchase_data = edd_get_purchase_session();
		if ( empty( $purchase_data['gateway'] ) || $this->id !== $purchase_data['gateway'] ) {
			return $should_log_in_user;
		}

		if ( ! edd_recurring()->is_purchase_recurring( $purchase_data ) ) {
			return $should_log_in_user;
		}

		return true;
	}

	/**
	 * Check the customer currency prior to allowing checkout.
	 *
	 * If a customer has previously purchased a subscription, any future subscriptions must be made in the same currency.
	 *
	 * @since 2.9.0
	 * @throws \Exception If the Stripe customer currency does not match the currency attempting to checkout, throw an Exception.
	 *
	 * @param array            $purchase_data Purchase data.
	 * @param \Stripe\Customer $customer Stripe Customer object.
	 */
	public function check_customer_currency( $purchase_data, $customer ) {
		if ( ! edd_recurring()->is_purchase_recurring( $purchase_data ) ) {
			return;
		}

		// First purchase, \Stripe\Customer has not taken an action that assigns
		// a currency, so any currency purchase can be made.
		if ( ! $customer->currency ) {
			return;
		}

		$store_currency    = strtolower( edd_get_currency() );
		$customer_currency = strtolower( $customer->currency );

		if ( $customer_currency !== $store_currency ) {
			throw new \Exception(
				sprintf(
					/* translators: %1$s Customer currency. */
					__( 'Unable to complete your purchase. Your order must be completed in %1$s.', 'edd-recurring' ),
					strtoupper( $customer->currency )
				)
			);
		}
	}

	/**
	 * Sets the PaymentIntent capture method to manual.
	 *
	 * Creating \Stripe\Subscriptions can fail individually.
	 * Capturing after all attempts have been made ensures we only charge
	 * for fulfilled items.
	 *
	 * @since 2.9.0
	 *
	 * @param array $payment_intent_args PaymentIntent creation arguments.
	 * @param array $purchase_data       Cart purchase data.
	 * @return array
	 */
	public function create_payment_intent_args( $payment_intent_args, $purchase_data ) {
		if ( edd_recurring()->is_purchase_recurring( $purchase_data ) ) {
			$payment_intent_args['capture_method'] = 'manual';
		}

		return $payment_intent_args;
	}

	/**
	 * Handles creating EDD_Subscription and \Stripe\Subscription records
	 * on checkout form submission.
	 *
	 * @since 2.9.0
	 *
	 * @param array                                     $purchase_data    Purchase data.
	 * @param \EDD\Orders\Order|\EDD_Payment            $order_or_payment The order or payment object.
	 * @param \Stripe\PaymentIntent|\Stripe\SetupIntent $intent           Created Stripe Intent.
	 */
	public function process_purchase_form( $order_or_payment, $intent ) {
		$purchase_data = edd_get_purchase_session();

		if ( ! edd_recurring()->is_purchase_recurring( $purchase_data ) ) {
			return;
		}

		// Store for direct access later.
		$this->payment_id    = $order_or_payment->ID;
		$this->purchase_data = $purchase_data;

		$this->purchase_data = apply_filters( 'edd_recurring_purchase_data', $purchase_data, $this );
		$this->user_id       = $this->purchase_data['user_info']['id'];
		$this->email         = $this->purchase_data['user_info']['email'];

		// Never let a user_id be lower than 0 since WP Core absints when doing get_user_meta lookups
		if ( $this->purchase_data['user_info']['id'] < 1 ) {
			$this->purchase_data['user_info']['id'] = 0;
		}

		do_action( 'edd_recurring_process_checkout', $this->purchase_data, $this );

		$errors = edd_get_errors();

		// Throw an exception with the latest error (for backwards compat with `edd_recurring_process_checkout`).
		if ( $errors ) {
			throw new \Exception( current( edd_get_errors() ) );
		}

		// Use cart purchase data to find EDD_Customer and EDD_Recurring_Subscriber.
		$this->setup_customer_subscriber();

		// Map cart purchase data to gateway object (this).
		$this->build_subscriptions();

		// Use mapped data to create EDD_Subscription records.
		$this->create_edd_subscriptions();

		// Save any custom meta added via hooks.
		edd_update_order_meta( $this->payment_id, '_edd_subscription_payment', true );

		if ( ! empty( $this->custom_meta ) ) {
			foreach ( $this->custom_meta as $key => $value ) {
				edd_update_order_meta( $this->payment_id, $key, $value );
			}
		}

		// Use mapped data to create \Stripe\Subscription records.
		$this->create_stripe_subscriptions( $intent );
	}

	/**
	 * Creates EDD_Subscription records.
	 *
	 * @todo This is not gateway-specific and can be moved up.
	 */
	public function create_edd_subscriptions() {
		/*
		 * We need to delete pending subscription records to prevent duplicates. This ensures no duplicate subscription records are created when a purchase is being recovered. See:
		 * https://github.com/easydigitaldownloads/edd-recurring/issues/707
		 * https://github.com/easydigitaldownloads/edd-recurring/issues/762
		 */
		global $wpdb;

		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}edd_subscriptions WHERE parent_payment_id = %d AND status = 'pending';", $this->payment_id ) );

		// Now create the subscription record(s).
		foreach ( $this->subscriptions as $key => $subscription ) {

			$status = 'pending';
			if ( isset( $subscription['status'] ) ) {
				$status = $subscription['status'];
			}

			$trial_period = ! empty( $subscription['has_trial'] ) ? $subscription['trial_quantity'] . ' ' . $subscription['trial_unit'] : '';
			$expiration   = $this->subscriber->get_new_expiration( $subscription['id'], $subscription['price_id'], $trial_period );

			// Check and see if we have a custom recurring period from the Custom Prices extension.
			if ( defined( 'EDD_CUSTOM_PRICES' ) ) {

				$cart_item = $this->purchase_data['cart_details'][ $subscription['cart_index'] ];

				if ( isset( $cart_item['item_number']['options']['custom_price'] ) ) {
					switch ( $subscription['period'] ) {

						case 'quarter':
							$period = '+ 3 months';

							break;

						case 'semi-year':
							$period = '+ 6 months';

							break;

						default:
							$period = '+ 1 ' . $subscription['period'];

							break;

					}

					$expiration = date( 'Y-m-d H:i:s', strtotime( $period . ' 23:59:59', current_time( 'timestamp' ) ) );
				}
			}

			$args = array(
				'product_id'         => $subscription['id'],
				'price_id'           => isset( $subscription['price_id'] ) ? $subscription['price_id'] : null,
				'user_id'            => $this->purchase_data['user_info']['id'],
				'parent_payment_id'  => $this->payment_id,
				'status'             => $status,
				'period'             => $subscription['period'],
				'initial_amount'     => $subscription['initial_amount'],
				'initial_tax_rate'   => $subscription['initial_tax_rate'],
				'initial_tax'        => $subscription['initial_tax'],
				'recurring_amount'   => $subscription['recurring_amount'],
				'recurring_tax_rate' => $subscription['recurring_tax_rate'],
				'recurring_tax'      => $subscription['recurring_tax'],
				'bill_times'         => $subscription['bill_times'],
				'expiration'         => $expiration,
				'trial_period'       => $trial_period,
				'profile_id'         => $subscription['profile_id'],
				'transaction_id'     => $subscription['transaction_id'],
				'gateway'            => $this->id,
			);

			$args = apply_filters( 'edd_recurring_pre_record_signup_args', $args, $this );

			$sub = $this->subscriber->add_subscription( $args );

			if ( ! $this->offsite && $trial_period ) {
				$this->subscriber->add_meta( 'edd_recurring_trials', $subscription['id'] );
			}

			// Track newly created \EDD_Subscription in the gateway object.
			$this->subscriptions[ $key ]['edd_subscription'] = $sub;

			/**
			 * Triggers right after a subscription is created.
			 *
			 * @param EDD_Subscription      $sub          New subscription object.
			 * @param array                 $subscription Gateway subscription arguments.
			 * @param EDD_Recurring_Gateway $this         Gateway object.
			 *
			 * @since 2.10.2
			 */
			do_action( 'edd_recurring_post_record_signup', $sub, $subscription, $this );
		}
	}

	/**
	 * Creates \Stripe\Subscription records.
	 *
	 * @since 2.9.0
	 *
	 * @param \Stripe\PaymentIntent Stripe PaymentIntent, used to retrieve the parent \EDD_Payment
	 */
	public function create_stripe_subscriptions( $intent ) {
		/** This action is documented in incldues/gateways/edd-recurring-gateway.php */
		do_action( 'edd_recurring_pre_create_payment_profiles', $this );

		// Retrieve the \Stripe\Customer used to create the \Stripe\PaymentIntent.
		//
		// Could use ID directly to avoid another API request, however
		// the full object is needed for the `edd_recurring_create_stripe_subscription_args`
		// filter below.
		$customer = $this->get_customer( $intent->customer );

		// Sync the gateway's recurring customer ID with the subscriber.
		$this->subscriber->set_recurring_customer_id( $customer->id, $this->id );

		// Ensure that one-time purchases through Stripe use the same customer ID.
		update_user_meta( $this->user_id, edd_stripe_get_customer_key(), $customer->id );
		$this->subscriber->update_meta( edd_stripe_get_customer_key(), $customer->id );

		foreach ( $this->subscriptions as $key => $subscription ) {
			try {
				$plan_details = $this->get_stripe_plan( $subscription );

				$args = array(
					'customer'               => $customer->id,
					'default_payment_method' => $intent->payment_method,
					'off_session'            => true,
					'items'                  => array(
						array(
							'plan'     => $plan_details->id,
							'quantity' => 1,
						),
					),
					'metadata'               => array(
						'payment_key'         => $this->purchase_data['purchase_key'],
						'download'            => $subscription['name'],
						'download_id'         => $subscription['id'],
						'price_id'            => $subscription['price_id'],
						'caller'              => __CLASS__ . '|' . __METHOD__ . '|' . __LINE__ . '|' . EDD_RECURRING_VERSION,
						'edd_subscription_id' => $subscription['edd_subscription']->id ?? '',
					),
				);

				if ( ! empty( $subscription['has_trial'] ) ) {
					$args['trial_end'] = strtotime( '+' . $subscription['trial_quantity'] . ' ' . $subscription['trial_unit'] );
					$set_anchor        = false;
				} else {
					$args['billing_cycle_anchor'] = $this->get_billing_cycle_anchor( $subscription );
					$args['prorate']              = false;
					$set_anchor                   = true;
				}

				/**
				 * Filters the arguments used to create all Recurring subscriptions.
				 *
				 * @since unknown
				 *
				 * @param array  $args       Arguments used to create the gateway-specific Subscription record.
				 * @param array  $downloads  Cart downloads.
				 * @param string $id         Gateway ID.
				 * @param string $product_id Download ID.
				 * @param string $price_id   Download price ID.
				 */
				$args = apply_filters(
					'edd_recurring_create_subscription_args',
					$args,
					$this->purchase_data['downloads'],
					$this->id,
					$subscription['id'],
					$subscription['price_id']
				);

				/**
				 * Filters the arguments used to create \Stripe\Subscription records.
				 *
				 * @since unknown
				 *
				 * @param array  $args      Arguments used to create the \Stripe\Subscription.
				 * @param array  $downloads Cart downloads.
				 * @param string $id        Gateway ID.
				 * @param \Stripe\Customer  Stripe customer.
				 */
				$args = apply_filters(
					'edd_recurring_create_stripe_subscription_args',
					$args,
					$this->purchase_data,
					$customer
				);

				// Avoid sending unnecessary parameters to Stripe.
				if ( ! empty( $args['needs_one_time'] ) ) {
					unset( $args['needs_one_time'] );
					unset( $args['license_id'] );
				}

				/*
				 * If we have a `billing_cycle_anchor` AND a `trial_end`, then we need to unset whichever one
				 * we set, and leave the customer's custom one in tact.
				 *
				 * This is done to account for people who filter the arguments to customize the next bill
				 * date. If `trial_end` is used in conjunction with `billing_cycle_anchor` then it will create
				 * unexpected results and the next bill date will not be what they want.
				 *
				 * This may not be completely perfect but it's the best way to try to account for any errors.
				 */
				if ( ! empty( $args['trial_end'] ) && ! empty( $args['billing_cycle_anchor'] ) ) {
					// If we set an anchor, remove that, because this means the customer has set their own `trial_end`.
					if ( $set_anchor ) {
						unset( $args['billing_cycle_anchor'] );
					} else {
						// We set a trial, which means the customer has set their own `billing_cycle_anchor`.
						unset( $args['trial_end'] );
					}
				}

				$stripe_subscription = edds_api_request( 'Subscription', 'create', $args );
				$update_args         = array(
					'profile_id' => $stripe_subscription->id,
				);

				// Set the EDD expiration to match the Stripe subscription.
				if ( ! empty( $stripe_subscription->current_period_end ) ) {
					$update_args['expiration'] = date( 'Y-m-d', $stripe_subscription->current_period_end ) . ' 23:59:59';
				}
				$subscription['edd_subscription']->update( $update_args );

				wp_schedule_single_event( strtotime( '+2 minutes' ), 'edd_recurring_stripe_check_txn', array( $stripe_subscription->id ) );

				if ( ! empty( $subscription['has_trial'] ) ) {
					$order_item_args = array(
						'order_id'   => $this->payment_id,
						'cart_index' => $key,
						'product_id' => $subscription['id'],
					);
					// Due to limitations with Berlin, we can't query for a null price_id.
					if ( ! is_null( $subscription['price_id'] ) ) {
						$order_item_args['price_id'] = $subscription['price_id'];
					}
					$order_items = edd_get_order_items( $order_item_args );
					$order_item  = reset( $order_items );
					edd_update_order_item(
						$order_item->id,
						array(
							'amount'   => 0,
							'subtotal' => 0,
							'tax'      => $subscription['initial_tax'],
							'discount' => 0,
							'total'    => 0,
						)
					);
					edd_update_order(
						$this->payment_id,
						array(
							'tax'      => 0,
							'total'    => 0,
							'subtotal' => 0,
						)
					);
				}

				// Note any Subscription failures.
			} catch ( \Exception $e ) {
				$this->failed_subscriptions[] = array(
					'key'          => $key,
					'error'        => $e->getMessage(),
					'subscription' => $subscription,
				);
			}
		}

		// Clean up subscriptions.
		foreach ( $this->failed_subscriptions as $failed_subscription ) {
			// Change the status of the subscription to on_hold.
			$failed_subscription['subscription']['edd_subscription']->update(
				array(
					'status' => 'needs_attention',
				)
			);
			edd_add_note(
				array(
					'object_id'   => $this->payment_id,
					'object_type' => 'order',
					'content'     => sprintf(
						/* translators: 1. Subscription name, 2. Error message. */
						__( 'Failed creating subscription for %1$s. Gateway returned: %2$s', 'edd-recurring' ),
						$failed_subscription['subscription']['name'],
						$failed_subscription['error']
					),
				)
			);
		}

		if ( ! empty( $this->failed_subscriptions ) ) {
			edd_update_order_meta( $this->payment_id, '_edd_recurring_failed_subscriptions', $this->failed_subscriptions );
		} else {
			edd_delete_order_meta( $this->payment_id, '_edd_recurring_failed_subscriptions' );
		}

		/** This action is documented in incldues/gateways/edd-recurring-gateway.php */
		do_action( 'edd_recurring_post_create_payment_profiles', $this );
	}

	/**
	 * Adjusts the capture amount for the \Stripe\PaymentIntent and captures.
	 *
	 * The parent \EDD_Payment record's current total is used to
	 * determine the amount that is captured.
	 *
	 * @since 2.9.0
	 *
	 * @param \Stripe\PaymentIntent $intent PaymentIntent to capture.
	 */
	public function capture_payment_intent( $intent ) {
		$order_id = $intent->metadata->edd_payment_id;
		$order    = edd_get_order( $order_id );

		if ( edds_is_zero_decimal_currency() ) {
			$amount = round( $order->total, 0 );
		} else {
			$amount = round( $order->total * 100, 0 );
		}

		// Capture amount must be positive (and over $0.50).
		// No Subscriptions were left on the Parent Payment Record.
		//
		// The cart is also manually cleared here to avoid confusion.
		if ( 0 === intval( $amount ) ) {
			$intent->cancel(
				array(
					'cancellation_reason' => 'abandoned',
				)
			);

			edd_add_note(
				array(
					'object_type' => 'order',
					'object_id'   => $order->id,
					'content'     => esc_html__( 'PaymentIntent cancelled because there is nothing to collect.', 'edd-recurring' ),
				)
			);

			edd_empty_cart();
			return;
		}

		return $intent->capture(
			array(
				'amount_to_capture' => $amount,
			)
		);
	}

	/**
	 * Transitions \EDD_Subscription records to their next status when
	 * the parent \EDD_Payment record is transitioned.
	 *
	 * @since 2.9.0
	 * @param \EDD_Payment $parent_payment Parent payment.
	 */
	public function complete_subscriptions( $parent_payment ) {
		$purchase_data = edd_get_purchase_session();
		if ( ! edd_recurring()->is_purchase_recurring( $purchase_data ) ) {
			return;
		}

		$subscription_db = new EDD_Subscriptions_DB();
		$subscriptions   = $subscription_db->get_subscriptions(
			array(
				'parent_payment_id' => $parent_payment->ID,
				'status'            => 'pending',
			)
		);

		if ( empty( $subscriptions ) ) {
			return;
		}

		foreach ( $subscriptions as $subscription ) {
			$updated = $subscription->update(
				array(
					'status' => empty( $subscription->trial_period ) ? 'active' : 'trialling',
				)
			);

			if ( $updated ) {
				$subscription->add_note( __( 'Subscription activated during purchase.', 'edd-recurring' ) );
			}
		}
	}

	/**
	 * Processes webhooks from the payment processor.
	 *
	 * @since 2.4
	 * @return void
	 */
	public function process_webhooks() {

		$listener = filter_input( INPUT_GET, 'edd-listener', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( $this->id !== $listener ) {
			return;
		}

		$event = EDD\Recurring\Gateways\Stripe\Webhooks\Event::get();
		if ( ! $event || empty( $event->id ) ) {
			return;
		}

		$listener = new EDD\Recurring\Gateways\Stripe\Webhooks\Listener( $event );
		$listener->process();
	}

	/**
	 * Retrieve the customer object from Stripe.
	 *
	 * @since 2.4
	 * @since 2.9.0 All payments go through the base Stripe gateway ensuring a
	 *              customer record is associated with each user.
	 *
	 * @param string $customer_id Optional \Stripe\Customer ID. If not supplied the current user record will be used.
	 * @return null|\Stripe\Customer Null if a saved customer ID reference cannot be found.
	 */
	public function get_customer( $customer_id = null ) {
		$customer = null;

		if ( ! $customer_id ) {
			$customer_id = edds_get_stripe_customer_id( get_current_user_id() );
		}

		if ( ! empty( $customer_id ) ) {
			try {
				$customer = edds_api_request( 'Customer', 'retrieve', $customer_id );
			} catch ( \Exception $e ) {
				$customer = null;
			}
		}

		return $customer;
	}

	/**
	 * Backfills missing subscription data.
	 *
	 * This runs when a renewal payment is processed in Stripe for a subscription that is
	 * missing the profile_id field. This happens occassionally with subscriptions created
	 * pre Recurring Payments 2.4
	 *
	 * @access      public
	 * @since       2.4
	 * @return      object EDD_Subscription
	 */
	public function backfill_subscription( $customer_id = '', $subscription_id = '' ) {

		$subscription = false;

		try {
			// Update the customer to ensure their card data is up to date
			$customer   = edds_api_request( 'Customer', 'retrieve', $customer_id );
			$stripe_sub = edds_api_request( 'Subscription', 'retrieve', $subscription_id );

			if ( ! empty( $stripe_sub->plan->product ) ) {
				$product   = edds_api_request( 'Product', 'retrieve', $stripe_sub->plan->product );
				$plan_name = $product->name;
			} else {
				$plan_name = $stripe_sub->plan->name;
			}

			// Look up payment by email
			$payments = edd_get_payments(
				array(
					's'      => $customer->email,
					'status' => 'publish',
					'number' => 100,
					'output' => 'payments',
				)
			);

			// echo '<pre>';print_r( $payments );echo '</pre>';

			if ( $payments ) {

				foreach ( $payments as $payment ) {

					if ( ! is_array( $payment->cart_details ) ) {

						continue;

					}

					if ( ! edd_get_payment_meta( $payment->ID, '_edd_subscription_payment', true ) ) {

						continue;

					}

					foreach ( $payment->cart_details as $download ) {

						$slug = get_post_field( 'post_name', $download['id'] );

						if ( $slug != $plan_name ) {
							continue;
						}

						// We have found a matching subscription, let's look up the sub record and fix it
						$subs_db = new EDD_Subscriptions_DB();
						$subs    = $subs_db->get_subscriptions( array( 'parent_payment_id' => $payment->ID ) );
						$sub     = reset( $subs );

						if ( $sub && $sub->id > 0 ) {

							$sub->update( array( 'profile_id' => $subscription_id ) );

							$subscription = $sub;

							break;

						}
					}
				}
			}

			// No customer found
		} catch ( Exception $e ) {

		}

		return $subscription;
	}

	/**
	 * Retrieve the plan ID for an item in the cart
	 *
	 * @access      public
	 * @since       2.4
	 * @param       array $subscription The EDD Subscription data in question.
	 * @return      int|false
	 */
	public function get_plan_id( $subscription = array() ) {
		$plan    = $this->get_stripe_plan( $subscription );
		$plan_id = false !== $plan ? $plan->id : false;

		return $plan_id;
	}

	/**
	 * Retrieve the stripe Plan details. It also creates a plan if none is found that matches.
	 *
	 * @access      public
	 * @since       2.9.6
	 * @param       array $subscription The EDD Subscription data in question.
	 * @return      \Stripe\Plan|false Stripe Plan object or false if one cannot be created or retrieved.
	 */
	public function get_stripe_plan( $subscription = array() ) {

		$name = get_post_field( 'post_name', $subscription['id'] );

		if ( isset( $subscription['price_id'] ) && false !== $subscription['price_id'] ) {

			$name .= ' - ' . edd_get_price_option_name( $subscription['id'], $subscription['price_id'] );

		}

		$plan_id = $name . '_' . $subscription['recurring_amount'] . '_' . $subscription['period'];
		/**
		 * Allows the Stripe Plan ID to be modified.
		 * By default the Plan ID is formed by concatenating the Download name, recurring amount, and recurring billing period.
		 * Changing the Plan ID will cause a new Product and Plan to be created in Stripe and all purchases moving forward will be attributed to the new Plan.
		 *
		 * @since 2.10.3
		 * @param string $plan_id      The ID of the Plan in Stripe. Must be unique across all Plans in your Stripe account.
		 * @param array  $subscription The array of subscription data.
		 */
		$plan_id = sanitize_key( apply_filters( 'edd_recurring_stripe_plan_id', $plan_id, $subscription ) );

		try {
			$plan     = edds_api_request( 'Plan', 'retrieve', $plan_id );
			$currency = strtolower( edd_get_currency() );

			if ( $plan->currency !== $currency ) {

				$plan_id = $plan_id . '_' . $currency;
				$args    = $this->get_plan_args( $subscription, $name, $plan_id );

				try {

					$plan = edds_api_request( 'Plan', 'retrieve', $plan_id );

				} catch ( Exception $e ) {

					$plan = $this->create_stripe_plan( $args );

				}
			}
		} catch ( Exception $e ) {

			$args = $this->get_plan_args( $subscription, $name, $plan_id );
			$plan = $this->create_stripe_plan( $args );

		}

		return $plan;
	}

	/**
	 * Build the argument array for creating a plan in Stripe
	 *
	 * @since 2.7
	 * @param array  $subscription
	 * @param string $name
	 * @param string $plan_id
	 *
	 * @return array
	 */
	public function get_plan_args( $subscription, $name, $plan_id = '' ) {
		$statement_descriptor   = $name;
		$unsupported_characters = array( '<', '>', '"', '\'' );
		$statement_descriptor   = apply_filters( 'edd_recurring_stripe_statement_descriptor', substr( $statement_descriptor, 0, 22 ), $subscription );
		$statement_descriptor   = str_replace( $unsupported_characters, '', $statement_descriptor );

		switch ( $subscription['period'] ) {

			case 'quarter':
				$frequency = 3;
				$period    = 'month';
				break;

			case 'semi-year':
				$frequency = 6;
				$period    = 'month';
				break;

			default:
				$frequency = 1;
				$period    = $subscription['period'];
				break;

		}

		$amount = $subscription['recurring_amount'];
		/**
		 * Stripe requires the amount to be in a number of 'cents' in the currency.
		 * Additionally, Stripe uses a different list of "zero decimal" currencies
		 * than EDD core, so whether the amount should be converted uses that logic.
		 */
		if ( ! edds_is_zero_decimal_currency() ) {
			$amount = round( $amount * 100, 0 );
		}

		$args = array(
			'amount'               => $amount,
			'interval'             => $period,
			'interval_count'       => $frequency,
			'currency'             => edd_get_currency(),
			'name'                 => $name,
			'id'                   => $plan_id,
			'statement_descriptor' => $statement_descriptor,
			'metadata'             => array(
				'caller' => __CLASS__ . '|' . __METHOD__ . '|' . __LINE__ . '|' . EDD_RECURRING_VERSION,
			),
		);

		/**
		 * Stripe plan arguments.
		 * Allows filtering of the arguments that are sent to Stripe when creating the plan.
		 *
		 * @since 2.4
		 *
		 * @param array $args {
		 *     The plan arguments that will be sent to Stripe.
		 *     int    $amount         The amount that will be charged for the plan.
		 *     string $interval       The period at which the plan will renew at.
		 *     int    $interval_count The frequency at which the plan will renew.
		 *     string $name           The human readable name for the plan.
		 *     string $currency       The currency for the plan.
		 *     string $id             The string identifier for the plan in Stripe.
		 *     string $statement_descriptor The value that will show on a customer's financial institution for charges of this plan.
		 * }
		 * @param array $subscription
		 */
		return apply_filters( 'edd_recurring_create_stripe_plan_args', $args, $subscription );
	}

	/**
	 * Creates a plan in Stripe and returns the plan ID
	 *
	 * @access  public
	 * @since   2.4
	 * @param   array $args The values to use when creating the Stripe Plan.
	 * @return  \Stripe\Plan|false
	 */
	private function create_stripe_plan( $args = array() ) {

		/*
		 * If we're using API version 2018-02-05 or greater, create a product
		 *
		 * See https://github.com/easydigitaldownloads/edd-recurring/issues/925
		 */

		try {

			$id = md5( serialize( $args ) );

			$product = edds_api_request( 'Product', 'retrieve', $id );

		} catch ( Exception $e ) {

			// No product found, create one

			$product = edds_api_request(
				'Product',
				'create',
				array(
					'id'                   => $id,
					'name'                 => $args['name'],
					'type'                 => 'service',
					'statement_descriptor' => $args['statement_descriptor'],
					'metadata'             => array(
						'caller' => __CLASS__ . '|' . __METHOD__ . '|' . __LINE__ . '|' . EDD_RECURRING_VERSION,
					),
				)
			);

		}

		try {

			if ( ! empty( $product ) ) {

				$args['product'] = $product;

				if ( isset( $args['name'] ) ) {

					unset( $args['name'] );

				}

				if ( isset( $args['statement_descriptor'] ) ) {

					unset( $args['statement_descriptor'] );

				}
			}

			$plan = edds_api_request( 'Plan', 'create', $args );

		} catch ( Exception $e ) {

			$plan = false;

		}

		return $plan;
	}

	/**
	 * Returns a timestamp for a Subscription's biling cycle anchor point.
	 *
	 * @since 2.9.7
	 *
	 * @link https://github.com/easydigitaldownloads/edd-recurring/issues/1268
	 * @link https://stripe.com/docs/billing/subscriptions/billing-cycle
	 *
	 * @param array    $subscription Subscription arguments.
	 * @param null|int $now          Starting point for determining the current calendar positions.
	 *                               Default time()
	 * @return int Timestamp.
	 */
	public function get_billing_cycle_anchor( $subscription, $now = null ) {
		$anchor = null;

		if ( null === $now ) {
			$now = time();
		}

		$day     = date( 'j', $now );
		$month   = date( 'n', $now );
		$year    = date( 'Y', $now );
		$hours   = date( 'G', $now );
		$minutes = date( 'i', $now );
		$seconds = date( 's', $now );

		if ( in_array( $subscription['period'], array( 'day', 'week' ), true ) ) {
			$anchor = strtotime( sprintf( '+1 %s', $subscription['period'] ) );
		} else {
			switch ( $subscription['period'] ) {
				case 'month':
					$month = $month + 1;
					break;
				case 'quarter':
					$month = $month + 3;
					break;
				case 'semi-year':
					$month = $month + 6;
					break;
				case 'year':
					$year = $year + 1;
					break;
			}

			// If the month count goes beyond 12 (the current year) roll over
			// to the next year and find the appropriate month.
			//
			// mktime() accepts month counts above 12 but the year would still
			// be anchored in the current year.
			if ( $month > 12 ) {
				$year  = $year + 1;
				$month = $month - 12;
			}

			// This is a real date, use it as the anchor.
			if ( true === checkdate( $month, $day, $year ) ) {
				$anchor = strtotime( sprintf( '%s-%s-%s %s:%s:%s', $year, $month, $day, $hours, $minutes, $seconds ) );
			} else {
				$anchor = strtotime( sprintf( '%s:%s:%s last day of %s %s', $hours, $minutes, $seconds, date( 'F', mktime( 0, 0, 0, $month, 1, $year ) ), $year ) );
			}
		}

		/**
		 * Account for innacurate server clocks to prevent
		 * "billing_cycle_anchor cannot be later than next natural billing date" errors.
		 *
		 * @link https://github.com/easydigitaldownloads/edd-recurring/issues/1345
		 */
		$offset = apply_filters( 'edd_recurring_stripe_billing_cycle_anchor_offset', MINUTE_IN_SECONDS / 4 );

		return $anchor - $offset;
	}

	/**
	 * Matches the Subscription's expiration date with Stripe's renewal date.
	 *
	 * @since 2.9.7
	 *
	 * @param int              $expiration Renewal expiration timestamp.
	 * @param int              $subscription_id ID of the current Subscription.
	 * @param EDD_Subscription $subscription Current subscription.
	 * @return int Renewal expiration timestamp.
	 */
	public function set_renewal_expiration( $expiration, $subscription_id, $subscription ) {
		if ( $this->id !== $subscription->gateway ) {
			return $expiration;
		}

		try {
			$stripe_sub = edds_api_request( 'Subscription', 'retrieve', $subscription->profile_id );

			/**
			 * Since Stripe can process a renewal charge roughly 1 hour after the expiration of a subscription,
			 * we should account for this as subscription renewal payments are not immediately collected, but they are
			 * immediately invoiced, and charged later.
			 *
			 * @see https://stripe.com/docs/billing/lifecycle#subscription-lifecycle
			 */
			$stripe_sub_expiration = $stripe_sub->current_period_end + ( HOUR_IN_SECONDS * 1.5 );
			$expiration            = date( 'Y-m-d H:i:s', $stripe_sub_expiration );
		} catch ( \Exception $e ) {
			// Do nothing, use original value.
		}

		return $expiration;
	}

	/**
	 * Fixes an issue in subscriptions that got the incorrect expiration date.
	 *
	 * @see https://github.com/easydigitaldownloads/edd-recurring/pull/1281
	 * @since 2.9.8
	 *
	 * @param $sub EDD_Subscription
	 */
	public function check_renewal_expiration( $sub ) {
		if ( 'stripe' === $this->id && '0000-00-00 00:00:00' === $sub->expiration ) {
			$sub->check_expiration();
		}
	}

	/**
	 * Determines if the subscription can be cancelled
	 *
	 * @access      public
	 * @since       2.4
	 * @return      bool
	 */
	public function can_cancel( $ret, $subscription ) {
		if ( 'stripe' !== $subscription->gateway ) {
			return $ret;
		}

		return ! empty( $subscription->profile_id ) && in_array( $subscription->status, $this->get_cancellable_statuses(), true );
	}

	/**
	 * Cancels a subscription at period end, unless the status of the subscription is failing. If failing, cancel immediately.
	 *
	 * @access      public
	 * @since       2.4
	 * @param       EDD_Subscription $subscription The EDD Subscription object being cancelled.
	 * @param       bool             $valid Currently this defaults to be true at all times.
	 * @return      bool
	 */
	public function cancel( $subscription, $valid ) {

		if ( empty( $valid ) ) {
			return false;
		}

		try {
			// Before we cancel, lets make sure this subscription exists at Stripe.
			$stripe_subscription = edds_api_request( 'Subscription', 'retrieve', $subscription->profile_id );

			if ( in_array( $stripe_subscription->status, array( 'canceled', 'unpaid' ), true ) ) {
				return false;
			}

			if ( ! in_array( $stripe_subscription->status, array( 'past_due', 'void' ), true ) ) {
				$stripe_subscription = edds_api_request(
					'Subscription',
					'update',
					$subscription->profile_id,
					array(
						'cancel_at_period_end' => true,
					)
				);
			} else {
				$stripe_subscription->cancel();
			}

			// We must now loop through and cancel all unpaid invoice to ensure that additional payment attempts are not made.
			$invoices = edds_api_request(
				'Invoice',
				'all',
				array(
					'subscription' => $subscription->profile_id,
					'status'       => 'open',
				)
			);

			if ( $invoices ) {

				foreach ( $invoices->data as $invoice ) {

					// Skip paid invoices.
					if ( $invoice->paid ) {
						continue;
					}

					$invoice->voidInvoice();
				}
			}
		} catch ( Exception $e ) {
			// Translators: The error message from Stripe.
			$subscription->add_note( sprintf( esc_html__( 'Attempted cancellation but was unable. Message was %s.', 'edd-recurring' ), wp_json_encode( $e->getMessage() ) ) );
			$subscription->update(
				array(
					'status' => 'needs_attention',
				)
			);
			return false;
		}

		$subscription->add_note( esc_html__( 'The subscription was cancelled at Stripe.', 'edd-recurring' ) );

		return true;
	}

	/**
	 * Cancels a subscription immediately.
	 *
	 * @access      public
	 * @since       2.9.4
	 * @param       EDD_Subscription $subscription The EDD Subscription object being cancelled.
	 * @return      bool
	 */
	public function cancel_immediately( $subscription ) {

		if ( ! in_array( $subscription->status, $this->get_cancellable_statuses(), true ) ) {
			return false;
		}

		try {
			$sub = edds_api_request( 'Subscription', 'retrieve', $subscription->profile_id );
			$sub->cancel();

			// We must now loop through and cancel all unpaid invoice to ensure that additional payment attempts are not made.
			$invoices = edds_api_request(
				'Invoice',
				'all',
				array(
					'subscription' => $subscription->profile_id,
					'status'       => 'open',
				)
			);

			if ( $invoices ) {

				foreach ( $invoices->data as $invoice ) {

					// Skip paid invoices.
					if ( $invoice->paid ) {
						continue;
					}

					$invoice->voidInvoice();
				}
			}
		} catch ( Exception $e ) {
			// Translators: The error message from Stripe.
			$subscription->add_note( sprintf( esc_html__( 'Attempted cancellation but was unable. Message was %s.', 'edd-recurring' ), wp_json_encode( $e->getMessage() ) ) );
			return false;
		}

		edd_recurring_delete_subscription_meta( $subscription->id, 'cancel_by' );

		return true;
	}

	/**
	 * Determines if a subscription can be reactivated through the gateway.
	 *
	 * @since 2.6
	 *
	 * @param bool              $can_reactivate                       True if the Subscription can be reactivated.
	 * @param \EDD_Subscription $subscription Subscription to determine reactivation status of.
	 *
	 * @return bool
	 */
	public function can_reactivate( $can_reactivate, $subscription ) {
		if ( 'stripe' !== $subscription->gateway || empty( $subscription->profile_id ) || 'cancelled' !== $subscription->status ) {
			return $can_reactivate;
		}

		$order = edd_get_order( $subscription->get_original_payment_id() );

		// Can't reactivate with a refunded or revoked original payment.
		if ( 'complete' !== $order->status ) {
			return false;
		}

		// Can't reactivate a Subscription that was automatically cancelled as part of a
		// Software Licensing upgrade.
		$was_upgraded = edd_get_order_meta( $order->id, '_edd_sl_upgraded_to_payment_id', true );

		if ( ! empty( $was_upgraded ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Determines if the subscription can be retried when failing
	 *
	 * @access      public
	 * @since       2.8
	 * @return      bool
	 */
	public function can_retry( $ret, $subscription ) {
		if ( $subscription->gateway === 'stripe' && ! empty( $subscription->profile_id ) && 'failing' === $subscription->status ) {
			return true;
		}
		return $ret;
	}

	/**
	 * Reactivates a subscription.
	 *
	 * @access      public
	 * @since       2.6
	 *
	 * @param EDD_Subscription $subscription The EDD_Subscription object.
	 * @param boolean          $valid        A verification call that this call came from a valid source.
	 *
	 * @return boolean
	 */
	public function reactivate( $subscription, $valid ) {

		if ( empty( $valid ) ) {
			return false;
		}

		try {
			$sub = edds_api_request( 'Subscription', 'retrieve', $subscription->profile_id );

			if ( 'past_due' === $sub->status ) {
				// If the Subscription is past due, we need to retry the latest open invoice.
				$invoices = edds_api_request(
					'Invoice',
					'all',
					array(
						'subscription' => $sub->id,
						'limit'        => 1,
						'status'       => 'open',
					)
				);

				// If the invoice is open, we can pay it.
				foreach ( $invoices as $invoice ) {
					$invoice->pay();
				}

				$sub = edds_api_request( 'Subscription', 'retrieve', $subscription->profile_id );

				if ( 'active' !== $sub->status ) {
					$subscription->add_note( esc_html__( 'Failed to pay past due invoice.', 'edd-recurring' ) );
					return false;
				}
			}

			// This Subscription was cancelled in Stripe, so we have to create a new subscription.
			if ( empty( $sub->cancel_at_period_end ) || in_array( $sub->status, array( 'canceled', 'incomplete', 'incomplete_expired' ), true ) ) {
				$existing_meta = array();

				// Support Stripe PHP 6.x
				if ( method_exists( $sub->metadata, '__toArray' ) ) {
					$existing_meta = $sub->metadata->__toArray();

					// Support Stripe PHP 7.x
					// @link https://github.com/stripe/stripe-php/pull/704
				} elseif ( method_exists( $sub->metadata, 'toArray' ) ) {
					$existing_meta = $sub->metadata->toArray();
				}

				$args = array(
					'customer'               => $sub->customer,
					'items'                  => array(
						array(
							'plan'     => $sub->plan->id,
							'quantity' => $sub->quantity,
						),
					),
					'tax_percent'            => $sub->tax_percent,
					'default_payment_method' => $sub->default_payment_method,
					'default_source'         => $sub->default_source,
					'off_session'            => true,
					'metadata'               => array_merge(
						array(
							'reactivated' => true,
							'old_sub_id'  => $subscription->profile_id,
							'caller'      => __CLASS__ . '|' . __METHOD__ . '|' . __LINE__ . '|' . EDD_RECURRING_VERSION,
						),
						$existing_meta
					),
				);

				// If the expiration date is in the future, we need to reactivate without charge.
				if ( current_time( 'timestamp' ) < $subscription->get_expiration_time() ) {
					if ( ! empty( $sub->current_period_end ) ) {
						$args['trial_end'] = $sub->current_period_end;
					} else {
						$args['trial_end'] = strtotime( $subscription->get_expiration() );
					}
				}

				$stripe_sub = edds_api_request( 'Subscription', 'create', $args );
				$status     = 'active';

				// Subscription could not be fully reactivated.
				if ( 'incomplete' === $stripe_sub->status ) {
					$status = 'needs_attention';
					$subscription->add_note( esc_html__( 'Subscription reactivation requires payment by customer and will be cancelled in 24 hours if no action is taken.', 'edd-recurring' ) );
					edd_set_error( 'edd_recurring_stripe_incomplete_subscription', esc_html__( 'Your subscription could not be fully reactivated. You may need to update your payment method.', 'edd-recurring' ) );
				}

				$subscription->update(
					array(
						'status'     => $status,
						'profile_id' => $stripe_sub->id,
						'expiration' => date( 'Y-n-d H:i:s', $stripe_sub->current_period_end ),
					)
				);
				if ( 'active' === $status ) {
					$subscription->maybe_add_time_meta( 'reactivated' );
				}
			} else { // This Subscription is still active in Stripe, remove cancellation notice.
				edds_api_request(
					'Subscription',
					'update',
					$sub->id,
					array(
						'cancel_at_period_end' => false,
					)
				);

				$subscription->update(
					array(
						'status'     => 'active',
						'expiration' => date( 'Y-n-d H:i:s', $sub->current_period_end ),
					)
				);
				$subscription->maybe_add_time_meta( 'reactivated' );
			}
		} catch ( Exception $e ) {
			wp_die( esc_html( $e->getMessage() ), esc_html( __( 'Error', 'edd-recurring' ) ), array( 'response' => 403 ) );
		}

		return true;
	}

	/**
	 * Retries a failing Subscription's latest invoice.
	 *
	 * This method is connected to a filter instead of an action so we can return a nice error message.
	 *
	 * @todo This uses a different amount of paid invoices than the Stripe Account settings may require.
	 *
	 * @access      public
	 * @since       2.8
	 *
	 * @param bool             $result       If the result was successful.
	 * @param EDD_Subscription $subscription The EDD_Subscription object to retry.
	 *
	 * @return      bool|WP_Error
	 */
	public function retry( $result, $subscription ) {
		if ( ! $this->can_retry( false, $subscription ) ) {
			return $result;
		}

		$subscriber  = new EDD_Recurring_Subscriber( $subscription->customer_id );
		$customer_id = $subscriber->get_recurring_customer_id( 'stripe' );

		if ( empty( $customer_id ) ) {
			return $result;
		}

		$void_past_due_invoices = true;

		/** This filter is documented in includes/gateways/edd-recurring-stripe.php */
		$void_past_due_invoices = apply_filters(
			'edd_recurring_stripe_void_past_due_invoices',
			$void_past_due_invoices,
			$subscription
		);

		try {
			// Manual retries are limited to 7 days, so it's unlikely there will
			// be more invoices than that.
			$invoices = edds_api_request(
				'Invoice',
				'all',
				array(
					'subscription' => $subscription->profile_id,
					'limit'        => 7,
					'status'       => 'open',
					'customer'     => $customer_id,
				)
			);

			if ( empty( $invoices->data ) ) {
				return $result;
			}

			$has_paid_invoice = false;

			foreach ( $invoices->data as $invoice ) {
				/* @var \Stripe\Invoice $invoice */

				// We have found an invoice and paid it, void the rest.
				if ( true === $has_paid_invoice && true === $void_past_due_invoices ) {
					$invoice->voidInvoice();
				} else {
					$paid_invoice = $invoice->pay(
						array(
							'off_session' => true,
						)
					);

					if ( 'paid' === $paid_invoice->status ) {
						$has_paid_invoice = true;
						$payment_intent   = edds_api_request( 'PaymentIntent', 'retrieve', $paid_invoice->payment_intent );
						$charges          = $payment_intent->charges->data;

						if ( ! empty( $charges ) ) {
							$charge = current( $charges );

							/**
							 * Usually we pass in the date value for this renewal, in this case the user is doing it now, by retrying
							 * so the date can just be 'now'.
							 */
							$payment_id = $subscription->add_payment(
								array(
									'transaction_id' => $charge->id,
									'amount'         => $this->stripe_amount_to_edd_amount( $paid_invoice->total ),
									'gateway'        => 'stripe',
								)
							);

							$subscription->renew( $payment_id );
						}
					}
				}
			}

			$result = $has_paid_invoice;
		} catch ( Exception $e ) {
			$result = new WP_Error( 'edd_recurring_stripe_error', $e->getMessage() );
		}

		return $result;
	}

	/**
	 * Converts a Stripe amount (integer) to an EDD amount for storage.
	 * Non-zero-decimal currencies get divided by 100.
	 *
	 * @uses edds_is_zero_decimal_currency()
	 *
	 * @since 2.10.5
	 *
	 * @param int $amount Stripe always gives us an integer.
	 *
	 * @return float|int
	 */
	private function stripe_amount_to_edd_amount( $amount ) {
		if ( ! edds_is_zero_decimal_currency() ) {
			$amount /= 100;
		}

		return $amount;
	}

	/**
	 * Get the expiration date with Stripe
	 *
	 * @since  2.6.6
	 * @param  object $subscription The subscription object
	 * @return string Expiration date or WP_Error if something went wrong
	 */
	public function get_expiration( $subscription ) {

		try {

			$subscription = edds_api_request( 'Subscription', 'retrieve', $subscription->profile_id );

		} catch ( Exception $e ) {

			return new WP_Error( 'edd_recurring_stripe_error', $e->getMessage() );

		}

		return date( 'Y-n-d H:i:s', $subscription->current_period_end );
	}

	/**
	 * Determines if the subscription can be updated.
	 *
	 * @access      public
	 * @since       2.4
	 * @return      bool
	 */
	public function can_update( $can_update, $subscription ) {
		if ( 'stripe' !== $subscription->gateway ) {
			return $can_update;
		}

		if ( ! empty( $subscription->profile_id ) && in_array( $subscription->status, array( 'active', 'failing', 'trialling', 'needs_attention' ), true ) ) {
			return true;
		}

		return $can_update;
	}

	/**
	 * Refund charges for renewals when refunding via View Order Details.
	 *
	 * @access      public
	 * @since       2.4.11
	 * @param       EDD_Payment $payment The EDD_Payment object that is being refunded.
	 * @return      void
	 */
	public function process_refund( EDD_Payment $payment ) {
		if ( empty( $_POST['edd_refund_in_stripe'] ) ) {
			return;
		}

		$statuses = array( 'edd_subscription' );

		if ( ! in_array( $payment->old_status, $statuses ) ) {
			return;
		}

		if ( 'stripe' !== $payment->gateway ) {
			return;
		}

		switch ( $payment->old_status ) {

			// Renewal.
			case 'edd_subscription':
				// No valid charge ID.
				if ( empty( $payment->transaction_id ) || $payment->transaction_id == $payment->ID ) {
					return;
				}

				try {
					if ( version_compare( Stripe\Stripe::VERSION, '7.0', '<' ) ) {
						$refund = edds_api_request( 'Charge', 'retrieve', $payment->transaction_id );
						$refund->refund();
					} else {
						$args = array(
							'charge' => $payment->transaction_id,
						);

						/**
						 * Filters the arguments used to create a Refund object in Stripe.
						 *
						 * @since 2.10.0
						 *
						 * @param array $args {
						 *   Refund object arguments.
						 *
						 *   https://stripe.com/docs/api/refunds/create
						 * }
						 */
						$args = apply_filters( 'edds_create_refund_args', $args );

						$opt_args = array();

						/**
						 * Filters the per-request arguments used when creating a Refund object in Stripe.
						 *
						 * @since 2.10.0
						 *
						 * @param array $opt_args {
						 *   Per request arguments.
						 * }
						 */
						$opt_args = apply_filters( 'edds_create_refund_secondary_args', $opt_args );

						$refund = edds_api_request( 'Refund', 'create', $args, $opt_args );
					}

					$payment->add_note(
						sprintf(
							/* translators: %s Refund ID. */
							__( 'Charge refunded in Stripe. Refund ID %s', 'edd-recurring' ),
							$refund->id
						)
					);
				} catch ( \Exception $e ) {
					wp_die( $e->getMessage(), __( 'Error', 'edd-recurring' ), array( 'response' => 400 ) );
				}

				break;
		}
	}

	/**
	 * Outputs the payment method update form
	 *
	 * @since  2.4
	 * @param  EDD_Subscription object $subscription The subscription object.
	 * @return void
	 */
	public function update_payment_method_form( $subscription ) {
		if ( $subscription->gateway !== $this->id ) {
			return;
		}

		$form = new \EDD\Recurring\Gateways\Stripe\Update\Form( $subscription );
		$form->render();
	}

	/**
	 * Updates a Subscription's default payment method.
	 *
	 * @since 2.13.0 Added `setup_intent` to the AJAX response if a new payment method requires confirmation.
	 */
	public function update_subscription_payment_method() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : false;
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'update-payment' ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Invalid request. Please try again', 'edd-recurring' ),
				)
			);
		}

		$subscription_id       = isset( $_POST['subscription_id'] ) ? sanitize_text_field( $_POST['subscription_id'] ) : false;
		$payment_method_id     = isset( $_POST['payment_method_id'] ) ? sanitize_text_field( $_POST['payment_method_id'] ) : false;
		$payment_method_exists = isset( $_POST['payment_method_exists'] ) ? 'true' === sanitize_text_field( $_POST['payment_method_exists'] ) : false;

		if ( ! $subscription_id || ! $payment_method_id ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Unable to locate Subscription. Please try again', 'edd-recurring' ),
				)
			);
		}

		// Handle authentication - either logged-in user or token-based.
		$edd_subscription = null;
		$update_token     = filter_input( INPUT_POST, 'update_token', FILTER_SANITIZE_SPECIAL_CHARS );

		if ( ! is_user_logged_in() && ! $update_token ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Authentication required. Please log in or use a valid update link.', 'edd-recurring' ),
				)
			);
		}

		if ( $update_token ) {
			// Token-based authentication for non-logged-in users.
			$edd_subscription = \EDD\Recurring\Subscriptions\Update\Link::validate_token( $update_token );
			if ( ! $edd_subscription instanceof \EDD\Recurring\Subscriptions\Subscription ) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'Invalid or expired update link.', 'edd-recurring' ),
					)
				);
			}

			// Verify the subscription ID matches the token.
			if ( $edd_subscription->profile_id !== $subscription_id ) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'Subscription mismatch.', 'edd-recurring' ),
					)
				);
			}

			if ( ! $edd_subscription->can_update() ) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'This subscription cannot be updated.', 'edd-recurring' ),
					)
				);
			}
		} else {
			// Logged-in user authentication.
			$edd_subscription = edd_recurring_get_subscription_by( 'profile_id', $subscription_id );
			if ( ! $edd_subscription ) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'Unable to locate subscription.', 'edd-recurring' ),
					)
				);
			}

			// Verify user owns this subscription.
			$subscriber = new EDD_Recurring_Subscriber( $edd_subscription->customer_id );
			if ( (int) get_current_user_id() !== (int) $subscriber->user_id ) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'You do not have permission to update this subscription.', 'edd-recurring' ),
					)
				);
			}
		}

		try {
			$original_payment_method_id = null;
			$stripe_customer_id         = null;
			// Retrieve the subscription to get its current default payment method.
			// This is crucial for the revert functionality.
			try {
				$stripe_subscription_for_original_pm = edds_api_request( 'Subscription', 'retrieve', $subscription_id );
				if ( ! empty( $stripe_subscription_for_original_pm->default_payment_method ) ) {
					$original_payment_method_id = $stripe_subscription_for_original_pm->default_payment_method;
				}
				$stripe_customer_id = $stripe_subscription_for_original_pm->customer;
			} catch ( \Exception $e ) {
				// Log this error. If we can't get the original PM, we can't revert if the update leads to a failed SI.
				// This might be acceptable if it's rare, but it's a known limitation then.
				edd_debug_log( 'EDD Recurring Stripe: Could not retrieve original payment method for subscription ' . $subscription_id . ' during update attempt: ' . $e->getMessage() );
			}

			// Attach method if it's new.
			if ( ! $payment_method_exists && ! empty( $stripe_customer_id ) ) {
				$payment_method = edds_api_request( 'PaymentMethod', 'retrieve', $payment_method_id );
				$payment_method->attach(
					array(
						'customer' => $stripe_customer_id,
					)
				);

				// Update an existing method's address.
			} else {
				$address_info    = isset( $_POST['billing_address'] ) ? (array) $_POST['billing_address'] : array();
				$billing_address = array();

				foreach ( $address_info as $key => $value ) {
					$billing_address[ $key ] = ! empty( $value ) ? sanitize_text_field( $value ) : null;
				}

				edds_api_request(
					'PaymentMethod',
					'update',
					$payment_method_id,
					array(
						'billing_details' => array(
							'address' => $billing_address,
						),
					)
				);
			}

			// Set the Subscription's default payment method.
			$stripe_subscription_object = edds_api_request(
				'Subscription',
				'update',
				$subscription_id,
				array(
					'default_payment_method' => $payment_method_id,
				)
			);

			$response_data = array(
				'message'                    => esc_html__( 'Payment method updated.', 'edd-recurring' ),
				'subscription'               => $stripe_subscription_object,
				'setup_intent'               => null,
				'original_payment_method_id' => null,
			);

			if ( ! empty( $stripe_subscription_object->pending_setup_intent ) && is_string( $stripe_subscription_object->pending_setup_intent ) ) {
				try {
					$retrieved_setup_intent = edds_api_request( 'SetupIntent', 'retrieve', $stripe_subscription_object->pending_setup_intent );
					if (
						$retrieved_setup_intent &&
						isset( $retrieved_setup_intent->status ) &&
						in_array( $retrieved_setup_intent->status, array( 'requires_action', 'requires_confirmation' ), true )
					) {
						$response_data['setup_intent'] = $retrieved_setup_intent;
						// Only provide original_payment_method_id if a revert might be needed and we have one,
						// and it's different from the new one.
						if ( $original_payment_method_id && $original_payment_method_id !== $payment_method_id ) {
							$response_data['original_payment_method_id'] = $original_payment_method_id;
						}
						$response_data['message'] = esc_html__( 'Your payment method requires additional confirmation.', 'edd-recurring' );
					}
				} catch ( \Exception $si_exception ) {
					edd_debug_log( 'EDD Recurring Stripe: Failed to retrieve SetupIntent ' . $stripe_subscription_object->pending_setup_intent . ': ' . $si_exception->getMessage() );
					// Do not let failure to retrieve the SI break the entire payment method update flow if the main part succeeded,
					// but this means client-side SI handling won't occur as expected.
					// The message will remain 'Payment method updated.', which might be misleading if SI was needed.
				}
			}

			wp_send_json_success( $response_data );
		} catch ( \Exception $e ) {
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}

	/**
	 * Processes the update payment form.
	 *
	 * Handling of the latest open invoice with an attached PaymentIntent is done
	 * on the client. In order to avoid a loop of paying for multiple "Past due" invoices
	 * that haven't affected the the \EDD_Subscription status, void them.
	 *
	 * @link https://github.com/easydigitaldownloads/edd-recurring/issues/1177
	 *
	 * @since 2.9.0
	 *
	 * @param EDD_Recurring_Subscriber $subscriber   EDD_Recurring_Subscriber.
	 * @param EDD_Subscription         $subscription EDD_Subscription.
	 */
	public function update_payment_method( $subscriber, $subscription ) {
		$void_past_due_invoices = true;

		/**
		 * Filters if stacked past due invoices should be voided when updating
		 * a Subscription's payment method.
		 *
		 * @since 2.9.0
		 *
		 * @param bool $void_past_due_invoices Void stacked past due invoices. Defaults true.
		 * @param int  $subscriber EDD_Recurring_Subscriber
		 */
		$void_past_due_invoices = apply_filters(
			'edd_recurring_stripe_void_past_due_invoices',
			$void_past_due_invoices,
			$subscription
		);

		if ( true !== $void_past_due_invoices ) {
			return;
		}

		if ( empty( $subscription->profile_id ) ) {
			return;
		}

		$customer_id = $subscriber->get_recurring_customer_id( 'stripe' );

		if ( empty( $customer_id ) ) {
			return;
		}
		edd_recurring_update_subscription_meta( $subscription->id, 'ignore_original_payment_method', true );

		try {
			// Manual retries are limited to 7 days, so it's unlikely there will
			// be more invoices than that.
			$invoices = edds_api_request(
				'Invoice',
				'all',
				array(
					'subscription' => $subscription->profile_id,
					'limit'        => 7,
					'status'       => 'open',
					'customer'     => $customer_id,
				)
			);

			if ( empty( $invoices->data ) ) {
				return;
			}

			foreach ( $invoices->data as $invoice ) {
				/* @var \Stripe\Invoice $invoice */
				$invoice->voidInvoice();
			}
		} catch ( \Exception $e ) {
			wp_die( esc_html( $e->getMessage() ) );
		}
	}

	/**
	 * Cancels subscription in Stripe when marked as completed
	 *
	 * @access      public
	 * @since       2.4.15
	 * @return      bool
	 */
	public function cancel_on_completion( $subscription_id, $subscription ) {

		if ( $subscription->gateway !== $this->id ) {
			return;
		}

		return $this->cancel( $subscription, true );
	}

	/**
	 * Link the recurring profile in Stripe.
	 *
	 * @since  2.4.4
	 * @param  string $profile_id   The recurring profile id
	 * @param  object $subscription The Subscription object
	 * @return string               The link to return or just the profile id
	 */
	public function link_profile_id( $profile_id, $subscription ) {

		if ( ! empty( $profile_id ) ) {
			$order      = edd_get_order( $subscription->parent_payment_id );
			$html       = '<a href="%s" target="_blank">' . $profile_id . '</a>';
			$base_url   = 'test' === $order->mode ? 'https://dashboard.stripe.com/test/' : 'https://dashboard.stripe.com/';
			$link       = esc_url( $base_url . 'subscriptions/' . $profile_id );
			$profile_id = sprintf( $html, $link );
		}

		return $profile_id;
	}

	/**
	 * Looks up the transaction ID for a subscription record by the profile ID.
	 *
	 * @since  2.4.11
	 * @param string $profile_id The recurring profile id.
	 * @return object|false EDD_Subsciption object or false if no updates are made.
	 */
	public function check_transaction_id( $profile_id = '' ) {
		if ( empty( $profile_id ) ) {
			return false;
		}

		$subscription = edd_recurring_get_subscription_by( 'profile_id', $profile_id );
		if ( ! $subscription ) {
			return false;
		}

		// Already transformed a PaymentIntent to Charge ID.
		if ( 'ch_' === substr( $subscription->transaction_id, 0, 3 ) ) {
			return $subscription;
		}

		// A parent EDD_Payment's PaymentIntent was used temporarily.
		// Try to find a charge from the Intent.
		if ( 'pi_' === substr( $subscription->transaction_id, 0, 3 ) ) {

			try {
				$payment_intent = edds_api_request( 'PaymentIntent', 'retrieve', $subscription->transaction_id );

				if ( ! empty( $payment_intent->charges->data ) ) {
					$charge_id = current( $payment_intent->charges->data )->id;

					$subscription->update(
						array(
							'transaction_id' => $charge_id,
						)
					);

					return $subscription;
				}
			} catch ( \Exception $e ) {
				return false;
			}

			// Try to find it through any existing invoices.
		} else {

			$subscriber  = new EDD_Recurring_Subscriber( $subscription->customer_id );
			$customer_id = $subscriber->get_recurring_customer_id( 'stripe' );

			if ( empty( $customer_id ) ) {
				return false;
			}

			try {
				$customer = edds_api_request( 'Customer', 'retrieve', $customer_id );
				$invoices = edds_api_request(
					'Invoice',
					'all',
					array(
						'customer' => $customer_id,
						'limit'    => 20,
					)
				);

				if ( empty( $invoices->data ) ) {
					return false;
				}

				foreach ( $invoices->data as $invoice ) {
					if ( empty( $invoice->subscription ) ) {
						continue;
					}

					if ( $profile_id != $invoice->subscription ) {
						continue;
					}

					if ( empty( $invoice->charge ) ) {
						continue;
					}

					$subscription->update(
						array(
							'transaction_id' => $invoice->charge,
						)
					);

					$subscription->transaction_id = $invoice->charge;

					return $subscription;

					break;
				}
			} catch ( \Exception $e ) {
				return false;
			}
		}

		return false;
	}

	/**
	 * Determines if the subscription data needs checked against Stripe's database.
	 *
	 * Right now this only checks if the transaction ID is missing and retrieves it. In the future this could also check status, expiration date, etc.
	 *
	 * @since  2.4.11
	 * @param EDD_Subscription $subscription The EDD_Subscription object.
	 * @return void
	 */
	public function maybe_check_subscription( EDD_Subscription $subscription ) {
		if ( ! $subscription || ! $subscription->id > 0 ) {
			return;
		}

		if ( 'stripe' !== $subscription->gateway ) {
			return;
		}

		if ( empty( $subscription->profile_id ) ) {
			return;
		}

		// Already transformed a PaymentIntent to Charge ID.
		if ( 'ch_' === substr( $subscription->transaction_id, 0, 3 ) ) {
			return;
		}

		// Make sure we don't cause an infinite loop.
		remove_action( 'edd_recurring_setup_subscription', array( $this, 'maybe_check_subscription' ), 10 );

		if ( false !== $this->check_transaction_id( $subscription->profile_id ) ) {
			// Remove the scheduled event for this subscription if it hasn't already run.
			wp_clear_scheduled_hook( 'edd_recurring_stripe_check_txn', array( $subscription->profile_id ) );
		}

		add_action( 'edd_recurring_setup_subscription', array( $this, 'maybe_check_subscription' ) );
	}

	/**
	 * Verify that the user has acknowledged to updating their payment form as a default for all subscriptions
	 *
	 * @since 2.4
	 * @since 2.9.0 No longer used, always returns value sent.
	 *
	 * @param bool  $is_valid  If the data passed so far was valid from EDD Core
	 * @param array $post_data The array of $_POST sent by the form
	 *
	 * @return bool
	 */
	public function confirm_default_payment_method_change( $is_valid, $post_data ) {
		return $is_valid;
	}
}
$edd_recurring_stripe = new EDD_Recurring_Stripe();
