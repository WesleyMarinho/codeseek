<?php
/**
 * PayPal Commerce Functions
 *
 * @package    edd-recurring
 * @subpackage Gateways\PayPal
 * @copyright  Copyright (c) 2021, Sandhills Development, LLC
 * @license    GPL2+
 * @since      2.11.2
 */

namespace EDD_Recurring\Gateways\PayPal;

use EDD_Recurring_PayPal_Commerce;

/**
 * Builds the arguments to create a plan when upgrading a Software Licensing license.
 * In this scenario we need to sync the subscription's first renewal date with the expiration
 * date of the license. So if your license key expires in 6 months but you're upgrading to
 * a yearly plan, we want to charge the user $x today and have the first renewal be in
 * 6 months time.
 *
 * @internal Not intended for general use. May change without warning.
 *
 * @param \DateTime $renewal_date Desired date of the first renewal.
 * @param string    $product_id   PayPal product ID this plan is associated with.
 * @param array     $subscription Array of subscription data.
 *
 * @since    2.11.2
 * @return array Arguments that can be used in the API request to create a plan.
 * @throws \Exception If the billing cycle arguments are missing.
 */
function _create_plan_args_for_sl_upgrade( $renewal_date, $product_id, $subscription ) {
	$plan_args = EDD_Recurring_PayPal_Commerce::build_plan_api_args(
		$product_id,
		$subscription
	);

	if ( empty( $plan_args['billing_cycles'] ) || ! is_array( $plan_args['billing_cycles'] ) ) {
		throw new \Exception( 'Missing billing cycle arguments.' );
	}

	// We need to update the 'frequency' for the initial payment to match the renewal date.
	$current_date = new \DateTime( 'now' );

	// Calculate the total difference in seconds.
	$current_timestamp = $current_date->getTimestamp();
	$renewal_timestamp = $renewal_date->getTimestamp();
	$total_seconds     = $renewal_timestamp - $current_timestamp;

	// Calculate total days, years, and remaining days.
	$total_days     = (int) floor( $total_seconds / DAY_IN_SECONDS );
	$years          = intdiv( $total_days, 365 );
	$remainder_days = $total_days % 365;

	$new_billing_cycles = array();
	$current_sequence   = 1;

	// Special case for exactly one year (accounting for leap years).
	if ( 365 === $total_days || 366 === $total_days ) {
		$new_billing_cycles[] = array(
			'frequency'      => EDD_Recurring_PayPal_Commerce::subscription_frequency_to_paypal_args( 'year', 1 ),
			'tenure_type'    => 'TRIAL',
			'sequence'       => $current_sequence,
			'pricing_scheme' => array(
				'fixed_price' => array(
					'currency_code' => strtoupper( edd_get_currency() ),
					'value'         => (string) $subscription['initial_amount'],
				),
			),
			'total_cycles'   => 1,
		);

		++$current_sequence;
	} else {
		// PayPal's maximum allowed value for a "day" cycle is 365.
		if ( $remainder_days > 0 ) {
			$new_billing_cycles[] = array(
				'frequency'      => EDD_Recurring_PayPal_Commerce::subscription_frequency_to_paypal_args( 'day', $remainder_days ),
				'tenure_type'    => 'TRIAL',
				'sequence'       => $current_sequence,
				'pricing_scheme' => array(
					'fixed_price' => array(
						'currency_code' => strtoupper( edd_get_currency() ),
						'value'         => (string) $subscription['initial_amount'],
					),
				),
				'total_cycles'   => 1,
			);

			++$current_sequence;
		}

		// If we have any years, we need another billing cycle for that.
		if ( $years > 0 ) {
			$new_billing_cycles[] = array(
				'frequency'      => EDD_Recurring_PayPal_Commerce::subscription_frequency_to_paypal_args( 'year', $years ),
				'tenure_type'    => 'TRIAL',
				'sequence'       => $current_sequence,
				'pricing_scheme' => array(
					'fixed_price' => array(
						'currency_code' => strtoupper( edd_get_currency() ),
						// Only charge an amount today if this is the first sequence. (If we didn't already set a trial above.).
						'value'         => 1 === $current_sequence ? (string) $subscription['initial_amount'] : '0',
					),
				),
				'total_cycles'   => 1,
			);

			++$current_sequence;
		}
	}

	// Now add the recurring cycle.
	$new_billing_cycles[] = array(
		'frequency'      => EDD_Recurring_PayPal_Commerce::subscription_frequency_to_paypal_args( $subscription['period'], $subscription['frequency'] ),
		'tenure_type'    => 'REGULAR',
		'sequence'       => $current_sequence,
		'pricing_scheme' => array(
			'fixed_price' => array(
				'currency_code' => strtoupper( edd_get_currency() ),
				'value'         => (string) $subscription['recurring_amount'],
			),
		),
		'total_cycles'   => ! empty( $subscription['bill_times'] ) ? intval( $subscription['bill_times'] ) : 0,
	);

	$plan_args['billing_cycles'] = $new_billing_cycles;

	return $plan_args;
}
