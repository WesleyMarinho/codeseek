<?php
/**
 * The Subscriptions block view.
 * This view is used to display the subscriptions block.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 * @var array $attributes The block attributes.
 */

$database      = new EDD_Subscriptions_DB();
$args          = $this->get_subscription_args( $attributes );
$subscriptions = $database->get_subscriptions( $args );

if ( empty( $subscriptions ) ) {
	?>
	<p><?php esc_html_e( 'You do not have any subscriptions.', 'edd-recurring' ); ?></p>
	<?php
	return;
}

$classes = $this->get_classes(
	$attributes,
	array(
		'edd-blocks__subscriptions-grid',
	)
);
?>

<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
	<?php
	foreach ( $subscriptions as $subscription ) :
		?>
		<div class="edd-blocks-subscriptions__subscription edd-blocks-subscriptions__grid-item">
			<?php
			require 'subscription/header.php';
			require 'subscription/rows.php';
			require 'subscription/link.php';
			?>
		</div>
		<?php
	endforeach;
	?>
</div>

<?php
if ( empty( $attributes['number'] ) ) {
	return;
}
unset( $args['number'] );
$count = $database->count( $args );
echo edd_pagination(
	array(
		'type'  => 'subscriptions',
		'total' => ceil( $count / absint( $attributes['number'] ) ),
	)
);
