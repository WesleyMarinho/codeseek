<?php
/**
 * The subscription header view.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 * @var \EDD_Subscription $subscription The subscription object.
 */

?>
<div class="edd-blocks-subscriptions__subscription-header edd-blocks-subscriptions__grid-item-header">
	<div class="edd-blocks-subscriptions__subscription-id">
		<?php
		/* translators: %s: Subscription ID */
		printf( esc_html__( 'Subscription #%s', 'edd-recurring' ), esc_html( $subscription->id ) );
		?>
	</div>
	<div class="edd-blocks-subscriptions__subscription-status">
		<?php
		if ( ! empty( $subscription->status ) ) {
			echo esc_html( $subscription->get_status_label() );
		}
		?>
	</div>
</div>
