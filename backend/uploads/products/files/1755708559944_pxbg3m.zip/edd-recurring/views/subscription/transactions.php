<?php
/**
 * The subscription transactions view.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 * @var \EDD_Subscription $subscription The subscription object.
 */

$renewal_orders   = $subscription->get_renewal_orders();
$renewal_orders[] = edd_get_order( $subscription->parent_payment_id );
if ( ! $renewal_orders ) {
	return;
}
?>

<h3><?php esc_html_e( 'Transactions', 'edd-recurring' ); ?></h3>

<?php
$classes = $this->get_classes(
	$attributes,
	array(
		'edd-blocks__subscriptions-grid',
		'edd-blocks__columns',
	)
);
?>

<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
	<?php
	foreach ( $renewal_orders as $order ) {
		$receipt_uri = edd_get_receipt_page_uri( $order->id );
		?>
		<div class="edd-blocks-subscriptions__transaction edd-blocks-subscriptions__grid-item">
			<div class="edd-blocks-subscriptions__grid-item-header">
				<div class="edd-blocks__row-label">
					<?php esc_html_e( 'Order:', 'edd-recurring' ); ?>
				</div>
				<div class="edd-blocks__row-value">
					<a
						href="<?php echo esc_url( $receipt_uri ); ?>"
					>
						<?php echo esc_html( edd_get_payment_number( $order->id ) ); ?>
					</a>
					<?php
					if ( $order->id == $subscription->parent_payment_id ) {
						echo ' ' . esc_html__( '(original order)', 'edd-recurring' );
					}
					?>
				</div>
			</div>
			<div class="edd-blocks__row">
				<div class="edd-blocks__row-label">
					<?php esc_html_e( 'Order Amount:', 'edd-recurring' ); ?>
				</div>
				<div class="edd-blocks__row-value">
					<?php echo esc_html( edd_currency_filter( edd_format_amount( edd_get_payment_amount( $order->id ) ), edd_get_payment_currency_code( $order->id ) ) ); ?>
				</div>
			</div>
			<div class="edd-blocks__row">
				<div class="edd-blocks__row-label">
					<?php esc_html_e( 'Order Date:', 'edd-recurring' ); ?>
				</div>
				<div class="edd-blocks__row-value">
					<?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $order->date_created ) ) ); ?>
				</div>
			</div>
		</div>
		<?php
	}
	?>
</div>
