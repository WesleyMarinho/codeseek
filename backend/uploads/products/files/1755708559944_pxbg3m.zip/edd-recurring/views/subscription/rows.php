<?php
/**
 * The subscription rows view.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 * @var \EDD_Subscription $subscription The subscription object.
 */

?>
<div class="edd-blocks__row">
	<div class="edd-blocks__row-label">
		<?php esc_html_e( 'Product:', 'edd-recurring' ); ?>
	</div>
	<div class="edd-blocks__row-value">
		<?php
		$price_id = is_numeric( $subscription->price_id ) ? $subscription->price_id : null;
		echo esc_html( edd_get_download_name( $subscription->product_id, $price_id ) );
		?>
	</div>
</div>
<?php if ( ! empty( $attributes['show_initial_amount'] ) ) : ?>
	<div class="edd-blocks__row">
		<div class="edd-blocks__row-label">
			<?php esc_html_e( 'Initial Amount:', 'edd-recurring' ); ?>
		</div>
		<div class="edd-blocks__row-value">
			<?php
			echo esc_html( edd_currency_filter( edd_format_amount( $subscription->recurring_amount ) ) );
			?>
		</div>
	</div>
<?php endif; ?>
<div class="edd-blocks__row">
	<div class="edd-blocks__row-label">
		<?php esc_html_e( 'Price:', 'edd-recurring' ); ?>
	</div>
	<div class="edd-blocks__row-value">
		<?php
		printf(
			'%s / %s',
			esc_html( edd_currency_filter( edd_format_amount( $subscription->recurring_amount ) ) ),
			esc_html( EDD_Recurring()->get_pretty_subscription_frequency( $subscription->period ) )
		);
		?>
	</div>
</div>
<div class="edd-blocks__row">
	<div class="edd-blocks__row-label">
		<?php esc_html_e( 'Renews On:', 'edd-recurring' ); ?>
	</div>
	<div class="edd-blocks__row-value">
		<?php
		echo esc_html( ! empty( $subscription->expiration ) ? date_i18n( get_option( 'date_format' ), strtotime( $subscription->expiration ) ) : __( 'N/A', 'edd-recurring' ) );
		?>
	</div>
</div>
<?php if ( ! empty( $attributes['show_gateway'] ) ) : ?>
	<div class="edd-blocks__row">
		<div class="edd-blocks__row-label">
			<?php esc_html_e( 'Payment Method:', 'edd-recurring' ); ?>
		</div>
		<div class="edd-blocks__row-value">
			<?php
			$order = edd_recurring_get_subscription_meta( $subscription->id, 'ignore_original_payment_method', true ) ? null : edd_get_order( $subscription->parent_payment_id );
			echo esc_html( edd_get_gateway_checkout_label( $subscription->gateway, $order ) );
			?>
		</div>
	</div>
<?php endif; ?>
<?php if ( ! empty( $attributes['show_times_billed'] ) ) : ?>
	<div class="edd-blocks__row">
		<div class="edd-blocks__row-label">
			<?php esc_html_e( 'Times Billed:', 'edd-recurring' ); ?>
		</div>
		<div class="edd-blocks__row-value">
			<?php
			$output = $subscription->get_times_billed() . ' / ';
			if ( empty( $subscription->bill_times ) ) {
				$output .= __( 'Until Cancelled', 'edd-recurring' );
			} else {
				$output .= $subscription->bill_times;
			}
			echo esc_html( $output );
			?>
		</div>
	</div>
<?php endif; ?>
