<?php
/**
 * The subscription details view.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 * @var \EDD_Subscription $subscription The subscription object.
 */

if ( empty( $subscription ) ) {
	$subscription = false;
	if ( isset( $_GET['subscription_id'] ) && is_numeric( $_GET['subscription_id'] ) ) {
		$subscription_id = absint( $_GET['subscription_id'] );
		$subscription    = new EDD_Subscription( $subscription_id );
	}
}
if ( ! $subscription instanceof EDD_Subscription || empty( $subscription->id ) ) {
	return;
}
$subscriber = new EDD_Recurring_Subscriber( get_current_user_id(), true );
if ( empty( $subscriber->id ) || $subscription->customer_id !== $subscriber->id ) {
	return;
}
include 'actions.php';
?>
<h3><?php esc_html_e( 'Details', 'edd-recurring' ); ?></h3>
<div class="edd-blocks-subscriptions__subscription edd-blocks-subscriptions__grid-item">
	<?php
	include 'header.php';
	include 'rows.php';
	?>
</div>

<!-- wp:spacer -->
<div style="height:60px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<?php
include 'transactions.php';
