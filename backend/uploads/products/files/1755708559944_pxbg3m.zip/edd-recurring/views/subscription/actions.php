<?php
/**
 * The subscription actions view.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 * @var \EDD_Subscription $subscription The subscription object.
 */

$actions = $this->get_subscription_actions( $subscription );
?>
<div class="edd-blocks-subscriptions__subscription-actions">
	<?php
	$action_url = remove_query_arg( array( 'subscription_id', 'view_transactions' ), edd_get_current_page_url() );
	?>
	<a href="<?php echo esc_url( $action_url ); ?>" class="edd-submit">
		<?php esc_html_e( 'All Subscriptions', 'edd-recurring' ); ?>
	</a>
	<?php
	$view = filter_input( INPUT_GET, 'action', FILTER_SANITIZE_SPECIAL_CHARS );
	foreach ( $actions as $key => $action ) {
		if ( $view === $key ) {
			continue;
		}
		?>
		<a
			href="<?php echo esc_url( $action['url'] ); ?>"
			class="edd-blocks-subscriptions__subscription-action edd-subscription-<?php echo esc_attr( $key ); ?> edd-submit"
		>
			<?php echo esc_html( $action['label'] ); ?>
		</a>
		<?php
	}
	?>
</div>
