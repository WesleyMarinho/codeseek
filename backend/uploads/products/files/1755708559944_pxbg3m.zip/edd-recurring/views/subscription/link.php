<?php
/**
 * The subscription details link view.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 * @var \EDD_Subscription $subscription The subscription object.
 */

?>
<div class="edd-blocks-subscriptions__subcription-actions">
	<?php $details = $this->get_details_link( $subscription ); ?>
	<div class="edd-blocks-subscriptions__subscription-action">
		<a
			href="<?php echo esc_url( $details['url'] ); ?>"
			class="edd-blocks-subscriptions__subscription-action--details"
		>
			<?php echo esc_html( $details['label'] ); ?>
		</a>
	</div>
</div>
