<?php
/**
 * Manages secure URLs for subscription payment method updates.
 *
 * @package     EDD\Recurring\Subscriptions
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Subscriptions\Update;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Recurring\Subscriptions\Subscription;

/**
 * Class Link
 *
 * @since 2.13.0
 */
class Link {

	/**
	 * The cipher method for encryption.
	 *
	 * @since 2.13.0
	 */
	private const CIPHER_METHOD = 'AES-256-CBC';

	/**
	 * Generates a secure URL for updating a subscription\'s payment method.
	 *
	 * @since 2.13.0
	 *
	 * @param Subscription $subscription The subscription object.
	 * @return string|null The secure URL, or null if not applicable.
	 */
	public static function generate_for_subscription( Subscription $subscription ): ?string {
		if ( ! self::is_subscription_valid( $subscription ) ) {
			return null;
		}

		$data_to_encrypt = (string) $subscription->id;
		$key             = self::get_encryption_key();
		$iv_length       = openssl_cipher_iv_length( self::CIPHER_METHOD );
		if ( false === $iv_length ) {
			// Log error or handle, as IV length could not be determined.
			// This case is highly unlikely for standard ciphers like AES-256-CBC.
			return null;
		}
		$iv = openssl_random_pseudo_bytes( $iv_length );

		$encrypted_data = openssl_encrypt( $data_to_encrypt, self::CIPHER_METHOD, $key, OPENSSL_RAW_DATA, $iv );

		if ( false === $encrypted_data ) {
			// Log error: encryption failed.
			return null;
		}

		// Combine IV and encrypted data, then hex encode for URL safety.
		$token = bin2hex( $iv . $encrypted_data );

		// Use the custom rewrite URL structure.
		return home_url( 'subscription/update/' . $token );
	}

	/**
	 * Validates a token from a secure URL and retrieves the subscription.
	 *
	 * @since 2.13.0
	 *
	 * @param string $token The token from the URL.
	 * @return Subscription|null The subscription object if the token is valid, otherwise null.
	 */
	public static function validate_token( string $token ): ?Subscription {
		// A valid hex string must have an even length and contain only hex characters.
		if ( strlen( $token ) % 2 !== 0 || ! ctype_xdigit( $token ) ) {
			return null;
		}

		$raw_data = hex2bin( $token );
		// hex2bin() itself can return false for other reasons, e.g. internal errors, although rare with prior checks.
		if ( false === $raw_data ) {
			// Invalid hex string.
			return null;
		}

		$key       = self::get_encryption_key();
		$iv_length = openssl_cipher_iv_length( self::CIPHER_METHOD );
		if ( false === $iv_length ) {
			// This should ideally not happen if CIPHER_METHOD is valid.
			return null;
		}

		// Ensure there's enough data for the IV.
		if ( strlen( $raw_data ) < $iv_length ) {
			return null;
		}

		$iv             = substr( $raw_data, 0, $iv_length );
		$encrypted_data = substr( $raw_data, $iv_length );

		$decrypted_data = openssl_decrypt( $encrypted_data, self::CIPHER_METHOD, $key, OPENSSL_RAW_DATA, $iv );

		if ( false === $decrypted_data || ! is_numeric( $decrypted_data ) ) {
			// Decryption failed or did not yield a numeric ID.
			return null;
		}

		$subscription_id = (int) $decrypted_data;
		if ( $subscription_id <= 0 ) {
			return null;
		}

		try {
			$subscription = new Subscription( $subscription_id );
			if ( ! self::is_subscription_valid( $subscription ) ) {
				return null;
			}

			return $subscription;
		} catch ( \Exception $e ) {
			// Failed to load subscription.
			return null;
		}
	}

	/**
	 * Checks if a subscription is valid for updating. The subscription must be failing and using the Stripe gateway.
	 *
	 * @since 2.13.0
	 * @param Subscription $subscription The subscription object.
	 * @return bool True if the subscription is valid, false otherwise.
	 */
	private static function is_subscription_valid( Subscription $subscription ): bool {
		if ( ! $subscription instanceof Subscription || empty( $subscription->id ) ) {
			return false;
		}

		$allowed_statuses = array( 'failing', 'trialling', 'active' );
		if ( ! in_array( $subscription->status, $allowed_statuses, true ) ) {
			return false;
		}

		if ( 'stripe' === $subscription->gateway ) {
			return true;
		}

		return ! empty( edd_recurring_get_customer_update_uri( $subscription ) );
	}

	/**
	 * Gets the encryption key.
	 *
	 * Derives a key from WordPress salts for better security.
	 *
	 * @since 2.13.0
	 * @return string The encryption key.
	 */
	private static function get_encryption_key(): string {
		// Using a hash of WordPress nonces ensures the key is site-specific and persistent.
		// We use SHA256 to ensure the key is the correct length for AES-256.
		return hash( 'sha256', NONCE_KEY . NONCE_SALT, true );
	}
}
