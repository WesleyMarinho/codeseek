<?php
/**
 * Manages the display and handling of the subscription payment method update page.
 *
 * @package     EDD\Recurring\Subscriptions\Update
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Subscriptions\Update;

use EDD\EventManagement\SubscriberInterface;
use EDD\Recurring\Subscriptions\Subscription;
use EDD\Recurring\Subscriptions\Update\Link;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class Page
 *
 * Handles the WordPress integration for the subscription update URL, including rewrite rules and page display.
 *
 * @since 2.13.0
 */
class Page implements SubscriberInterface {

	/**
	 * Get the subscribed events.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events(): array {
		return array(
			'init'                         => array( 'add_custom_rewrite_rule', 1 ),
			'query_vars'                   => 'add_query_vars',
			'template_redirect'            => 'handle_subscription_redirect',
			'template_include'             => 'include_template',
			'edd_recurring_update_payment' => 'finish_update_payment',
		);
	}

	/**
	 * Add custom rewrite rule for subscription update URLs.
	 *
	 * @since 2.13.0
	 */
	public function add_custom_rewrite_rule() {
		/**
		 * Filter the rewrite rule for the subscription update URL.
		 *
		 * @since 2.13.0
		 * @param string $rewrite_rule The rewrite rule for the subscription update URL.
		 */
		$rules = get_option( 'rewrite_rules', array() );
		if ( ! isset( $rules[ $this->get_update_rewrite_rule() ] ) ) {
			add_rewrite_tag( '%update_token%', '([^&]+)' );
			add_rewrite_rule( $this->get_update_rewrite_rule(), 'index.php?pagename=subscription-update&edd_recurring_update=$matches[1]', 'top' );
			flush_rewrite_rules();
		}
	}

	/**
	 * Add query vars for the custom rewrite rule.
	 *
	 * @since 2.13.0
	 * @param array $vars Query vars.
	 * @return array
	 */
	public function add_query_vars( $vars ) {
		$vars[] = 'edd_recurring_update';

		return $vars;
	}

	/**
	 * Handle subscription redirect logic before template loading.
	 *
	 * @since 2.13.1
	 * @return void
	 */
	public function handle_subscription_redirect() {
		if ( ! $this->is_update_page() ) {
			return;
		}

		$token        = sanitize_text_field( get_query_var( 'edd_recurring_update' ) );
		$subscription = Link::validate_token( $token );

		if ( ! $subscription instanceof Subscription ) {
			// Invalid token - let the template handle the error display.
			return;
		}

		// If subscription can be updated directly, show the form.
		if ( $subscription->can_update() ) {
			return;
		}

		$uri = edd_recurring_get_customer_update_uri( $subscription );
		if ( empty( $uri ) ) {
			return;
		}

		wp_redirect( $uri ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
		exit;
	}

	/**
	 * Include custom template for subscription update page.
	 *
	 * @since 2.13.0
	 * @param string $template Template.
	 * @return string
	 */
	public function include_template( $template ) {
		if ( ! $this->is_update_page() ) {
			return $template;
		}

		// Ensure we set a no-cache directive.
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		// Set the status header to 200.
		status_header( 200 );

		add_action(
			'pre_get_document_title',
			function () {
				return esc_html__( 'Update Payment Method', 'edd-recurring' );
			}
		);

		if ( wp_is_block_theme() ) {
			return $this->get_template_path( 'subscription-update-blocks.php' );
		}

		return $this->get_template_path( 'subscription-update-default.php' );
	}

	/**
	 * Finish the update payment process.
	 *
	 * @since 2.13.0
	 * @param array $data The data passed to the function.
	 * @return void
	 */
	public function finish_update_payment( $data ) {
		$update_token = filter_input( INPUT_POST, 'update_token', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( empty( $update_token ) ) {
			return;
		}

		$passed_nonce = filter_input( INPUT_POST, 'edd_recurring_update_nonce', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( ! $passed_nonce || ! filter_input( INPUT_POST, '_wp_http_referer', FILTER_SANITIZE_SPECIAL_CHARS ) ) {
			wp_die( __( 'Invalid Payment Update', 'edd-recurring' ) );
		}

		$verified = wp_verify_nonce( $passed_nonce, 'update-payment' );
		if ( 1 !== $verified ) {
			wp_die( __( 'Unable to verify payment update. Please try again later.', 'edd-recurring' ) );
		}

		// Validate the token and get the subscription.
		$subscription_from_token = Link::validate_token( $update_token );
		if ( ! $subscription_from_token instanceof \EDD\Recurring\Subscriptions\Subscription ) {
			wp_die( __( 'Invalid or expired update link. Please try again.', 'edd-recurring' ) );
		}

		$subscription_id = filter_input( INPUT_POST, 'subscription_id', FILTER_VALIDATE_INT );
		if ( ! $subscription_id ) {
			wp_die( __( 'Invalid subscription ID.', 'edd-recurring' ) );
		}

		// Verify the subscription ID matches the token.
		if ( (int) $subscription_id !== (int) $subscription_from_token->id ) {
			wp_die( __( 'Subscription ID mismatch. Please try again.', 'edd-recurring' ) );
		}

		$subscription = edd_recurring_get_subscription( $subscription_id );
		if ( empty( $subscription->id ) ) {
			wp_die( __( 'Invalid subscription id.', 'edd-recurring' ) );
		}

		// Verify the subscription matches the token.
		if ( (int) $subscription->id !== (int) $subscription_from_token->id ) {
			wp_die( __( 'Subscription mismatch.', 'edd-recurring' ) );
		}

		$subscriber = new \EDD_Recurring_Subscriber( $subscription->customer_id );
		if ( empty( $subscriber->id ) ) {
			wp_die( __( 'Invalid subscriber.', 'edd-recurring' ) );
		}

		// Clear any existing errors before processing.
		edd_clear_errors();

		do_action( 'edd_recurring_update_' . $subscription->gateway . '_subscription', $subscriber, $subscription );

		$errors = edd_get_errors();
		if ( empty( $errors ) ) {
			edd_set_success( 'subscription-updated', __( 'Subscription payment method updated.', 'edd-recurring' ) );
		}

		// Redirect to success page.
		$redirect_url = home_url( $this->get_update_uri_base() . $update_token );

		edd_redirect( $redirect_url );
	}

	/**
	 * Render the subscription update form content.
	 *
	 * @since 2.13.0
	 * @param string $token The update token from the URL.
	 * @return void
	 */
	public function render_update_content( $token ) {
		if ( empty( $token ) ) {
			$this->render_error( __( 'This page is for updating payment methods. To update yours, please use the secure link that was provided to you.', 'edd-recurring' ) );

			return;
		}

		$subscription = Link::validate_token( $token );
		if ( ! $subscription instanceof Subscription ) {
			$this->render_error( __( 'The payment update link is invalid or has expired. Please try generating a new link or contact support.', 'edd-recurring' ) );

			return;
		}

		$errors = edd_get_errors();
		if ( ! empty( $errors ) || ! empty( EDD()->session->get( 'edd_success_errors' ) ) ) {
			edd_print_errors();

			return;
		}

		if ( ! $subscription->can_update() ) {
			$this->render_error( __( 'This subscription cannot be updated via this method.', 'edd-recurring' ) );

			return;
		}

		// All checks passed, prepare to load the form.
		$action_url      = home_url( 'subscription/update/' . $token );
		$subscription_id = $subscription->id;

		?>
		<p>
			<?php
			$price_id = is_numeric( $subscription->price_id ) ? $subscription->price_id : null;
			printf(
				/* translators: %s: download title */
				wp_kses_post( __( 'Use this form to update the payment method for <em>%s</em>.', 'edd-recurring' ) ),
				esc_html( edd_get_download_name( $subscription->product_id, $price_id ) )
			);
			?>
		</p>
		<form action="<?php echo esc_url( $action_url ); ?>" id="edd-recurring-form" method="POST">
			<input name="edd-recurring-update-gateway" type="hidden" value="<?php echo esc_attr( $subscription->gateway ); ?>" />
			<input name="update_token" type="hidden" value="<?php echo esc_attr( $token ); ?>" />
			<?php
			wp_nonce_field( 'update-payment', 'edd_recurring_update_nonce' );

			do_action( 'edd_recurring_before_update', $subscription_id );
			do_action( 'edd_recurring_update_payment_form', $subscription );
			do_action( 'edd_recurring_after_update', $subscription_id );
			?>

			<input type="hidden" name="edd_action" value="recurring_update_payment" />
			<input type="hidden" name="subscription_id" value="<?php echo absint( $subscription->id ); ?>" />
			<input type="hidden" name="redirect" value="<?php echo esc_url( $action_url ); ?>" />
			<input type="submit" name="edd-recurring-update-submit" id="edd-recurring-update-submit" value="<?php echo esc_attr( __( 'Update Payment Method', 'edd-recurring' ) ); ?>" />
		</form>
		<?php
	}

	/**
	 * Render an error message.
	 *
	 * @since 2.13.0
	 * @param string $message The error message.
	 * @return void
	 */
	private function render_error( string $message, $type = 'error' ) {
		?>
		<div class="edd-alert edd-alert-<?php echo esc_attr( $type ); ?> edd-recurring__update--<?php echo esc_attr( $type ); ?>">
			<p><?php echo esc_html( $message ); ?></p>
		</div>
		<?php
	}

	/**
	 * Get the template path, checking for theme overrides first.
	 *
	 * @since 2.13.0
	 * @param string $template_name Template filename.
	 * @return string
	 */
	private function get_template_path( $template_name ) {
		// Check if theme has override.
		$theme_template = locate_template(
			array(
				'edd_templates/' . $template_name,
				'edd-recurring/' . $template_name,
				$template_name,
			)
		);

		if ( $theme_template ) {
			return $theme_template;
		}

		// Use plugin template.
		$plugin_template = EDD_RECURRING_PLUGIN_DIR . 'templates/' . $template_name;
		if ( file_exists( $plugin_template ) ) {
			return $plugin_template;
		}

		// Fallback to default template.
		return EDD_RECURRING_PLUGIN_DIR . 'templates/subscription-update-default.php';
	}

	/**
	 * Get the subscription update URL base.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	public static function get_update_url_base() {
		return home_url( self::get_update_uri_base() );
	}

	/**
	 * Get the rewrite rule for the subscription update URL.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	private function get_update_rewrite_rule() {
		return apply_filters( 'edd_recurring_magic_link_rewrite_rule', $this->get_update_uri_base() . '(.*)/?' );
	}

	/**
	 * Get the rewrite URI for the subscription update URL.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	private function get_update_uri_base() {
		return trailingslashit( apply_filters( 'edd_recurring_magic_link_rewrite_uri', 'subscription/update/' ) );
	}

	/**
	 * Checks if the current page is the subscription update page.
	 *
	 * @since 2.13.1
	 * @return bool
	 */
	private function is_update_page() {
		return get_query_var( 'edd_recurring_update' ) && 'subscription-update' === get_query_var( 'pagename' );
	}
}
