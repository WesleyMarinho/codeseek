<?php
/**
 * @package     EDD\Recurring\Subscriptions
 * @copyright   Copyright Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Subscriptions;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Database\Row;

/**
 * The Subscription Class
 *
 * @since  2.4
 */
class Subscription extends Row {

	/**
	 * Subscription ID
	 *
	 * @var int
	 */
	protected $id = 0;

	/**
	 * Customer ID
	 *
	 * @var int
	 */
	protected $customer_id = 0;

	/**
	 * Subscription period
	 *
	 * @var string
	 */
	protected $period = '';

	/**
	 * Initial amount
	 *
	 * @var string
	 */
	protected $initial_amount = '';

	/**
	 * Initial tax rate
	 *
	 * @var string
	 */
	protected $initial_tax_rate = '';

	/**
	 * Initial tax
	 *
	 * @var string
	 */
	protected $initial_tax = '';

	/**
	 * Recurring amount
	 *
	 * @var string
	 */
	protected $recurring_amount = '';

	/**
	 * Recurring tax rate
	 *
	 * @var string
	 */
	protected $recurring_tax_rate = '';

	/**
	 * Recurring tax
	 *
	 * @var string
	 */
	protected $recurring_tax = '';

	/**
	 * Number of times to bill
	 *
	 * @var int
	 */
	protected $bill_times = 0;

	/**
	 * Transaction ID
	 *
	 * @var string
	 */
	protected $transaction_id = '';

	/**
	 * Parent payment ID
	 *
	 * @var int
	 */
	protected $parent_payment_id = 0;

	/**
	 * Product ID
	 *
	 * @var int
	 */
	protected $product_id = 0;

	/**
	 * Price ID
	 *
	 * @var int
	 */
	protected $price_id = null;

	/**
	 * Created date.
	 *
	 * @todo This property will be changed to date_created in a future release.
	 *
	 * @var string
	 */
	protected $created;

	/**
	 * Modified date.
	 *
	 * @var string
	 */
	protected $date_modified;

	/**
	 * Expiration date
	 *
	 * @var string
	 */
	protected $expiration;

	/**
	 * Trial period
	 *
	 * @var string
	 */
	protected $trial_period;

	/**
	 * Status
	 *
	 * @var string
	 */
	protected $status = 'pending';

	/**
	 * Profile ID
	 *
	 * @var string
	 */
	protected $profile_id = '';

	/**
	 * Gateway
	 *
	 * @var string
	 */
	protected $gateway = '';

	/**
	 * Notes
	 *
	 * @var array
	 */
	// protected $notes = array();

	/**
	 * The Customer object.
	 *
	 * @var EDD_Customer $customer
	 */
	protected $customer;

	/**
	 * Get us started
	 *
	 * @since  2.4
	 *
	 * @param int|object $_id_or_object Subscription ID or object.
	 * @param bool       $_by_profile_id Whether to get the subscription by profile ID.
	 */
	public function __construct( $_id_or_object = 0, $_by_profile_id = false ) {

		if ( $_by_profile_id ) {
			$_sub = edd_recurring_get_subscription_by( 'profile_id', $_id_or_object );

			if ( empty( $_sub ) ) {
				return;
			}

			$_id_or_object = $_sub;
		}

		$this->setup_subscription( $_id_or_object );
	}

	/**
	 * Magic getter.
	 *
	 * @since 2.4
	 */
	public function __get( $key = '' ) {
		if ( 'date_created' === $key ) {
			return $this->created;
		}

		return parent::__get( $key );
	}

	/**
	 * Magic setter. Since properties are not public, we need to use this to set them for backwards compatibility.
	 *
	 * @since 2.13.0
	 */
	public function __set( $key = '', $value = '' ) {
		if ( property_exists( $this, $key ) ) {
			$this->$key = $value;
		}

		return null;
	}

	/**
	 * Setup the subscription object
	 *
	 * @since  2.4
	 *
	 * @param  int|object $id_or_object Subscription ID or object.
	 *
	 * @return EDD_Subscription|bool
	 */
	private function setup_subscription( $id_or_object = 0 ) {
		if ( empty( $id_or_object ) ) {
			return false;
		}

		if ( is_numeric( $id_or_object ) ) {
			$sub = edd_recurring_get_subscription( $id_or_object );
		} elseif ( is_object( $id_or_object ) ) {
			$sub = $id_or_object;
		}

		if ( empty( $sub ) ) {
			return false;
		}

		foreach ( $sub as $key => $value ) {
			$this->$key = $value;
		}

		$this->customer = new \EDD_Customer( $this->customer_id );
		if ( empty( $this->gateway ) ) {
			$this->gateway = edd_get_payment_gateway( $this->parent_payment_id );
		}

		/**
		 * Fires after a subscription is setup
		 *
		 * @param EDD_Subscription $this The subscription object.
		 */
		do_action( 'edd_recurring_setup_subscription', $this );

		return $this;
	}

	/**
	 * Creates a subscription
	 *
	 * @since  2.4
	 * @param  array $data Array of attributes for a subscription.
	 * @return mixed  false if data isn't passed and class not instantiated for creation.
	 */
	public function create( $data = array() ) {
		if ( ! empty( $this->id ) ) {
			return false;
		}

		$defaults = array(
			'customer_id'        => 0,
			'period'             => '',
			'initial_amount'     => '',
			'initial_tax_rate'   => '',
			'initial_tax'        => '',
			'recurring_amount'   => '',
			'recurring_tax_rate' => '',
			'recurring_tax'      => '',
			'bill_times'         => 0,
			'parent_payment_id'  => 0,
			'product_id'         => 0,
			'price_id'           => null,
			'created'            => '',
			'expiration'         => '',
			'status'             => '',
			'profile_id'         => '',
			'gateway'            => '',
		);

		$args = wp_parse_args( $data, $defaults );

		// Remove the ID if it's passed in.
		if ( ! empty( $args['id'] ) ) {
			unset( $args['id'] );
		}

		// Force an active subscription to expired if expiration date is in the past.
		if ( $args['expiration'] && strtotime( 'NOW', current_time( 'timestamp' ) ) > strtotime( $args['expiration'], current_time( 'timestamp' ) ) ) {
			if ( in_array( $args['status'], array( 'active', 'trialling' ), true ) ) {
				$args['status'] = 'expired';
			}
		}

		if ( empty( $args['gateway'] ) ) {
			$args['gateway'] = edd_get_payment_gateway( $this->parent_payment_id );
		}

		/**
		 * Fires before a subscription is created.
		 *
		 * @param array $args Array of subscription data.
		 */
		do_action( 'edd_subscription_pre_create', $args );

		$id = edd_recurring_add_subscription( $args );

		/**
		 * Fires after a subscription is created
		 *
		 * @param int $id The ID of the subscription that was created.
		 * @param array $args Array of subscription data.
		 */
		do_action( 'edd_subscription_post_create', $id, $args );

		$this->set_status( $args['status'] );

		return $this->setup_subscription( $id );
	}

	/**
	 * Updates a subscription
	 *
	 * @since  2.4
	 * @param  array $args Array of fields to update.
	 * @return bool
	 */
	public function update( $args = array() ) {
		$current_product  = $this->product_id;
		$current_price_id = $this->price_id;

		$ret = edd_recurring_update_subscription( $this->id, $args );

		if ( $ret ) {
			if ( isset( $args['status'] ) ) {
				$this->set_status( $args['status'] );
			}

			if ( isset( $args['product_id'] ) && $current_product != $args['product_id'] ) {
				/* translators: 1. the current product ID; 2. the new product ID */
				$this->add_note( sprintf( __( 'Product ID changed from %1$d to %2$d.', 'edd-recurring' ), $current_product, $args['product_id'] ) );
			}

			if ( isset( $args['price_id'] ) && ! is_null( $args['price_id'] ) && $current_price_id != $args['price_id'] ) {
				/* translators: 1. the current price ID; 2. the new price ID */
				$this->add_note( sprintf( __( 'Price ID changed from %1$d to %2$d.', 'edd-recurring' ), $current_price_id, $args['price_id'] ) );
			}
		}

		// Clear the object cache for this subscription.
		wp_cache_delete( $this->id, 'edd_subscription_objects' );

		/**
		 * Fires after a subscription is updated
		 *
		 * @param int $id The ID of the subscription that was updated.
		 * @param array $args Array of subscription data.
		 * @param EDD_Subscription $this The subscription object that was updated.
		 */
		do_action( 'edd_recurring_update_subscription', $this->id, $args, $this );

		return $ret;
	}

	/**
	 * Delete the subscription
	 *
	 * @since  2.4
	 * @return bool
	 */
	public function delete() {
		/**
		 * Fires before a subscription is deleted
		 *
		 * @param EDD_Subscription $this The subscription object that is being deleted.
		 */
		do_action( 'edd_recurring_before_delete_subscription', $this );

		$deleted = edd_recurring_delete_subscription( $this->id );

		/**
		 * Fires after a subscription is deleted
		 *
		 * @param bool $deleted True if the subscription was deleted, false otherwise.
		 * @param EDD_Subscription $this The subscription object that was deleted.
		 */
		do_action( 'edd_recurring_after_delete_subscription', $deleted, $this );

		wp_cache_delete( $this->id, 'edd_subscription_objects' );

		return $deleted;
	}

	/**
	 * Retrieves the parent payment ID
	 *
	 * @since  2.4
	 * @return int
	 */
	public function get_original_payment_id() {
		return $this->parent_payment_id;
	}

	/**
	 * Retrieve renewal payments for a subscription
	 *
	 * @since  2.4
	 * @deprecated 2.12.0
	 * @return EDD_Payment[]
	 */
	public function get_child_payments() {
		// EDD 3.0 maps these to the correct order parameters.
		$payments = edd_get_payments(
			array(
				'post_parent'    => (int) $this->parent_payment_id,
				'posts_per_page' => '999',
				'post_status'    => 'any',
				'post_type'      => 'edd_payment',
				'meta_key'       => 'subscription_id',
				'meta_value'     => $this->id,
				'output'         => 'payments',
			)
		);

		return (array) $payments;
	}

	/**
	 * Get the renewal orders for a subscription.
	 *
	 * @since 2.12.0
	 * @param array $args Optional args to get renewal orders.
	 * @return array
	 */
	public function get_renewal_orders( $args = array() ) {
		return edd_get_orders(
			wp_parse_args(
				$args,
				array(
					'parent'     => $this->parent_payment_id,
					'type'       => 'sale',
					'number'     => 999,
					'status__in' => edd_get_complete_order_statuses(),
					'meta_query' => array(
						array(
							'key'   => 'subscription_id',
							'value' => $this->id,
						),
					),
				)
			)
		);
	}

	/**
	 * Counts the number of payments made to the subscription
	 *
	 * @since  2.4
	 * @return int
	 */
	public function get_total_payments() {
		return edd_count_orders(
			array(
				'parent'     => $this->parent_payment_id,
				'type'       => 'sale',
				'meta_query' => array(
					array(
						'key'   => 'subscription_id',
						'value' => $this->id,
					),
				),
			)
		) + 1;
	}

	/**
	 * Returns the number of times the subscription has been billed
	 *
	 * @since  2.6
	 * @return int
	 */
	public function get_times_billed() {

		$orders = edd_count_orders(
			array(
				'parent'     => $this->parent_payment_id,
				'status__in' => edd_get_complete_order_statuses(),
				'meta_query' => array(
					array(
						'key'   => 'subscription_id',
						'value' => $this->id,
					),
				),
				'type'       => 'sale',
			)
		);

		// If there is no trial, add in the original order.
		if ( empty( $this->trial_period ) ) {
			++$orders;
		}

		return $orders;
	}

	/**
	 * Gets the lifetime value for the subscription
	 *
	 * @since  2.4
	 * @return float
	 */
	public function get_lifetime_value() {

		$amount               = 0.00;
		$has_item_signup_fee  = false;
		$original_order_items = edd_get_order_items(
			array(
				'order_id'       => $this->parent_payment_id,
				'product_id'     => $this->product_id,
				'status__not_in' => array( 'refunded', 'pending', 'abandoned', 'failed' ),
			)
		);
		foreach ( $original_order_items as $item ) {
			$amount += $item->total;

			// Check for any signup fees or fees from Discounts Pro.
			$fees = edd_get_order_adjustments(
				array(
					'object_id'   => $item->id,
					'object_type' => 'order_item',
					'type'        => 'fee',
				)
			);
			if ( $fees ) {
				foreach ( $fees as $fee ) {
					if ( false !== strpos( $fee->type_key, 'signup_fee_' ) ) {
						$has_item_signup_fee = true;
						$amount             += $fee->amount;
					}
					if ( false !== strpos( $fee->type_key, 'dp_' ) ) {
						$amount += $fee->amount;
					}
				}
			}
		}

		// Historically, Recurring assumed that there was just one signup fee per order.
		if ( ! $has_item_signup_fee ) {
			$order_fees = edd_get_order_adjustments(
				array(
					'object_id'   => $this->parent_payment_id,
					'object_type' => 'order',
					'type'        => 'fee',
					'type_key'    => 'signup_fee',
				)
			);
			if ( $order_fees ) {
				foreach ( $order_fees as $fee ) {
					$amount += $fee->amount;
				}
			}
		}

		$renewal_orders = $this->get_renewal_orders();
		if ( $renewal_orders ) {
			foreach ( $renewal_orders as $renewal_order ) {
				$amount += $renewal_order->total;
			}
		}

		return $amount;
	}

	/**
	 * Records a new payment on the subscription
	 *
	 * @since  2.4
	 * @param  array $args Array of values for the payment, including amount and transaction ID.
	 * @return bool|integer False if no payment is crated, or the payment ID if successful.
	 */
	public function add_payment( $args = array() ) {

		$original_order = edd_get_order( $this->parent_payment_id );
		if ( ! $original_order ) {
			edd_debug_log( 'EDD_Subscription::add_payment() - Original order not found for subscription #' . $this->id );
			return false;
		}

		/**
		 * For our default date, in case it isn't passed in, we need to determine if we
		 * are on EDD 2.x or 3.x, and account for the current_time being in GMT/UTC.
		 *
		 * EDD 3.0+ stores all dates in GMT/UTC, but current_time() defaults to using the WordPress timezone.
		 *
		 * Since we are updating all webhooks to send in a date, they are already accounting for this.
		 * This default will just be for anyone calling add_payment without the date argument.
		 */
		$use_gmt = true;

		$default_arguments = array(
			'amount'         => '', // This is the full amount that was charged at the gateway, INCLUDING tax.
			'tax'            => '', // This is going to be blank since 2.8, where taxes were no longer sent to the gateway. The only exception is when doing a manual renewal through the EDD subscription single view.
			'transaction_id' => '',
			'gateway'        => '',
			'date'           => current_time( 'mysql', $use_gmt ),
		);

		$args = wp_parse_args( $args, $default_arguments );
		$args = apply_filters( 'edd_recurring_add_payment_pre_args', $args, $this );

		if ( $this->payment_exists( $args['transaction_id'] ) ) {
			return false;
		}

		$parent               = edd_get_order( $this->parent_payment_id );
		$args['parent']       = $this->parent_payment_id;
		$args['customer_id']  = $parent->customer_id;
		$args['user_id']      = $parent->user_id;
		$args['currency']     = $parent->currency;
		$args['rate']         = $parent->rate;
		$args['status']       = 'edd_subscription';
		$args['total']        = edd_sanitize_amount( sanitize_text_field( $args['amount'] ) );
		$args['mode']         = $parent->mode;
		$args['date_created'] = $args['date'];
		$args['tax_rate_id']  = $parent->tax_rate_id;
		$args['order_number'] = edd_set_order_number();

		if ( empty( $args['gateway'] ) ) {
			$args['gateway'] = $parent->gateway;
		}

		$email    = $parent->email;
		$customer = edd_get_customer( $parent->customer_id );
		if ( ! empty( $customer->email ) ) {
			$email = $customer->email;
		}
		$args['email'] = $email;
		$args['key']   = $this->generate_order_payment_key( $email );

		$tax = 0;
		if ( ! empty( $args['tax'] ) ) {
			$tax = $args['tax'];
		} elseif ( ! empty( $this->recurring_tax_rate ) ) {
			// The $args['amount'] includes the tax. We need to calculate the tax as though it is included in the amount.
			$tax = $args['amount'] - ( $args['amount'] / ( 1 + $this->recurring_tax_rate ) );
		} elseif ( ! empty( $this->recurring_tax ) ) {
			$tax = $this->recurring_tax;
		}
		$args['tax']      = edd_sanitize_amount( sanitize_text_field( $tax ) );
		$args['subtotal'] = edd_sanitize_amount( sanitize_text_field( $args['total'] - $tax ) );

		if ( ! empty( $this->recurring_tax_rate ) ) {
			$args['tax_rate'] = $this->recurring_tax_rate;
		}

		// Add the order to the database.
		$order_id = edd_add_order( $args );

		$this->maybe_add_order_address( $order_id, $parent, $customer );

		// Set the order transaction ID.
		edd_set_payment_transaction_id( $order_id, $args['transaction_id'] );

		// Set the amount for the renewal order based on the inclusive/exclusive of tax setting.
		if ( edd_prices_include_tax() ) {
			$amount = $args['amount'];
		} else {
			$amount = $args['amount'] - $tax;
		}
		$order_item_args = array(
			'order_id'     => $order_id,
			'amount'       => $amount,
			'subtotal'     => $args['subtotal'],
			'total'        => $args['amount'],
			'tax'          => $tax,
			'price_id'     => $this->price_id,
			'product_id'   => $this->product_id,
			'product_name' => edd_get_download_name( $this->product_id, $this->price_id ),
			'quantity'     => 1,
			'status'       => 'complete',
		);
		edd_add_order_item( $order_item_args );
		edd_update_order_meta( $order_id, 'subscription_id', $this->id );

		// Some VAT plugins save the tax rate to the order meta. If it exists, use it.
		$custom_tax_rate = edd_get_order_meta( $parent->id, 'tax_rate', true );
		if ( ! empty( $custom_tax_rate ) ) {
			edd_update_order_meta( $order_id, 'tax_rate', sanitize_text_field( $custom_tax_rate ) );
		}

		// Schedule the after payments actions for the order.
		$deferred_actions = new \EDD\Orders\DeferredActions();
		$deferred_actions->schedule_deferred_actions( $order_id );

		// Backwards compatible hook. This is deprecated in favor of edd_recurring_add_subscription_order.
		if ( has_action( 'edd_recurring_add_subscription_payment' ) ) {
			$payment = edd_get_payment( $order_id );
			do_action( 'edd_recurring_add_subscription_payment', $payment, $this );
		}

		/**
		 * Fires after a subscription order is added.
		 *
		 * @since 2.12.0
		 * @param EDD\Orders\Order $renewal_order The renewal order.
		 * @param EDD_Subscription  $subscription  The subscription.
		 */
		do_action( 'edd_recurring_add_subscription_order', edd_get_order( $order_id ), $this );

		/**
		 * Fires after a subscription payment is added.
		 *
		 * This is a legacy hook for the 'Payment', a legacy terminology.
		 * If you're writing for EDD 3.0+ use edd_recurring_add_subscription_order instead.
		 *
		 * @param int $order_id The ID of the order.
		 * @param int $initial_payment_id The ID of the initial payment.
		 * @param float $amount The amount of the payment.
		 * @param string $transaction_id The transaction ID of the payment.
		 */
		do_action( 'edd_recurring_record_payment', $order_id, $this->parent_payment_id, $args['amount'], $args['transaction_id'] );

		return $order_id;
	}

	/**
	 * Retrieves the transaction ID from the subscription
	 *
	 * @since  2.4.4
	 * @return bool
	 */
	public function get_transaction_id() {
		if ( empty( $this->transaction_id ) ) {
			$txn_id = edd_get_payment_transaction_id( $this->parent_payment_id );

			if ( ! empty( $txn_id ) && (int) $this->parent_payment_id !== (int) $txn_id ) {
				$this->set_transaction_id( $txn_id );
			}
		}

		return $this->transaction_id;
	}

	/**
	 * Stores the transaction ID for the subscription purchase
	 *
	 * @since  2.4.4
	 *
	 * @param string $txn_id The transaction ID to store.
	 */
	public function set_transaction_id( $txn_id = '' ) {
		$this->update( array( 'transaction_id' => $txn_id ) );
		$this->transaction_id = $txn_id;
	}

	/**
	 * Renews a subscription.
	 *
	 * @since  2.4
	 * @param int $payment_id The payment ID to renew the subscription with.
	 * @return void
	 */
	public function renew( $payment_id = 0 ) {
		// If there is no payment ID, or the payment ID is not a renewal, bail.
		if ( empty( $payment_id ) || 'edd_subscription' !== edd_get_payment_status( $payment_id ) ) {
			return;
		}

		$expires = $this->get_expiration_time();

		// Determine what date to use as the start for the new expiration calculation.
		if ( $expires > current_time( 'timestamp' ) && $this->is_active() ) {
			$base_date = $expires;
		} else {
			$base_date = current_time( 'timestamp' );
		}

		$last_day   = cal_days_in_month( CAL_GREGORIAN, date( 'n', $base_date ), date( 'Y', $base_date ) );
		$period     = strtolower( $this->period );
		$expiration = '';

		switch ( $period ) {
			case 'quarter':
				$expiration = date( 'Y-m-d H:i:s', strtotime( '+3 months 23:59:59', $base_date ) );
				break;
			case 'semi-year':
				$expiration = date( 'Y-m-d H:i:s', strtotime( '+3 months 23:59:59', $base_date ) );
				break;
			default:
				if ( $last_day === date( 'j', $base_date ) && 'day' !== $period ) {
					$expiration = date( 'Y-m-d H:i:s', strtotime( $expiration . ' +2 days' ) );
				} else {
					$expiration = date( 'Y-m-d H:i:s', strtotime( '+1 ' . $this->period . ' 23:59:59', $base_date ) );
				}
				break;
		}

		/**
		 * Filter the expiration date for a subscription renewal
		 *
		 * @param string $expiration The expiration date for the subscription renewal.
		 * @param int    $subscription_id The ID of the subscription being renewed.
		 * @param EDD_Subscription $subscription The subscription object being renewed.
		 *
		 * @return string The expiration date for the subscription renewal.
		 */
		$expiration = apply_filters( 'edd_subscription_renewal_expiration', $expiration, $this->id, $this );

		// If a timestamp is passed in here, convert it to a date formatted string.
		if ( is_numeric( $expiration ) ) {
			$expiration = date( 'Y-m-d H:i:s', $expiration );
		}

		/**
		 * Fires before a subscription is renewed
		 *
		 * @param int    $subscription_id The ID of the subscription being renewed.
		 * @param string $expiration The expiration date for the subscription renewal.
		 * @param EDD_Subscription $subscription The subscription object being renewed.
		 */
		do_action( 'edd_subscription_pre_renew', $this->id, $expiration, $this );

		$times_billed = $this->get_times_billed();

		$args = array(
			'expiration' => $expiration,
			'status'     => 'active',
		);

		$this->update( $args );

		// Complete subscription if applicable.
		if ( $this->bill_times > 0 && $times_billed >= $this->bill_times ) {
			$this->complete();
			$this->status = 'completed';
		}

		// Get a fresh copy of the subscription to ensure we have the latest data.
		$this->setup_subscription( $this->id );

		/**
		 * Fires after a subscription is renewed
		 *
		 * @param int    $subscription_id The ID of the subscription being renewed.
		 * @param string $expiration The expiration date for the subscription renewal.
		 * @param EDD_Subscription $subscription The subscription object being renewed.
		 * @param int    $payment_id The payment ID used to renew the subscription.
		 */
		do_action( 'edd_subscription_post_renew', $this->id, $expiration, $this, $payment_id );

		/**
		 * Allows modifying the subscription status after a renewal is processed.
		 *
		 * @param int   $subscription_id The ID of the subscription being renewed.
		 * @param string $status The status of the subscription after renewal.
		 * @param EDD_Subscription $subscription The subscription object being renewed.
		 */
		do_action( 'edd_recurring_set_subscription_status', $this->id, $this->status, $this );
	}

	/**
	 * Marks a subscription as completed
	 *
	 * Subscription is completed when the number of payments matches the billing_times field
	 *
	 * @since  2.4
	 * @return void
	 */
	public function complete() {
		// Prevent setting a subscription as complete if it was previously set as cancelled, except if the sub is being manually updated by the site owner.
		if ( 'cancelled' === $this->status && ! isset( $_POST['edd_update_subscription'] ) && empty( $_POST['edd_update_subscription'] ) ) {
			return;
		}

		$args = array(
			'status' => 'completed',
		);

		if ( $this->update( $args ) ) {
			/**
			 * Fires when a subscription is completed
			 *
			 * @param int $subscription_id The ID of the subscription being completed.
			 * @param EDD_Subscription $subscription The subscription object being completed.
			 */
			do_action( 'edd_subscription_completed', $this->id, $this );
		}
	}

	/**
	 * Marks a subscription as expired
	 *
	 * Subscription is completed when the billing times is reached
	 *
	 * @since  2.4
	 * @param bool $check_expiration True if expiration date should be checked with merchant processor before expiring.
	 * @return bool
	 */
	public function expire( $check_expiration = false ) {
		$expiration = $this->expiration;

		if ( $check_expiration && $this->check_expiration() ) {
			// check_expiration() updates $this->expiration so compare to $expiration above.
			if ( $expiration < $this->get_expiration() && current_time( 'timestamp' ) < $this->get_expiration_time() ) {
				return false; // Do not mark as expired since real expiration date is in the future.
			}
		}

		$args = array(
			'status' => 'expired',
		);

		if ( $this->update( $args ) ) {
			/**
			 * Fires when a subscription is expired
			 *
			 * @param int $subscription_id The ID of the subscription being expired.
			 * @param EDD_Subscription $subscription The subscription object being expired.
			 */
			do_action( 'edd_subscription_expired', $this->id, $this );
		}
	}

	/**
	 * Marks a subscription as failing
	 *
	 * @since  2.4.2
	 * @return void
	 */
	public function failing() {

		if ( 'failing' === $this->status ) {
			return;
		}

		// If the subscription is already failing or cancelled, do not mark it as failing.
		$can_update = ! in_array( $this->status, array( 'cancelled', 'failing' ), true );
		// If the subscription cannot be updated, check if the current user can update the subscription.
		if ( ! $can_update ) {
			$can_update = is_admin() && $this->current_user_can();
		}

		if ( ! $can_update ) {
			$this->add_note(
				sprintf(
					/* translators: %s: subscription status */
					__( 'The subscription cannot be set to failing because its status is %s.', 'edd-recurring' ),
					$this->status
				)
			);
			return;
		}

		$args = array(
			'status' => 'failing',
		);

		if ( $this->update( $args ) ) {
			/**
			 * Fires when a subscription is failing
			 *
			 * @param int $subscription_id The ID of the subscription being marked as failing.
			 * @param EDD_Subscription $subscription The subscription object being marked as failing.
			 */
			do_action( 'edd_subscription_failing', $this->id, $this );
		}
	}

	/**
	 * Marks a subscription as cancelled
	 *
	 * @since  2.4
	 * @return void
	 */
	public function cancel() {
		// Prevent setting a subscription as cancelled if it was previously set as cancelled or expired.
		if ( ! in_array( $this->status, edd_recurring_get_cancellable_statuses(), true ) ) {
			return;
		}

		/**
		 * Gateway specific hook for cancelling a subscription.
		 *
		 * @param EDD_Subscription $subscription The subscription object being cancelled.
		 * @param bool $is_manual True if the subscription is being manually cancelled by the site owner.
		 */
		do_action( 'edd_recurring_cancel_' . $this->gateway . '_subscription', $this, true );

		// Get a fresh copy of the subscription to ensure we have the latest data.
		$this->setup_subscription( $this->id );
		if ( 'needs_attention' === $this->status ) {
			return;
		}

		$updated = $this->update(
			array(
				'status' => 'cancelled',
			)
		);
		if ( ! $updated ) {
			return;
		}

		// Add the gmt timestamp to the subscription metadata.
		$this->maybe_add_time_meta( 'cancelled' );

		if ( is_user_logged_in() ) {
			$userdata = get_userdata( get_current_user_id() );
			$user     = $userdata->user_login;
		} else {
			$user = __( 'gateway', 'edd-recurring' );
		}

		/* translators: 1. the subscription ID; 2. the user who cancelled the subscription. */
		$note = sprintf( __( 'Subscription #%1$d cancelled by %2$s', 'edd-recurring' ), $this->id, $user );
		$this->add_note( $note );

		edd_recurring_delete_subscription_meta( $this->id, 'cancel_by' );

		/**
		 * Fires when a subscription is cancelled
		 *
		 * @param int $subscription_id The ID of the subscription being cancelled.
		 * @param EDD_Subscription $subscription The subscription object being cancelled.
		 */
		do_action( 'edd_subscription_cancelled', $this->id, $this );
	}

	/**
	 * Determines if subscription can be cancelled
	 *
	 * This method is filtered by payment gateways in order to return true on subscriptions
	 * that can be cancelled with a profile ID through the merchant processor
	 *
	 * @since  2.4
	 * @return bool
	 */
	public function can_cancel() {
		if ( $this->is_cancellation_scheduled() ) {
			return false;
		}

		/**
		 * Filter to determine if a subscription can be cancelled
		 *
		 * @param bool $can_cancel True if the subscription can be cancelled, false otherwise.
		 * @param EDD_Subscription $subscription The subscription object being checked for cancellation.
		 */
		return apply_filters( 'edd_subscription_can_cancel', false, $this );
	}

	/**
	 * Retrieves the URL to cancel subscription
	 *
	 * @since  2.4
	 * @return string
	 */
	public function get_cancel_url() {
		$url = '';
		if ( in_array( $this->status, edd_recurring_get_cancellable_statuses(), true ) ) {
			$url = wp_nonce_url(
				add_query_arg(
					array(
						'edd_action' => 'cancel_subscription',
						'sub_id'     => $this->id,
					)
				),
				"edd-recurring-cancel-{$this->id}"
			);
		}

		/**
		 * Filter the URL to cancel a subscription
		 *
		 * @param string $url The URL to cancel the subscription.
		 * @param EDD_Subscription $subscription The subscription object to generate a cancellation URL for.
		 */
		return apply_filters( 'edd_subscription_cancel_url', $url, $this );
	}

	/**
	 * Determines if subscription can be manually renewed
	 *
	 * This method is filtered by payment gateways in order to return true on subscriptions
	 * that can be renewed manually
	 *
	 * @since  2.5
	 * @return bool
	 */
	public function can_renew() {
		if ( $this->is_cancellation_scheduled() ) {
			return false;
		}

		/**
		 * Filter to determine if a subscription can be renewed
		 *
		 * @param bool $can_renew True if the subscription can be renewed, false otherwise.
		 * @param EDD_Subscription $subscription The subscription object being checked for renewal.
		 */
		return apply_filters( 'edd_subscription_can_renew', false, $this );
	}

	/**
	 * Retrieves the URL to renew a subscription
	 *
	 * @since  2.5
	 * @return string
	 */
	public function get_renew_url() {
		if ( $this->is_cancellation_scheduled() ) {
			return '';
		}

		$url = wp_nonce_url(
			add_query_arg(
				array(
					'edd_action' => 'renew_subscription',
					'sub_id'     => $this->id,
				)
			),
			"edd-recurring-renew-{$this->id}"
		);

		/**
		 * Filter the URL to renew a subscription
		 *
		 * @param string $url The URL to renew the subscription.
		 * @param EDD_Subscription $subscription The subscription object to generate a renewal URL for.
		 */
		return apply_filters( 'edd_subscription_renew_url', $url, $this );
	}

	/**
	 * Determines if subscription can have their payment method updated
	 *
	 * @since  2.4
	 * @return bool
	 */
	public function can_update() {
		if ( $this->is_cancellation_scheduled() ) {
			return false;
		}

		/**
		 * Filter to determine if a subscription can have their payment method updated
		 *
		 * @param bool $can_update True if the subscription can have their payment method updated, false otherwise.
		 * @param EDD_Subscription $subscription The subscription object being checked for payment method update.
		 */
		return apply_filters( 'edd_subscription_can_update', false, $this );
	}

	/**
	 * Retrieves the URL to update subscription
	 *
	 * @since  2.4
	 * @return string
	 */
	public function get_update_url() {

		$url = add_query_arg(
			array(
				'action'          => 'update',
				'subscription_id' => $this->id,
			)
		);

		/**
		 * Filter the URL to update a subscription
		 *
		 * @param string $url The URL to update the subscription.
		 * @param EDD_Subscription $subscription The subscription object to generate an update URL for.
		 */
		return apply_filters( 'edd_subscription_update_url', $url, $this );
	}

	/**
	 * Determines if subscription can be reactivated
	 *
	 * This method is filtered by payment gateways in order to return true on subscriptions
	 * that can be reactivated with a profile ID through the merchant processor
	 *
	 * @since  2.7.10
	 * @return bool
	 */
	public function can_reactivate() {
		if ( $this->is_cancellation_scheduled() ) {
			return false;
		}

		/**
		 * Filter to determine if a subscription can be reactivated
		 *
		 * @param bool $can_reactivate True if the subscription can be reactivated, false otherwise.
		 * @param EDD_Subscription $subscription The subscription object being checked for reactivation.
		 */
		return apply_filters( 'edd_subscription_can_reactivate', false, $this );
	}

	/**
	 * Retrieves the URL to reactivate subscription
	 *
	 * @since  2.7.10
	 * @return string
	 */
	public function get_reactivation_url() {

		$url = wp_nonce_url(
			add_query_arg(
				array(
					'edd_action' => 'reactivate_subscription',
					'sub_id'     => $this->id,
				)
			),
			"edd-recurring-reactivate-{$this->id}"
		);

		/**
		 * Filter the URL to reactivate a subscription
		 *
		 * @param string $url The URL to reactivate the subscription.
		 * @param EDD_Subscription $subscription The subscription object to generate a reactivation URL for.
		 */
		return apply_filters( 'edd_subscription_reactivation_url', $url, $this );
	}


	/**
	 * Determines if subscription can be retried when failing.
	 *
	 * This method is filtered by payment gateways in order to return true on subscriptions
	 * that can be retried with a profile ID through the merchant processor
	 *
	 * @since  2.7.10
	 * @return bool
	 */
	public function can_retry() {
		/**
		 * Filter to determine if a subscription can be retried
		 *
		 * @param bool $can_retry True if the subscription can be retried, false otherwise.
		 * @param EDD_Subscription $subscription The subscription object being checked for retry.
		 */
		return apply_filters( 'edd_subscription_can_retry', false, $this );
	}

	/**
	 * Retries a failing subscription
	 *
	 * @since  2.7.10
	 * @return bool|WP_Error
	 */
	public function retry() {
		// Only mark a subscription as complete if it's not already cancelled.
		if ( ! $this->can_retry() ) {
			return new \WP_Error( 'edd_recurring_not_failing', __( 'This subscription is not failing so cannot be retried.', 'edd-recurring' ) );
		}

		$result = false;

		/**
		 * Filter the response and allow gateways to hook in to handle the retry.
		 *
		 * This result is expected to be true or an instance of WP_Error on failure.
		 *
		 * @since  2.8
		 */
		$result = apply_filters( 'edd_recurring_retry_subscription_' . $this->gateway, $result, $this );

		/**
		 * Fires after the retry action has been attempted.
		 *
		 * @param int $subscription_id The ID of the subscription being retried.
		 * @param EDD_Subscription $subscription The subscription object being retried.
		 */
		do_action( 'edd_subscription_retry', $this->id, $this );

		if ( ! $result ) {
			// Set up a generic error response.
			$result = new \WP_Error( 'edd_recurring_retry_failed', __( 'An error was encountered. Please check your merchant account logs.', 'edd-recurring' ) );
		}

		return $result;
	}

	/**
	 * Retrieves the URL to retry a failing subscription
	 *
	 * @since  2.7.10
	 * @return string
	 */
	public function get_retry_url() {
		$url = wp_nonce_url(
			add_query_arg(
				array(
					'edd_action' => 'retry_subscription',
					'sub_id'     => $this->id,
				)
			),
			"edd-recurring-retry-{$this->id}"
		);

		/**
		 * Filter the URL to retry a subscription
		 *
		 * @param string $url The URL to retry the subscription.
		 * @param EDD_Subscription $subscription The subscription object to generate a retry URL for.
		 */
		return apply_filters( 'edd_subscription_retry_url', $url, $this );
	}

	/**
	 * Determines if subscription is active
	 *
	 * @since  2.4
	 * @return bool
	 */
	public function is_active() {
		$is_active = false;
		if ( in_array( $this->status, $this->get_active_statuses(), true ) && ! $this->is_expired() ) {
			$is_active = true;
		}

		/**
		 * Filter to determine if a subscription is active.
		 *
		 * @param bool $is_active Whether or not the subscription is active.
		 * @param int $subscription_id The ID of the subscription.
		 * @param EDD_Subscription $subscription The subscription object.
		 */
		return apply_filters( 'edd_subscription_is_active', $is_active, $this->id, $this );
	}

	/**
	 * Determines if subscription is expired
	 *
	 * @since  2.4
	 * @return bool
	 */
	public function is_expired() {
		$is_expired = false;

		if ( 'expired' === $this->status ) {
			$is_expired = true;
		} elseif ( in_array( $this->status, array( 'active', 'cancelled', 'trialling' ), true ) ) {

			$expiration = $this->get_expiration_time();
			if ( $expiration && strtotime( 'NOW', current_time( 'timestamp' ) ) > $expiration ) {
				$is_expired = true;
				if ( 'active' === $this->status || 'trialling' === $this->status ) {
					$this->expire();
				}
			}
		}

		/**
		 * Filter to allow the expiration status to be overridden.
		 *
		 * @param bool $is_expired Whether the subscription is expired
		 * @param int  $id         Subscription ID
		 * @param EDD_Subscription $subscription Subscription object
		 */
		return apply_filters( 'edd_subscription_is_expired', $is_expired, $this->id, $this );
	}

	/**
	 * Retrieves the expiration date
	 *
	 * @since  2.4
	 * @return string
	 */
	public function get_expiration() {
		return $this->expiration;
	}

	/**
	 * Checks the expiration date and returns the new date if it is different
	 *
	 * Will return true only if the expiration date retrieved is further in the future of the existing date.
	 *
	 * @since  2.6.6
	 * @return bool True if expiration changes
	 */
	public function check_expiration() {
		$ret = false;

		$gateway = edd_recurring()->get_gateway( $this->gateway );

		// If we have a gateway class, and the 'get_expiration' method can be called, then we can check the expiration.
		if ( $gateway && is_callable( array( $gateway, 'get_expiration' ) ) ) {
			$expiration = $gateway->get_expiration( $this );

			// If the expiration is an error, just return.
			if ( is_wp_error( $expiration ) ) {
				return $ret;
			}

			if ( $this->get_expiration_time() < strtotime( $expiration, current_time( 'timestamp' ) ) ) {
				// Update expiration date.
				$this->update( array( 'expiration' => $expiration ) );

				// Set the expiration time of the currently loaded object.
				$this->expiration = $expiration;

				// We'll return true here, since we adjusted the expiration.
				$ret = true;

				/* translators: %s: The new expiration date */
				$this->add_note( sprintf( __( 'Expiration synced with gateway and updated to %s', 'edd-recurring' ), $expiration ) );

				/**
				 * Fires when a subscription expiration date is checked and possibly updated.
				 *
				 * @param EDD_Subscription $subscription The subscription object being checked for expiration.
				 * @param string $expiration The new expiration date.
				 */
				do_action( 'edd_recurring_check_expiration', $this, $expiration );
			}
		}

		return $ret;
	}

	/**
	 * Retrieves the expiration date in a timestamp
	 *
	 * @since  2.4
	 * @return int
	 */
	public function get_expiration_time() {
		return strtotime( $this->expiration, current_time( 'timestamp' ) );
	}

	/**
	 * Retrieves the subscription status
	 *
	 * @since  2.4
	 * @return int
	 */
	public function get_status() {
		// Monitor for page load delays on pages with large subscription lists (IE: Subscriptions table in admin).
		$this->is_expired();

		// Check for completed subscriptions incorrectly marked as cancelled.
		if ( 'cancelled' === $this->status && ! empty( $this->bill_times ) ) {
			if ( $this->get_times_billed() >= $this->bill_times ) {
				$this->update( array( 'status' => 'completed' ) );
			}
		}
		return $this->status;
	}

	/**
	 * Retrieves the subscription status label
	 *
	 * @since  2.4
	 * @return int
	 */
	public function get_status_label() {

		if ( $this->is_cancellation_scheduled() ) {
			return __( 'Pending Cancellation', 'edd-recurring' );
		}

		$status   = $this->get_status();
		$statuses = edd_recurring_get_subscription_statuses();

		if ( isset( $statuses[ $status ] ) ) {
			return $statuses[ $status ];
		}

		return ucfirst( $status );
	}

	/**
	 * Retrieves the subscription status badge
	 *
	 * @since  2.12.0
	 * @return string
	 */
	public function get_status_badge() {
		$status = $this->get_status();
		if ( in_array( $status, array( 'trash', 'needs_attention' ), true ) ) {
			$status = 'error';
		} elseif ( $this->is_cancellation_scheduled() ) {
			$status = 'processing';
		}
		$status_badge_args = array(
			'status' => $status,
			'label'  => $this->get_status_label(),
			'class'  => 'edd-subscription-status-badge',
		);
		$status_badge      = new \EDD\Utils\StatusBadge( $status_badge_args );

		return $status_badge->get();
	}

	/**
	 * Determines if a payment exists with the specified transaction ID
	 *
	 * @since  2.4
	 * @param  string $txn_id The transaction ID from the merchant processor.
	 * @return bool
	 */
	public function payment_exists( $txn_id = '' ) {
		if ( empty( $txn_id ) ) {
			return false;
		}

		$txn_id = esc_sql( $txn_id );

		return ! empty( edd_get_order_transaction_by( 'transaction_id', $txn_id ) );
	}

	/**
	 * Get the parsed notes for a subscription as an array
	 *
	 * @since  2.7
	 * @param  integer $length The number of notes to get.
	 * @param  integer $paged What note to start at.
	 * @return array           The notes requested
	 */
	public function get_notes( $length = 20, $paged = 1 ) {

		$length = is_numeric( $length ) ? absint( $length ) : 20;
		$offset = is_numeric( $paged ) && 1 !== absint( $paged ) ? ( ( absint( $paged ) - 1 ) * $length ) : 0;
		$notes  = edd_get_notes(
			array(
				'object_id'   => $this->id,
				'object_type' => 'subscription',
				'number'      => $length,
				'offset'      => $offset,
			)
		);

		$notes_strings = array();
		foreach ( $notes as $note ) {
			// the date is a time string with yyyy-mm-dd hh:mm:ss format and we don't want seconds
			$date            = edd_date_i18n( strtotime( $note->date_created ), get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
			$notes_strings[] = $date . ' - ' . $note->content;
		}

		$notes_found = count( $notes_strings );
		if ( $notes_found === $length ) {
			return $notes_strings;
		}

		$length       -= $notes_found;
		$all_notes     = $this->get_raw_notes();
		if ( empty( $all_notes ) ) {
			return $notes_strings;
		}

		$notes_array   = array_reverse( array_filter( explode( "\n\n", $all_notes ) ) );
		$desired_notes = array_slice( $notes_array, $offset, $length );

		return array_merge( $notes_strings, $desired_notes );
	}

	/**
	 * Get the total number of notes we have after parsing
	 *
	 * @since  2.7
	 * @return int The number of notes for the subscription
	 */
	public function get_notes_count() {
		$notes = edd_count_notes(
			array(
				'object_id'   => $this->id,
				'object_type' => 'subscription',
			)
		);
		if ( edd_has_upgrade_completed( 'subscriptions_notes' ) || edd_is_doing_unit_tests() ) {
			return $notes;
		}

		$all_notes   = $this->get_raw_notes();
		$notes_array = array_reverse( array_filter( explode( "\n\n", $all_notes ) ) );
		$notes      += count( $notes_array );

		return $notes;
	}

	/**
	 * Add a note for the subscription
	 *
	 * @since  2.7
	 * @param string $note The note to add.
	 * @return string|boolean The new note if added successfully, false otherwise
	 */
	public function add_note( $note = '' ) {
		$note = trim( $note );
		if ( empty( $note ) ) {
			return false;
		}

		$note = apply_filters( 'edd_subscription_add_note_string', $note );
		do_action( 'edd_subscription_pre_add_note', $note, $this->id );

		$note_id = edd_add_note(
			array(
				'object_id'   => $this->id,
				'object_type' => 'subscription',
				'content'     => $note,
				'user_id'     => get_current_user_id(),
			)
		);

		do_action( 'edd_subscription_post_add_note', $this->notes, $note, $this->id );

		return $note;
	}

	/**
	 * Get the legacy notes column for the subscription. Once the upgrade is complete, this will return an empty string.
	 *
	 * @since  2.7
	 * @deprecated 2.13.0
	 * @return string The Notes for the subscription, non-parsed.
	 */
	private function get_raw_notes() {
		if ( edd_has_upgrade_completed( 'subscriptions_notes' ) || edd_is_doing_unit_tests() ) {
			return '';
		}

		$legacy_database = new \EDD\Recurring\Legacy\Database();
		$all_notes       = $legacy_database->get_column( 'notes', $this->id );

		return (string) $all_notes;
	}

	/**
	 * Convert object to array
	 *
	 * @since 2.7.4
	 *
	 * @return array
	 */
	public function to_array() {
		$array = array();
		foreach ( get_object_vars( $this ) as $prop => $var ) {

			if ( is_object( $var ) && is_callable( array( $var, 'to_array' ) ) ) {

				$array[ get_class( $var ) ] = $var->to_array();

			} else {

				$array[ $prop ] = $var;

			}
		}

		return $array;
	}

	/**
	 * Whether the current user can manage a specific subscription.
	 *
	 * @since 2.11.8
	 * @param string $capability The capability required if the user is not the subscription owner.
	 * @return bool
	 */
	public function current_user_can( $capability = 'manage_subscriptions' ) {
		if ( ! is_user_logged_in() ) {
			return false;
		}

		if ( current_user_can( $capability ) ) {
			return true;
		}

		if ( (int) get_current_user_id() === (int) $this->customer->user_id ) {
			return true;
		}

		return false;
	}

	/**
	 * Maybe add a time meta value to the subscription.
	 *
	 * @since 2.13.0
	 *
	 * @param string $key The key of the meta value to add.
	 * @return bool
	 */
	public function maybe_add_time_meta( string $key ) {
		if ( ! in_array( $key, array( 'cancelled', 'reactivated' ), true ) ) {
			return false;
		}

		if ( $this->has_time_meta( $key ) ) {
			return false;
		}

		return edd_recurring_add_subscription_meta( $this->id, "{$key}_at_gmt", time() );
	}

	/**
	 * Set the status property internally.  All places where the status of the subscription gets changed end up going
	 * going through here so the action here is reliable for hooking in on any status change.
	 *
	 * Method should only be called when the status for the subscription has actually been changed in the db.
	 *
	 * @since 2.7.14
	 * @param string $new_status The new status for the subscription.
	 */
	protected function set_status( $new_status ) {
		$old_status   = $this->status;
		$this->status = $new_status;

		if ( is_user_logged_in() ) {
			$userdata = get_userdata( get_current_user_id() );
			$user     = $userdata->user_login;
		} else {
			$user = __( 'gateway', 'edd-recurring' );
		}

		if ( strtolower( $this->status ) !== strtolower( $old_status ) ) {
			/* translators: 1. the old status; 2. the new status; 3. the user who changed the status. */
			$this->add_note( sprintf( __( 'Status changed from %1$s to %2$s by %3$s', 'edd-recurring' ), $old_status, $this->status, $user ) );
		}

		/**
		 * Fires when the status of a subscription changes.
		 *
		 * @param string $old_status The old status of the subscription.
		 * @param string $new_status The new status of the subscription.
		 * @param EDD_Subscription $subscription The subscription object.
		 */
		do_action( 'edd_subscription_status_change', $old_status, $new_status, $this );
	}

	/**
	 * Generates the payment key for the order.
	 * In EDD 3.0, this just uses edd_generate_order_payment_key.
	 * In EDD 2.x, this function replicates the code used in edd_generate_order_payment_key.
	 *
	 * @since 2.11.7
	 * @todo  Remove compatibility shim once Recurring minimum is 3.0.
	 *
	 * @param string $key The email address for the order.
	 * @return string
	 */
	private function generate_order_payment_key( $key ) {
		return edd_generate_order_payment_key( $key );
	}

	/**
	 * Whether the subscription is currently scheduled to be cancelled.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	private function is_cancellation_scheduled() {
		$reasons = array( 'license upgrade', 'license renewal' );
		foreach ( $reasons as $reason ) {
			if ( wp_next_scheduled( 'edd_recurring_cancel_subscription', array( $this->id, $reason ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Helper function to get the array of statuses considered to be active subscription statuses.
	 *
	 * @return array
	 */
	private function get_active_statuses() {
		return edd_recurring_get_active_subscription_statuses();
	}

	/**
	 * Maybe add an order address to the renewal order.
	 *
	 * @since 2.12.2
	 * @param int               $order_id     The renewal order ID.
	 * @param \EDD\Orders\Order $parent_order The parent order object.
	 * @param \EDD_Customer     $customer     The customer object.
	 * @return void
	 */
	private function maybe_add_order_address( $order_id, $parent_order, $customer ) {
		// If the customer has a primary address set, use that.
		$customer_address = edd_get_customer_address( $parent_order->user_id );
		if ( ! empty( $customer_address ) ) {
			$address = array(
				'name'        => $customer->name ?? '',
				'address'     => $customer_address['line1'],
				'address2'    => $customer_address['line2'],
				'city'        => $customer_address['city'],
				'region'      => $customer_address['state'],
				'postal_code' => $customer_address['zip'],
				'country'     => $customer_address['country'],
			);
		} else {
			$address = $parent_order->get_address();
			if ( ! empty( $address ) ) {
				$address = array(
					'name'        => $address->name,
					'address'     => $address->address,
					'address2'    => $address->address2,
					'city'        => $address->city,
					'region'      => $address->region,
					'postal_code' => $address->postal_code,
					'country'     => $address->country,
				);
			}
		}
		$address       = (array) $address;
		$address_check = array_filter( $address );
		if ( empty( $address_check ) ) {
			return;
		}

		$address['order_id'] = $order_id;

		edd_add_order_address( $address );
	}

	/**
	 * Check if the subscription has a time meta value within the last hour.
	 *
	 * @since 2.13.0
	 * @param string $key The key of the meta value to check.
	 * @return bool
	 */
	private function has_time_meta( string $key ): bool {
		global $wpdb;

		return ! empty(
			$wpdb->get_results(
				$wpdb->prepare(
					"SELECT meta_value FROM {$wpdb->edd_subscriptionmeta} WHERE meta_key = %s AND edd_subscription_id = %d AND meta_value > %d",
					"{$key}_at_gmt",
					$this->id,
					time() - HOUR_IN_SECONDS
				)
			)
		);
	}
}
