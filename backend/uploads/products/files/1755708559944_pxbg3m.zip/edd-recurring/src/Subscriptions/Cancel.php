<?php
/**
 * Subscription cancellation handler.
 *
 * @package EDD\Recurring\Subscriptions
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Subscriptions;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Cancel subscriptions.
 */
class Cancel {

	/**
	 * Maybe schedule the subscription cancellation--it will be skipped if already scheduled.
	 *
	 * @since 2.13.0
	 * @param \EDD_Subscription $subscription The subscription object.
	 * @param string            $reason       The reason for cancellation.
	 * @return void
	 */
	public function schedule_cancellation( \EDD_Subscription $subscription, string $reason ) {

		if ( ! $subscription->can_cancel() && 'manual' !== $subscription->gateway ) {
			return;
		}

		// If we are intentionally bypassing cron somehow, cancel now and return.
		if ( $this->should_cancel_immediately() ) {
			$this->cancel( $subscription->id, $reason );
			return;
		}

		// Check if the recalculation has already been scheduled.
		if ( wp_next_scheduled( 'edd_recurring_cancel_subscription', array( $subscription->id, $reason ) ) ) {
			return;
		}

		edd_debug_log( 'Scheduling cancellation for subscription ' . $subscription->id );

		$time = $this->get_time_to_cancel();
		$subscription->add_note( sprintf( 'Scheduled cancellation at %s for %s.', edd_date_i18n( $time, 'Y-m-d H:i:s' ), $reason ) );

		edd_recurring_add_subscription_meta( $subscription->id, 'cancel_by', $time + HOUR_IN_SECONDS, true );

		wp_schedule_single_event(
			$time,
			'edd_recurring_cancel_subscription',
			array( $subscription->id, $reason )
		);
	}

	/**
	 * Cancel a subscription.
	 *
	 * @since 2.13.0
	 * @param int    $subscription_id The subscription ID.
	 * @param string $reason          The reason for cancellation.
	 * @return void
	 */
	public function cancel( $subscription_id, $reason = '' ) {
		$subscription = edd_recurring_get_subscription( $subscription_id );
		if ( ! $subscription ) {
			return;
		}

		$recurring = edd_recurring();
		$gateway   = $recurring->get_gateway( $subscription->gateway );
		if ( empty( $gateway ) ) {
			$subscription->update( array( 'status' => 'needs_attention' ) );
			$subscription->add_note( sprintf( 'Cancellation was scheduled for %s, but could not be completed automatically.', $reason ) );
			return;
		}

		if ( ! $gateway->cancel_immediately( $subscription ) ) {
			return;
		}

		if ( ! empty( $reason ) ) {
			edd_insert_payment_note(
				$subscription->parent_payment_id,
				sprintf(
					/* translators: 1. the original subscription ID; 2. the reason the subscription was cancelled */
					__( 'Subscription #%1$d cancelled: %2$s', 'edd-recurring' ),
					$subscription->id,
					esc_html( $reason )
				)
			);

			$subscription->add_note(
				sprintf(
					/* translators: the reason the subscription was cancelled */
					__( 'Subscription cancelled: %s', 'edd-recurring' ),
					esc_html( $reason )
				)
			);
		}

		remove_action( 'edd_subscription_cancelled', array( $recurring::$emails, 'send_subscription_cancelled' ) );
		$subscription->cancel();
	}

	/**
	 * Whether to cancel immediately.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	private function should_cancel_immediately() {
		if ( $this->bypass_cron() ) {
			return true;
		}

		if ( defined( 'EDD_DOING_TESTS' ) && EDD_DOING_TESTS ) {
			return true;
		}

		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
			return true;
		}

		return false;
	}

	/**
	 * Whether to bypass the cron check.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	private function bypass_cron() {
		return apply_filters( 'edd_recurring_cancel_subscription_bypass_cron', false );
	}

	/**
	 * Get the time to cancel.
	 *
	 * @since 2.13.0
	 * @return int
	 */
	private function get_time_to_cancel(): int {
		return apply_filters( 'edd_recurring_cancel_subscription_time', time() + ( 5 * MINUTE_IN_SECONDS ) );
	}
}
