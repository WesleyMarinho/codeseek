<?php
/**
 * Product class for Recurring.
 *
 * @package     EDD\Recurring\Downloads
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Downloads;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * The Product Class.
 *
 * @since 2.13.0
 */
class Product extends \EDD_Download {

	/**
	 * Whether or not the product is recurring.
	 *
	 * @since 2.13.0
	 * @param int|null $price_id Optional. The price ID to check.
	 * @return bool
	 */
	public function is_recurring( $price_id = null ) {
		if ( ! is_null( $price_id ) ) {
			$prices = $this->get_prices();
			$period = $this->get_period( $price_id );

			return isset( $prices[ $price_id ]['recurring'] ) && 'never' !== $period;
		}

		return 'yes' === get_post_meta( $this->ID, 'edd_recurring', true );
	}

	/**
	 * Get the period for a price or the product.
	 *
	 * @since 2.13.0
	 * @param int|null $price_id Optional. The price ID to check.
	 * @return string
	 */
	public function get_period( $price_id = null ) {

		if ( ! is_null( $price_id ) ) {
			$prices = $this->get_prices();
			if ( isset( $prices[ $price_id ]['period'] ) ) {
				return $prices[ $price_id ]['period'];
			}
		}

		$period = get_post_meta( $this->ID, 'edd_period', true );

		return $period ? $period : 'never';
	}

	/**
	 * Get the times a product is billed.
	 *
	 * @since 2.13.0
	 * @param int|null $price_id Optional. The price ID to check.
	 * @return int
	 */
	public function get_times( $price_id = null ) {

		if ( ! is_null( $price_id ) ) {
			$prices = $this->get_prices();
			if ( isset( $prices[ $price_id ]['times'] ) ) {
				return intval( $prices[ $price_id ]['times'] );
			}
		}

		$times = get_post_meta( $this->ID, 'edd_times', true );

		return $times ? intval( $times ) : 0;
	}

	/**
	 * Whether or not the product has a free trial.
	 *
	 * @since 2.13.0
	 * @param int|null $price_id Optional. The price ID to check.
	 * @return bool
	 */
	public function has_free_trial( $price_id = null ) {

		$has_trial = false;
		$prices    = $this->get_prices();
		if ( empty( $prices ) || is_null( $price_id ) ) {
			$has_trial = get_post_meta( $this->ID, 'edd_trial_period', true );
		} elseif ( isset( $prices[ $price_id ] ) && ! empty( $prices[ $price_id ]['trial-quantity'] ) ) {
			$has_trial = ! empty( $prices[ $price_id ]['trial-quantity'] );
		}

		return apply_filters( 'edd_recurring_download_has_free_trial', (bool) $has_trial, $this->ID, $price_id );
	}

	/**
	 * Get the signup fee for a price or the product.
	 *
	 * @since 2.13.0
	 * @param int|null $price_id Optional. The price ID to check.
	 * @return float
	 */
	public function get_signup_fee( $price_id = null ) {

		if ( ! is_null( $price_id ) ) {
			$prices     = $this->get_prices();
			$signup_fee = 0;
			if ( isset( $prices[ $price_id ]['signup_fee'] ) ) {
				$signup_fee = floatval( $prices[ $price_id ]['signup_fee'] );
			}

			return apply_filters( 'edd_recurring_signup_fee', $signup_fee, $price_id, $prices );
		}

		$signup_fee = get_post_meta( $this->ID, 'edd_signup_fee', true );

		return $signup_fee ? floatval( $signup_fee ) : 0;
	}

	/**
	 * Get the trial period for a price or the product.
	 *
	 * @since 2.13.0
	 * @param int|null $price_id Optional. The price ID to check.
	 * @return array|bool
	 */
	public function get_trial_period( $price_id = null ) {
		if ( ! $this->has_free_trial( $price_id ) ) {
			return false;
		}

		$prices = $this->get_prices();
		if ( ( ! empty( $price_id ) || 0 === (int) $price_id ) && is_array( $prices ) && ! empty( $prices[ $price_id ]['trial-quantity'] ) && ! empty( $prices[ $price_id ]['trial-unit'] ) ) {
			$period = array(
				'quantity' => $prices[ $price_id ]['trial-quantity'],
				'unit'     => $prices[ $price_id ]['trial-unit'],
			);
		} else {
			$period = (array) get_post_meta( $this->ID, 'edd_trial_period', true );
			$period = wp_parse_args(
				$period,
				array(
					'quantity' => 1,
					'unit'     => 'month',
				)
			);
		}

		$period['quantity'] = absint( $period['quantity'] );
		$period['quantity'] = $period['quantity'] < 1 ? 1 : $period['quantity'];

		return $period;
	}
}
