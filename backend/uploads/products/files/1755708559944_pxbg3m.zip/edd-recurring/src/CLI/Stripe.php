<?php
/**
 * Registers a CLI command to for Stripe/Recurring.
 *
 * @package     EDD\Recurring\CLI
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\CLI;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class Stripe
 */
class Stripe extends \WP_CLI_Command {

	/**
	 * Find missing subscriptions.
	 *
	 * ## OPTIONS
	 * [--limit=<limit>]   The number of results to return. Default is 500.
	 * [--offset=<offset>] The number of results to skip. Default is 0.
	 * [--fix]             Whether to fix the missing subscriptions.
	 * [--order=<order>]   The order ID to fix. This will override any other options.
	 *
	 * @since 2.13.0
	 */
	public function missing( $args, $assoc_args ) {
		\WP_CLI::log( __( 'Finding missing subscriptions...', 'edd-recurring' ) );

		if ( ! empty( $assoc_args['order'] ) ) {
			$this->handle_single_order( $assoc_args['order'], false );
			return;
		}

		$stripe  = new \EDD\Recurring\Gateways\Stripe\MissingSubscription();
		$results = $stripe->find( $assoc_args );

		if ( empty( $results ) ) {
			\WP_CLI::success( __( 'No missing subscriptions found.', 'edd-recurring' ) );

			return;
		}

		if ( is_wp_error( $results ) ) {
			\WP_CLI::error( $results->get_error_message() );
			return;
		}

		\WP_CLI::log( __( 'The following orders appear to be recurring but are missing subscription records:', 'edd-recurring' ) );

		foreach ( $results as $result ) {
			if ( ! edd_recurring()::is_recurring( $result->product_id, $result->price_id ) ) {
				continue;
			}

			if ( empty( $assoc_args['fix'] ) ) {
				\WP_CLI::log( $result->order_id );
				continue;
			}

			$this->handle_single_order( $result->order_id );
		}
	}

	/**
	 * Handle a single order.
	 *
	 * @since 2.13.0
	 * @param int  $order_id The order ID.
	 * @param bool $confirm  Whether to confirm the fix.
	 * @return void
	 */
	private function handle_single_order( $order_id, $confirm = true ) {
		$previous_attempt = edd_get_order_meta( $order_id, '_edd_recurring_missing_subscription_error', true );
		if ( ! empty( $previous_attempt ) ) {
			/* translators: %d is the order ID; %s is the error message. */
			\WP_CLI::log( sprintf( __( 'Order %1$d could not automatically be fixed: %2$s', 'edd-recurring' ), $order_id, $previous_attempt ) );
			return;
		}

		if ( $confirm ) {
			/* translators: %d is the order ID. */
			\WP_CLI::confirm( sprintf( __( 'Would you like to fix order %d?', 'edd-recurring' ), $order_id ) );
		}

		$fixed = \EDD\Recurring\Gateways\Stripe\MissingSubscription::fix( $order_id );
		if ( true === $fixed ) {
			$fixed = __( 'Order fixed.', 'edd-recurring' );
		}

		\WP_CLI::log( $fixed );
	}
}
