<?php
/**
 * Blocks loader.
 *
 * @package     EDD\Recurring\Blocks
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Blocks;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\EventManagement\SubscriberInterface;

/**
 * Class Loader
 *
 * @since 2.13.0
 */
class Loader implements SubscriberInterface {

	/**
	 * Registers the event listeners.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'init'                        => 'register',
			'enqueue_block_editor_assets' => 'localize',
			'edd_registered_blocks'       => 'add_to_edd_blocks',
			'edd_block_style_uri'         => array( 'add_styles', 10, 2 ),
		);
	}

	/**
	 * Registers the Recurring blocks.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function register() {
		$blocks = array(
			'subscriptions'        => array(
				'render_callback' => array( $this, 'subscriptions' ),
			),
			'subscription-details' => array(
				'render_callback' => array( $this, 'subscription_details' ),
			),
		);

		foreach ( $blocks as $block => $args ) {
			register_block_type( EDD_RECURRING_PLUGIN_DIR . 'blocks/build/' . $block, $args );
		}
	}

	/**
	 * Renders the subscriptions block.
	 *
	 * @since 2.13.0
	 * @param array $attributes The attributes for the block.
	 * @return string
	 */
	public function subscriptions( $attributes ) {
		$attributes = wp_parse_args(
			$attributes,
			array(
				'align'               => '',
				'columns'             => 2,
				'className'           => '',
				'show_gateway'        => false,
				'show_times_billed'   => false,
				'show_initial_amount' => false,
				'number'              => 0,
			)
		);

		if ( ! is_user_logged_in() ) {
			return wpautop( __( 'You must be logged in to view your subscriptions.', 'edd-recurring' ) );
		}

		$customer = edd_get_customer_by( 'user_id', get_current_user_id() );
		if ( ! $customer ) {
			return wpautop( __( 'You must be logged in to view your subscriptions.', 'edd-recurring' ) );
		}
		ob_start();
		$classes = array(
			'wp-block-edd-subscriptions',
			'edd-blocks__subscriptions',
		);
		$view    = filter_input( INPUT_GET, 'action', FILTER_SANITIZE_SPECIAL_CHARS );
		?>

		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
			<?php
			edd_print_errors();
			if ( 'details' === $view ) {
				include EDD_RECURRING_PLUGIN_DIR . 'views/subscription/details.php';
			} elseif ( 'update' === $view ) {
				include EDD_RECURRING_PLUGIN_DIR . 'views/subscription/update.php';
			} else {
				include EDD_RECURRING_PLUGIN_DIR . 'views/subscriptions.php';
			}
			?>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Renders the subscription details block.
	 *
	 * @since 2.13.0
	 * @param array $attributes The attributes for the block.
	 * @return string
	 */
	public function subscription_details( $attributes ) {
		$attributes           = wp_parse_args(
			$attributes,
			array(
				'align'     => '',
				'columns'   => 2,
				'className' => '',
			)
		);
		$is_block_editor_user = $this->is_block_editor_user();
		if ( ! has_block( 'edd/confirmation' ) && ! has_block( 'edd/receipt' ) ) {
			return $is_block_editor_user ? __( 'This block can only be used with an order confirmation or receipt block.', 'edd-recurring' ) : '';
		}

		$payment_key = $this->get_payment_key();
		if ( ! $payment_key ) {
			return '';
		}

		$order         = edd_get_order_by( 'payment_key', $payment_key );
		$user_can_view = edd_can_view_receipt( $order );
		if ( ! $user_can_view ) {
			return '';
		}

		$args = array(
			'parent_payment_id' => $order->id,
			'order'             => 'ASC',
			'number'            => 9999,
		);
		if ( $is_block_editor_user ) {
			unset( $args['parent_payment_id'] );
			$args['number'] = 1;
		}
		$database      = new \EDD_Subscriptions_DB();
		$subscriptions = $database->get_subscriptions( $args );
		if ( empty( $subscriptions ) ) {
			return '';
		}
		ob_start();
		$classes = array(
			'wp-block-edd-subscription-details',
			'edd-blocks__subscription-details',
		);
		?>

		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
			<h3><?php esc_html_e( 'Subscription Details', 'edd-recurring' ); ?></h3>
			<?php
			foreach ( $subscriptions as $subscription ) {
				?>
				<div class="edd-blocks-subscriptions__subscription edd-blocks-subscriptions__grid-item">
					<?php
					include EDD_RECURRING_PLUGIN_DIR . 'views/subscription/header.php';
					include EDD_RECURRING_PLUGIN_DIR . 'views/subscription/rows.php';
					?>
				</div>
				<?php
			}
			?>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Adds a custom variable to the JS to allow a user in the block editor
	 * to preview sensitive data.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function localize() {
		$user = wp_get_current_user();
		wp_localize_script(
			'wp-block-editor',
			'EDDRecurringBlocks',
			array(
				'current_user' => md5( $user->user_email ),
				'nonce'        => wp_create_nonce( 'edd-recurring' ),
			)
		);
	}

	/**
	 * Adds the subscription block to the EDD blocks array.
	 *
	 * @since 2.13.0
	 * @param array $blocks The array of EDD blocks.
	 * @return array
	 */
	public function add_to_edd_blocks( $blocks ) {
		$blocks[] = 'edd/subscriptions';
		$blocks[] = 'edd/subscription-details';

		return $blocks;
	}

	/**
	 * Adds the styles for the subscription blocks.
	 *
	 * @since 2.13.0
	 * @param string $path The path to the block style.
	 * @param string $block_name The name of the block.
	 * @return string
	 */
	public function add_styles( $path, $block_name ) {
		$recurring_blocks = array(
			'subscriptions',
			'subscription-details',
		);
		if ( ! in_array( $block_name, $recurring_blocks, true ) ) {
			return $path;
		}

		return EDD_RECURRING_PLUGIN_URL . "blocks/build/{$block_name}/style-index.css";
	}

	/**
	 * Adds a confirmation to the cancel button.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function add_cancel_confirmation() {
		?>
		<script id="edd-recurring-subscription-cancel">
			const cancelButton = document.querySelector( '.edd-subscription-cancel' );
			if ( cancelButton ) {
				cancelButton.addEventListener( 'click', function ( e ) {
					if ( confirm( '<?php esc_html_e( 'Are you sure you want to cancel your subscription?', 'edd-recurring' ); ?>' ) ) {
						return;
					}

					e.preventDefault();
				} );
			}
		</script>
		<?php
	}

	/**
	 * Gets the args for the subscriptions query.
	 *
	 * @since 2.13.0
	 * @param array $attributes The attributes for the block.
	 * @return array
	 */
	private function get_subscription_args( $attributes ) {
		$args = array(
			'status'  => array( 'active', 'expired', 'cancelled', 'failing', 'trialling', 'needs_attention' ),
			'number'  => 9999,
			'order'   => 'DESC',
			'orderby' => 'created',
		);
		if ( ! empty( $attributes['number'] ) ) {
			$current_page   = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
			$args['number'] = $attributes['number'];
			$args['offset'] = $attributes['number'] * ( intval( $current_page ) - 1 );
		}
		if ( $this->is_block_editor_user() ) {
			$args['number'] = 6;
		} else {
			$subscriber          = new \EDD_Recurring_Subscriber( get_current_user_id(), true );
			$args['customer_id'] = $subscriber->id;
		}

		return $args;
	}

	/**
	 * Checks if the current user is a block editor user.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	private function is_block_editor_user() {
		$block_editor_user  = filter_input( INPUT_GET, 'edd_blocks_is_block_editor', FILTER_SANITIZE_NUMBER_INT );
		$block_editor_nonce = filter_input( INPUT_GET, 'edd_recurring_block_nonce', FILTER_SANITIZE_SPECIAL_CHARS );

		return ! empty( $block_editor_user ) && current_user_can( 'view_subscriptions' ) && wp_verify_nonce( $block_editor_nonce, 'edd-recurring' );
	}

	/**
	 * Gets the subscription actions.
	 *
	 * @since 2.13.0
	 * @param \EDD_Subscription $subscription The subscription object.
	 * @return array
	 */
	private function get_subscription_actions( $subscription ) {
		$actions = array(
			'details' => $this->get_details_link( $subscription ),
		);
		if ( $subscription->can_update() ) {
			$actions['update'] = array(
				'label' => __( 'Update Payment Method', 'edd-recurring' ),
				'url'   => $subscription->get_update_url(),
			);
		}
		if ( $subscription->can_renew() ) {
			$actions['renew'] = array(
				'label' => __( 'Renew', 'edd-recurring' ),
				'url'   => $subscription->get_renew_url(),
			);
		}
		if ( $subscription->can_cancel() ) {
			$url               = add_query_arg( 'block', true, $subscription->get_cancel_url() );
			$actions['cancel'] = array(
				'label' => edd_get_option( 'recurring_cancel_button_text', __( 'Cancel', 'edd-recurring' ) ),
				'url'   => $url,
			);
			add_action( 'wp_footer', array( $this, 'add_cancel_confirmation' ) );
		}
		if ( $subscription->can_reactivate() ) {
			$url                   = add_query_arg( 'block', true, $subscription->get_reactivation_url() );
			$actions['reactivate'] = array(
				'label' => __( 'Reactivate', 'edd-recurring' ),
				'url'   => $url,
			);
		}

		return $actions;
	}

	/**
	 * Gets the subscription details link.
	 *
	 * @since 2.13.0
	 * @param \EDD_Subscription $subscription The subscription object.
	 * @return array
	 */
	private function get_details_link( $subscription ) {
		return array(
			'label' => __( 'Subscription Details', 'edd-recurring' ),
			'url'   => add_query_arg(
				array(
					'action'          => 'details',
					'subscription_id' => absint( $subscription->id ),
				)
			),
		);
	}

	/**
	 * Gets the array of classes for a block.
	 *
	 * @since 2.13.0
	 * @param array $block_attributes The attributes for the block.
	 * @param array $classes The classes for the block.
	 * @return array
	 */
	private function get_classes( $block_attributes, $classes = array() ) {
		if ( ! empty( $block_attributes['columns'] ) && 1 < (int) $block_attributes['columns'] ) {
			$columns   = (int) $block_attributes['columns'];
			$classes[] = 'edd-blocks__columns';
			if ( 3 <= $columns ) {
				$classes[] = "edd-blocks__columns-{$columns}";
			}
		}
		if ( ! empty( $block_attributes['align'] ) ) {
			$classes[] = "align{$block_attributes['align']}";
		}
		if ( ! empty( $block_attributes['className'] ) ) {
			$additional_classes = explode( ' ', $block_attributes['className'] );
			if ( $additional_classes ) {
				$classes = array_merge( $classes, $additional_classes );
			}
		}

		return array_filter( array_unique( array_map( 'sanitize_html_class', $classes ) ) );
	}

	/**
	 * Gets the payment key:
	 *     Checks the URL directly
	 *     Checks for the order ID and hashed order value
	 *     Checks the current purchase session
	 *
	 * @since 2.13.0
	 * @return string|false
	 */
	private function get_payment_key() {
		if ( function_exists( '\\EDD\\Blocks\\Orders\\Functions\\get_payment_key' ) ) {
			return \EDD\Blocks\Orders\Functions\get_payment_key();
		}

		if ( isset( $_GET['payment_key'] ) ) {
			return urldecode( $_GET['payment_key'] );
		}

		if ( ! empty( $_GET['order'] ) && ! empty( $_GET['id'] ) ) {
			return edd_get_payment_key( absint( $_GET['id'] ) );
		}

		$session = edd_get_purchase_session();
		if ( $session ) {
			return $session['purchase_key'];
		}

		return false;
	}
}
