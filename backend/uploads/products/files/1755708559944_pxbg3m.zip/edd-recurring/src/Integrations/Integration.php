<?php
/**
 * Abstract integration class.
 *
 * @package     EDD\Recurring\Integrations
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Integrations;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\EventManagement\SubscriberInterface;

/**
 * Abstract integration class.
 *
 * @since 2.13.0
 */
abstract class Integration implements SubscriberInterface {

	/**
	 * Get the subscribed events.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events(): array {
		if ( ! static::is_active() ) {
			return array();
		}

		return static::hooks();
	}

	/**
	 * Whether the integration is active.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	abstract public static function is_active(): bool;

	/**
	 * Register hooks.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	abstract protected static function hooks(): array;
}
