<?php
/**
 * Software Licensing Emails trait.
 *
 * @package     EDD\Recurring\Integrations\SoftwareLicensing
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Integrations\SoftwareLicensing;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Software Licensing Emails class.
 *
 * @since 2.13.0
 */
trait Emails {

	/**
	 * Maybe disable the subscription reminder if the license has been upgraded.
	 *
	 * @param bool                                $can_send        Whether the reminder can be sent.
	 * @param int                                 $subscription_id The subscription ID.
	 * @param int                                 $notice_id       The notice ID.
	 * @param \EDD\Recurring\Emails\Types\Notices $notice          The notice object.
	 * @return bool
	 */
	public function maybe_disable_reminder( $can_send, $subscription_id, $notice_id, $notice ) {
		$subscription = edd_recurring_get_subscription( $subscription_id );
		if ( ! $subscription ) {
			return $can_send;
		}

		if ( 'cancelled' !== $subscription->status ) {
			return $can_send;
		}

		// If the original order was upgraded, don't send the reminder.
		$original_order_upgrade = edd_get_order_meta( $subscription->parent_payment_id, '_edd_sl_upgraded_to_payment_id', true );
		if ( ! empty( $original_order_upgrade ) ) {
			$original_order = edd_get_order( $original_order_upgrade );
			if ( ! empty( $original_order ) && in_array( $original_order->status, edd_get_complete_order_statuses(), true ) ) {
				return false;
			}
		}

		// If any of the renewal orders were upgraded, don't send the reminder.
		$renewal_orders = $subscription->get_renewal_orders();
		if ( ! empty( $renewal_orders ) ) {
			foreach ( $renewal_orders as $renewal_order ) {
				$upgrade_order = edd_get_order_meta( $renewal_order->id, '_edd_sl_upgraded_to_payment_id', true );
				if ( ! empty( edd_get_order_meta( $renewal_order->id, '_edd_sl_upgraded_to_payment_id', true ) ) ) {
					$upgrade_order = edd_get_order( $upgrade_order );
					if ( ! empty( $upgrade_order ) && in_array( $upgrade_order->status, edd_get_complete_order_statuses(), true ) ) {
						return false;
					}
				}
			}
		}

		return $can_send;
	}
}
