<?php
/**
 * Software Licensing abstract integration class.
 *
 * @package     EDD\Recurring\Integrations\SoftwareLicensing
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Integrations\SoftwareLicensing;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Recurring\Integrations\Integration as Base;

/**
 * Software Licensing Integration class.
 *
 * @since 2.13.0
 */
class Integration extends Base {
	use Emails;
	use Renewals;
	use Upgrades;

	/**
	 * Check if the integration is active.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	public static function is_active(): bool {
		return function_exists( 'edd_software_licensing' );
	}

	/**
	 * Register hooks.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	protected static function hooks(): array {
		return array(
			'edd_recurring_send_reminder'                => array( 'maybe_disable_reminder', 10, 4 ),
			'edd_recurring_create_subscription_args'     => array( 'handle_subscription_upgrade_billing', 10, 7 ),
			'edd_sl_post_license_renewal'                => 'cancel_subscription_on_renewal',
			'edd_sl_license_upgraded'                    => array( 'cancel_subscription_on_upgrade', 10, 2 ),
			'edd_recurring_post_create_payment_profiles' => 'set_renewal_flag',
		);
	}
}
