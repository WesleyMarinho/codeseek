<?php
/**
 * Software Licensing manual renewals handler.
 *
 * @package     EDD\Recurring\Integrations\SoftwareLicensing
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Integrations\SoftwareLicensing;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Renewals class.
 */
trait Renewals {

	/**
	 * Adds metadata to the license to indicate a manual renewal.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function set_renewal_flag( \EDD_Recurring_Gateway $gateway_data ) {

		foreach ( $gateway_data->subscriptions as $subscription ) {

			if ( empty( $subscription['is_renewal'] ) || empty( $subscription['license_id'] ) ) {
				continue;
			}

			$license = edd_software_licensing()->get_license( $subscription['license_id'] );
			$license->update_meta( 'old_subscription_id', $subscription['old_subscription_id'] );
			$license->update_meta( 'manual_renewal', true );
		}
	}

	/**
	 * Cancel a subscription when a license is manually renewed.
	 *
	 * @since 2.13.0
	 * @param int $license_id The license ID.
	 */
	public function cancel_subscription_on_renewal( $license_id ) {
		$license             = new License( $license_id );
		$old_subscription_id = $license->license->get_meta( 'old_subscription_id' );

		// Checking for metadata only added for manual renewals.
		if ( ! $old_subscription_id && ! $license->license->get_meta( 'manual_renewal' ) ) {
			return;
		}

		// Delete this meta, even if we can't find a subscription.
		$license->license->delete_meta( 'old_subscription_id' );
		$license->license->delete_meta( 'manual_renewal' );

		$old_subscription = $license->get_subscription(
			array(
				'id'                => $old_subscription_id,
				'parent_payment_id' => false,
			)
		);
		if ( ! $old_subscription ) {
			return;
		}

		$cancellation_handler = new \EDD\Recurring\Subscriptions\Cancel();
		$cancellation_handler->schedule_cancellation( $old_subscription, 'license renewal' );
	}
}
