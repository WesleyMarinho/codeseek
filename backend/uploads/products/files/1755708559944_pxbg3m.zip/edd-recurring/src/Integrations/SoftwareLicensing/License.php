<?php
/**
 * Software Licensing license handler.
 *
 * @package     EDD\Recurring\Integrations\SoftwareLicensing
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Integrations\SoftwareLicensing;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * License class.
 */
class License {

	/**
	 * The license object.
	 *
	 * @since 2.13.0
	 * @var \EDD_SL_License
	 */
	public $license;

	/**
	 * The license ID.
	 *
	 * @since 2.13.0
	 * @var int
	 */
	private $license_id;

	/**
	 * License constructor.
	 *
	 * @since 2.13.0
	 * @param int $license_id The license ID.
	 */
	public function __construct( $license_id ) {
		$this->license = edd_software_licensing()->get_license( $license_id );
	}

	/**
	 * Get a subscription from a license.
	 *
	 * @since 2.13.0
	 * @param array $sub_args Optional. Arguments to pass to the EDD_Subscriptions_DB::get_subscriptions() method.
	 * @return false|\EDD_Subscription
	 */
	public function get_subscription( $sub_args = array() ) {
		if ( empty( $this->license->download_id ) ) {
			return false;
		}

		$payment_ids = $this->license->payment_ids;
		if ( ! is_array( $payment_ids ) ) {
			return false;
		}

		$subscriptions = new \EDD_Subscriptions_DB();
		$sub_args      = wp_parse_args(
			$sub_args,
			array(
				'product_id'        => $this->license->download_id,
				'status'            => array( 'active', 'trialling' ),
				'number'            => 1,
				'order'             => 'ASC',
				'parent_payment_id' => $payment_ids,
			)
		);

		$subs = $subscriptions->get_subscriptions( $sub_args );

		return $subs ? reset( $subs ) : false;
	}
}
