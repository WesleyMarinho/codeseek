<?php
/**
 * Stripe Webhook Event.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class Event
 *
 * @since 2.13.0
 */
class Event {

	/**
	 * Get the event from Stripe.
	 *
	 * @since 2.13.0
	 * @throws \EDD\Utils\Exception If the event is invalid.
	 * @return \EDD\Stripe\API\Event | false
	 */
	public static function get() {
		$body = @file_get_contents( 'php://input' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		try {
			$event = json_decode( $body );

			if ( false === $event || ! isset( $event->id ) ) {
				throw new \EDD\Utils\Exception( esc_html__( 'Invalid Event', 'edd-recurring' ) );
			}

			return edds_api_request( 'Event', 'retrieve', $event->id );
		} catch ( \EDD_Exception $exception ) {
			edd_debug_log( 'Error retrieving Stripe event: ' . $exception->getMessage() );

			return false;
		}

		return false;
	}
}
