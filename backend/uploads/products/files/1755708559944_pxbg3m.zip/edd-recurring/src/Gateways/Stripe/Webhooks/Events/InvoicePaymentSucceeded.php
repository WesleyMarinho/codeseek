<?php
/**
 * Stripe Customer Invoice Payment Succeeded event.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks\Events
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks\Events;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class InvoicePaymentSucceeded
 *
 * @since 2.13.0
 */
class InvoicePaymentSucceeded extends Event {

	/**
	 * Processes the event.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process() {
		if ( ! $this->get_edd_subscription() ) {
			edd_debug_log( 'Stripe webhook PaymentSucceeded: Subscription not found.' );
			return;
		}

		$stripe_sub = $this->get_stripe_subscription();
		if ( ! $stripe_sub ) {
			return;
		}

		// This is a renewal charge.
		$order_id = $this->subscription->add_payment( $this->get_order_args() );
		if ( ! $order_id ) {
			$this->subscription->add_note( __( 'Failed to create renewal order.', 'edd-recurring' ) );
			return;
		}

		/* translators: %s: Stripe event ID */
		$this->subscription->add_note( sprintf( __( 'Renewal order processed by Stripe webhook: %s.', 'edd-recurring' ), $this->event->id ) );

		// Renew the subscription if it was not reactivated.
		if ( empty( $stripe_sub->metadata->reactivated ) || empty( $stripe_sub->metadata->reactivation_processed ) ) {
			$this->subscription->renew( $order_id );
			return;
		}

		$this->maybe_reactivate( $stripe_sub );
	}

	/**
	 * Get the EDD subscription.
	 *
	 * @since 2.13.0
	 * @return \EDD_Subscription|false
	 */
	private function get_edd_subscription() {
		if ( $this->subscription ) {
			return $this->subscription;
		}

		global $edd_recurring_stripe;
		$this->subscription = $edd_recurring_stripe->backfill_subscription( $this->object->customer, $this->object->subscription );

		return $this->subscription;
	}

	/**
	 * Get the Stripe subscription.
	 *
	 * @since 2.13.0
	 * @return \EDD\Vendor\Stripe\Subscription|false
	 */
	private function get_stripe_subscription() {
		$subscription_id = ! empty( $this->object->subscription ) ? $this->object->subscription : false;

		/**
		 * See if the trial is still in place before allowing a 0 transaction.
		 * https://github.com/easydigitaldownloads/edd-recurring/issues/611
		 */
		$stripe_sub = ! empty( $subscription_id )
			? edds_api_request( 'Subscription', 'retrieve', $subscription_id )
			: false;

		if ( empty( $this->object->total ) && ( $stripe_sub && current_time( 'timestamp' ) < $stripe_sub->trial_end ) ) {
			die( 'EDD Recurring: Initial Trial Invoice' );
		}

		return $stripe_sub;
	}

	/**
	 * Get the order arguments.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	private function get_order_args() {
		$subscription_payment_args = array(
			'amount'         => $this->update_amount( $this->object->total ),
			'transaction_id' => $this->object->charge,
		);

		if ( ! empty( $this->object->tax ) ) {
			$subscription_payment_args['tax'] = $this->object->tax / 100;
		}

		$date = $this->get_date();
		if ( $date ) {
			$subscription_payment_args['date'] = $date;
		}

		return $subscription_payment_args;
	}

	/**
	 * Update the amount.
	 *
	 * @since 2.13.0
	 * @param int $amount The amount.
	 * @return int
	 */
	private function update_amount( $amount ) {
		if ( edds_is_zero_decimal_currency( $this->object->currency ) ) {
			return $amount;
		}

		return $amount / 100;
	}

	/**
	 * Get the date.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	private function get_date() {
		/**
		 * Create a DateTime object of the payment_date, so we can adjust as needed.
		 *
		 * Stripe passes in the timestamp when the invoice.payment_succeeded was 'paid_at'.
		 *
		 * Since this is a unix timestamp, we can can just use this date as it is alrady GMT/UTC.
		*/
		$date_time = new \DateTime();
		$date_time->setTimestamp( $this->object->status_transitions->paid_at );

		// Set the timezone on the DateTime object.
		$date_time->setTimezone( new \DateTimeZone( 'GMT' ) );

		// Now set the date into the arguments for creating the renewal payment.
		return $date_time->format( 'Y-m-d H:i:s' );
	}

	/**
	 * Maybe reactivate the subscription.
	 *
	 * @since 2.13.0
	 * @param \EDD\Vendor\Stripe\Subscription $stripe_sub The Stripe subscription.
	 */
	private function maybe_reactivate( $stripe_sub ) {
		if ( empty( $stripe_sub->metadata->reactivated ) ) {
			return;
		}

		// Set a flag so we know that this reactivation has been processed.
		edds_api_request(
			'Subscription',
			'update',
			$stripe_sub->id,
			array(
				'metadata' => array(
					'reactivation_processed' => true,
				),
			)
		);
	}
}
