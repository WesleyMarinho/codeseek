<?php
/**
 * Stripe Customer Invoice Payment Failed event.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks\Events
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks\Events;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class InvoicePaymentFailed
 *
 * @since 2.13.0
 */
class InvoicePaymentFailed extends Event {

	/**
	 * Processes the event.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process() {
		if ( ! $this->subscription ) {
			return;
		}

		/* translators: %s: invoice URL */
		$this->subscription->add_note( sprintf( __( 'Failing invoice URL: %s', 'edd-recurring' ), $this->event->data->object->hosted_invoice_url ) );

		// Don't change the status if it's currently needs_attention.
		if ( 'needs_attention' === $this->subscription->status ) {
			return;
		}

		$this->subscription->failing();

		/**
		 * Fires when a subscription payment fails.
		 *
		 * @since 2.13.0
		 * @param \EDD_Subscription $subscription The subscription object.
		 */
		do_action( 'edd_recurring_payment_failed', $this->subscription );
	}
}
