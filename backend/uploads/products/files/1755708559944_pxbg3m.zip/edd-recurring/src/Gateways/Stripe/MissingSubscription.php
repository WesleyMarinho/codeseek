<?php
/**
 * Class to fix missing subscriptions for Stripe.
 *
 * @package     EDD\Recurring\Gateways\Stripe
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class MissingSubscription
 */
class MissingSubscription {

	/**
	 * Query for missing subscriptions.
	 *
	 * @since 2.13.0
	 * @param array $args The optional arguments.
	 * @return array
	 */
	public function find( $args ) {
		$products = $this->get_recurring_products();
		if ( empty( $products ) ) {
			return array();
		}

		$products = array_map( 'absint', $products );
		$limit    = ! empty( $args['limit'] ) ? absint( $args['limit'] ) : 500;
		$offset   = ! empty( $args['offset'] ) ? absint( $args['offset'] ) : 0;

		global $wpdb;

		$query = $wpdb->prepare(
			"SELECT oi.order_id, oi.product_id, oi.price_id
				FROM {$wpdb->prefix}edd_order_items AS oi
				JOIN {$wpdb->prefix}edd_orders AS o ON oi.order_id = o.id
				LEFT JOIN {$wpdb->prefix}edd_subscriptions AS subs ON oi.order_id = subs.parent_payment_id
				WHERE oi.product_id IN (" . implode( ',', array_fill( 0, count( $products ), '%d' ) ) . ')
				AND oi.status IN (%s, %s, %s)
				AND o.parent = 0
				AND o.gateway = %s
				AND subs.id IS NULL
				ORDER BY o.id ASC
				LIMIT %d OFFSET %d',
			array_merge( $products, array( 'complete', 'partially_refunded', 'refunded', 'stripe', $limit, $offset ) ) // Values for placeholders.
		);

		return $wpdb->get_results( $query ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Fix a missing subscription.
	 *
	 * @since 2.13.0
	 * @param int $id The order ID.
	 * @return bool|string
	 */
	public static function fix( $id ) {
		if ( ! $id ) {
			return __( 'You must provide an order ID.', 'edd-recurring' );
		}

		$order = edd_get_order( $id );
		if ( ! $order || 'stripe' !== $order->gateway ) {
			return __( 'Order not found.', 'edd-recurring' );
		}

		if ( 'edd_subscription' === $order->status ) {
			return __( 'Order is a renewal.', 'edd-recurring' );
		}

		$fixed = self::fix_order( $order );
		if ( true !== $fixed ) {
			edd_update_order_meta( $order->id, '_edd_recurring_missing_subscription_error', $fixed );
		}

		return $fixed;
	}

	/**
	 * Fix the order.
	 *
	 * @since 2.13.0
	 * @param \EDD\Orders\Order $order The order object.
	 * @return bool|string
	 */
	private static function fix_order( $order ) {

		$customer_id = edd_get_order_meta( $order->id, '_edds_stripe_customer_id', true );
		if ( ! $customer_id ) {
			return __( 'Customer not found.', 'edd-recurring' );
		}

		try {
			$stripe_customer = edds_api_request( 'Customer', 'retrieve', $customer_id );
		} catch ( \Exception $e ) {
			return __( 'Stripe customer not found.', 'edd-recurring' );
		}

		if ( ! $stripe_customer ) {
			return __( 'Stripe customer not found.', 'edd-recurring' );
		}

		foreach ( $order->items as $order_item ) {
			if ( ! edd_recurring()->is_recurring( $order_item->product_id, $order_item->price_id ) ) {
				continue;
			}

			$found_subscription = self::find_subscription( $stripe_customer, $order, $order_item );
			if ( ! $found_subscription ) {
				return __( 'No matching subscription found.', 'edd-recurring' );
			}

			if ( edd_recurring_get_subscription_by( 'profile_id', $found_subscription->id ) ) {
				edd_update_order_meta( $order->id, '_edd_subscription_payment', 1 );
				return __( 'Subscription already exists.', 'edd-recurring' );
			}

			$sub = self::create_subscription( $found_subscription, $order, $order_item );
			if ( ! $sub ) {
				return __( 'Failed to create subscription.', 'edd-recurring' );
			}

			edd_update_order_meta( $order->id, '_edd_subscription_payment', 1 );
			$sub->add_note( __( 'Subscription recovered.', 'edd-recurring' ) );
		}

		return true;
	}

	/**
	 * Find a subscription.
	 *
	 * @since 2.13.0
	 * @param object $stripe_customer The Stripe customer object.
	 * @param object $order           The order object.
	 * @return bool|object
	 */
	private static function find_subscription( $stripe_customer, $order, $order_item ) {
		$subscriptions       = $stripe_customer->subscriptions->data;
		$order_creation_time = strtotime( $order->date_created );
		foreach ( $subscriptions as $subscription ) {
			// Compare timestamps (within a reasonable window, e.g., 1 hour).
			if ( abs( $subscription->created - $order_creation_time ) < HOUR_IN_SECONDS ) {
				if ( (int) $subscription->metadata->download_id !== (int) $order_item->product_id ) {
					continue;
				}
				if ( isset( $subscripton->metadata->price_id ) && (int) $subscription->metadata->price_id !== (int) $order_item->price_id ) {
					continue;
				}
				if ( ! empty( $subscription->metadata->payment_key ) && ! hash_equals( $order->payment_key, $subscription->metadata->payment_key ) ) {
					continue;
				}

				return $subscription;
			}
		}

		return false;
	}

	/**
	 * Create a subscription.
	 *
	 * @since 2.13.0
	 * @param object $found_subscription The found subscription object.
	 * @param object $order              The order object.
	 * @param object $order_item         The order item object.
	 * @return bool|int
	 */
	private static function create_subscription( $found_subscription, $order, $order_item ) {

		$product          = new \EDD\Recurring\Downloads\Product( $order_item->product_id );
		$tax_rate         = self::get_tax_rate( $order );
		$recurring_amount = edds_is_zero_decimal_currency( $order->currency ) ? $found_subscription->plan->amount : $found_subscription->plan->amount / 100;

		// get the recurring tax amount from the recurring amount and tax rate.
		$recurring_tax = 0;
		if ( $tax_rate > 0 ) {
			$recurring_tax = $recurring_amount * $tax_rate;
		}

		$args = array(
			'product_id'         => $order_item->product_id,
			'price_id'           => $order_item->price_id,
			'user_id'            => $order->user_id,
			'parent_payment_id'  => $order->id,
			'status'             => self::get_status( $found_subscription->status ),
			'period'             => $product->get_period( $order_item->price_id ),
			'initial_amount'     => (float) $order->total,
			'initial_tax_rate'   => $tax_rate,
			'initial_tax'        => (float) $order->tax,
			'recurring_amount'   => (float) $recurring_amount,
			'recurring_tax_rate' => $tax_rate,
			'recurring_tax'      => (float) $recurring_tax,
			'bill_times'         => $product->get_times( $order_item->price_id ),
			'expiration'         => self::get_formatted_expiration( $found_subscription->current_period_end ),
			'trial_period'       => $product->get_trial_period( $order_item->price_id ),
			'profile_id'         => $found_subscription->id,
			'transaction_id'     => $order->get_transaction_id(),
			'created'            => $order->date_created,
		);

		if ( edd_recurring()->is_custom_recurring( $order_item->product_id ) ) {
			$args['period'] = (float) edd_recurring()->get_custom_period( $order_item->product_id );
			$args['times']  = (int) edd_recurring()->get_custom_times( $order_item->product_id );
		}

		$subscriber = new \EDD_Recurring_Subscriber( $order->user_id, true );

		return $subscriber->add_subscription( $args );
	}

	/**
	 * Get formatted expiration date.
	 *
	 * @since 2.13.0
	 * @param int $expiration The expiration timestamp.
	 * @return string
	 */
	private static function get_formatted_expiration( $expiration ) {

		$subscription_payment_date = new \DateTime();
		$subscription_payment_date->setTimestamp( $expiration );
		/**
		 * EDD 3.0+ uses GMT format for all dates.
		 */
		$store_timezone = 'GMT';

		// Set the timezone on the DateTime object.
		$subscription_payment_date->setTimezone( new \DateTimeZone( $store_timezone ) );

		// Now set the date into the arguments for creating the renewal payment.
		return $subscription_payment_date->format( 'Y-m-d H:i:s' );
	}

	/**
	 * Get recurring products.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	private function get_recurring_products() {
		$args  = array(
			'post_type'      => 'download',
			'posts_per_page' => -1,
			'post_status'    => array( 'publish', 'private', 'draft' ),
			'no_found_rows'  => true,
			'fields'         => 'ids',
			'nopaging'       => true,
		);
		$args  = edd_recurring_product_dropdown_recurring_only( $args );
		$query = new \WP_Query( $args );

		return $query->posts;
	}

	/**
	 * Matches the Stripe subscription status to the EDD status.
	 *
	 * @since 2.13.0
	 * @param string $status The status.
	 * @return string
	 */
	private static function get_status( $status ) {
		if ( 'trialing' === $status ) {
			return 'trialling';
		}

		if ( 'past_due' === $status ) {
			return 'failing';
		}

		return $status;
	}

	/**
	 * Get the tax rate from the order.
	 *
	 * @since 2.13.0
	 * @param \EDD\Orders\Order $order The order object.
	 * @return float
	 */
	private static function get_tax_rate( $order ) {
		$tax_rate = 0;
		if ( empty( $order->tax ) ) {
			return $tax_rate;
		}

		$order_tax_rate = $order->get_tax_rate();
		if ( ! empty( $order_tax_rate ) ) {
			return $order_tax_rate / 100;
		}

		if ( edd_prices_include_tax() ) {
			return round( ( $order->tax / ( $order->total - $order->tax ) ) * 100, 4 );
		}

		return ( $order->tax / ( $order->total - $order->tax ) ) * 100;
	}
}
