<?php
/**
 * @package     EDD\Recurring\Gateways\Stripe\Update
 * @copyright   Copyright Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Update;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Stripe Update Form
 *
 * @since 2.13.0
 */
class Form {

	/**
	 * Subscription object.
	 *
	 * @var \EDD\Recurring\Subscriptions\Subscription
	 */
	protected $subscription;

	/**
	 * Constructor.
	 *
	 * @param \EDD\Recurring\Subscriptions\Subscription $subscription Subscription object.
	 */
	public function __construct( $subscription ) {
		$this->subscription = $subscription;
	}

	/**
	 * Render the update payment method form.
	 *
	 * @since 2.13.0
	 */
	public function render() {
		// Attempt to get the full Stripe Subscription object to access its properties.
		$stripe_subscription_object = null;
		if ( ! empty( $this->subscription->profile_id ) ) {
			try {
				$stripe_subscription_object = edds_api_request(
					'Subscription',
					'retrieve',
					array(
						'id'     => $this->subscription->profile_id,
						'expand' => array( 'latest_invoice.payment_intent', 'pending_setup_intent' ),
					)
				);
			} catch ( \Exception $e ) {
				// Do nothing (we'll output an error message later).
			}
		}

		if ( ! $stripe_subscription_object ) {
			// Output error message directly if Stripe API call fails.
			echo '<p class="edd-alert edd-alert-error">' . esc_html__( 'Error retrieving subscription details from Stripe.', 'edd-recurring' ) . ' ' . esc_html( $e->getMessage() ) . '</p>';
			return;
		}

		$this->render_latest_payment_intent( $stripe_subscription_object );
		if ( 'payment-elements' === edds_get_elements_mode() ) {
			$this->render_payment_elements_form( $stripe_subscription_object );
		} else {
			$this->render_card_elements_form( $stripe_subscription_object );
		}
	}

	/**
	 * Render the payment elements form.
	 *
	 * @since 2.13.0
	 * @param \Stripe\Subscription $stripe_subscription_object Stripe subscription object.
	 */
	private function render_payment_elements_form( $stripe_subscription_object ) {
		// New Payment Elements flow.
		edd_stripe_js( true ); // Ensures Stripe SDK is loaded.

		wp_enqueue_script(
			'edd-recurring-stripe-payment-elements',
			EDD_RECURRING_PLUGIN_URL . 'assets/js/edd-recurring-stripe-payment-elements.js',
			array( 'jquery', 'edd-stripe-js', 'wp-dom-ready' ),
			EDD_RECURRING_VERSION,
			true
		);

		wp_localize_script(
			'edd-recurring-stripe-payment-elements',
			'eddRecurringStripePaymentElementsVars',
			$this->get_localization_args( $stripe_subscription_object )
		);

		?>
		<div id="edd-recurring-stripe-payment-element">
			<!-- Stripe Payment Element will be mounted here -->
		</div>
		<div id="edd-recurring-stripe-payment-error" role="alert" class="edd-alert edd-alert-error" style="display: none;"></div>
		<?php
	}

	/**
	 * Render the legacy card elements form.
	 *
	 * @since 2.13.0
	 * @param \Stripe\Subscription $stripe_subscription_object Stripe subscription object.
	 */
	private function render_card_elements_form( $stripe_subscription_object ) {
		add_filter( 'edd_is_checkout', '__return_true' );
		edd_load_scripts();
		edd_stripe_js( true );

		remove_filter( 'edd_is_checkout', '__return_true' );

		wp_enqueue_script(
			'edd-frontend-recurring-stripe',
			EDD_RECURRING_PLUGIN_URL . 'assets/js/edd-frontend-recurring-stripe.js',
			array( 'jquery', 'edd-stripe-js', 'wp-dom-ready' ),
			EDD_RECURRING_VERSION,
			true
		);

		wp_localize_script(
			'edd-frontend-recurring-stripe',
			'eddRecurringStripeVars',
			$this->get_localization_args( $stripe_subscription_object )
		);

		echo '<input type="hidden" id="edd_recurring_stripe_default_payment_method" value="' . esc_attr( $stripe_subscription_object->default_payment_method ) . '" />';

		do_action( 'edd_stripe_cc_form' );
	}

	/**
	 * Render a hidden input with the latest payment intent ID if the latest invoice is unpaid.
	 *
	 * @since 2.13.0
	 * @param \Stripe\Subscription $stripe_subscription_object Stripe subscription object.
	 */
	private function render_latest_payment_intent( $stripe_subscription_object ) {
		$latest_open_invoice = edds_api_request(
			'Invoice',
			'all',
			array(
				'subscription' => $stripe_subscription_object->id,
				'limit'        => 1,
				'status'       => 'open',
				'customer'     => $stripe_subscription_object->customer,
			)
		);

		if ( empty( $latest_open_invoice->data ) ) {
			return;
		}

		$invoice = current( $latest_open_invoice->data );
		if ( $invoice->payment_intent ) {
			$payment_intent_id = is_string( $invoice->payment_intent ) ? $invoice->payment_intent : $invoice->payment_intent->id;
			$payment_intent    = edds_api_request( 'PaymentIntent', 'retrieve', $payment_intent_id );
			if ( 'succeeded' !== $payment_intent->status ) {
				echo '<input type="hidden" name="edd_recurring_stripe_payment_intent" value="' . esc_attr( $payment_intent->id ) . '" />';
			}
		}
	}

	/**
	 * Get the localization arguments for the payment elements form.
	 *
	 * @since 2.13.0
	 * @param \Stripe\Subscription $stripe_subscription_object Stripe subscription object.
	 * @return array The localization arguments.
	 */
	private function get_localization_args( $stripe_subscription_object ): array {
		$profile_id_for_nonce = ! empty( $stripe_subscription_object->id ) ? $stripe_subscription_object->id : $this->subscription->profile_id;
		$timestamp            = time();

		return array(
			'ajax_url'        => admin_url( 'admin-ajax.php' ),
			'revert_pm_nonce' => wp_create_nonce( 'edd_recurring_revert_pm_update_' . $profile_id_for_nonce ),
			'subscription_id' => $profile_id_for_nonce, // Stripe Subscription ID.
			'currency'        => strtolower( edd_get_currency() ),
			'customer_email'  => $this->subscription->customer ? $this->subscription->customer->email : '',
			'customer_name'   => $this->subscription->customer ? $this->subscription->customer->name : '',
			'timestamp'       => $timestamp,
			'token'           => \EDD\Utils\Tokenizer::tokenize( $timestamp ),
		);
	}
}
