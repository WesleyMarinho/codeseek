<?php
/**
 * Stripe Webhook Listener.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * The listener class.
 *
 * @since 2.13.0
 */
class Listener {

	/**
	 * The event object.
	 *
	 * @var \EDD\Recurring\Gateways\Stripe\Webhooks\Event
	 * @since 2.13.0
	 */
	protected $event;

	/**
	 * Listener constructor.
	 *
	 * @since 2.13.0
	 */
	public function __construct( $event ) {
		$this->event = $event;
	}

	/**
	 * Processes the event.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	public function process() {
		status_header( 200 );

		$event_class = $this->parse_event_class( $this->event->type );
		/**
		 * We typically try and use the ::class constant, but we need to be able to support
		 * events that are not registered classes, so we will manually build the class name,
		 * so we don't trigger the catch block, which allows a hook to fire for the event.
		 */
		$event_class = __NAMESPACE__ . '\\Events\\' . $event_class;

		// Check our event classes to see if it exists.
		if ( class_exists( $event_class ) && is_subclass_of( $event_class, '\\EDD\\Recurring\\Gateways\\Stripe\\Webhooks\\Events\\Event' ) ) {
			$event = new $event_class( $this->event );
			if ( $event->verify_mode() && $event->requirements_met() ) {

				/**
				 * Fires before processing a Stripe webhook event.
				 *
				 * @since 2.13.0
				 * @param string $event_type The event type.
				 * @param \Stripe\Event $event The event object.
				 * @param \EDD_Subscription $subscription The subscription object.
				 */
				do_action( 'edd_pre_recurring_stripe_event', $this->event->type, $this->event, $event->subscription );

				/**
				 * Fires before processing a Stripe webhook event.
				 *
				 * @since 2.13.0
				 * @param \Stripe\Event $event The event object.
				 * @param \EDD_Subscription $subscription The subscription object.
				 */
				do_action( 'edd_pre_recurring_stripe_event_' . $this->event->type, $this->event, $event->subscription );

				$event->process();

				/**
				 * Fires after processing a Stripe webhook event.
				 *
				 * @since 2.13.0
				 * @param string        $event_type The event type.
				 * @param \Stripe\Event $event      The event object.
				 */
				do_action( 'edd_recurring_stripe_event_' . $this->event->type, $this->event );

				return true;
			}
		}

		return false;
	}

	/**
	 * Gets the event class.
	 *
	 * Events are in the format of `object.action` or `object.subobject.action`. We will convert these
	 * to camel case and remove periods to get the class name.
	 *
	 * For example:
	 * `charge.succeeded` would become `ChargeSucceeded`.
	 * `radar.early_fraud_warning.created` would become `RadarEarlyFraudWarningCreated`.
	 *
	 * @since 3.3.0
	 * @param string $event_type The event type.
	 * @return string
	 */
	private function parse_event_class( $event_type ) {
		// Replace the . and _ characters with spaces.
		$event_type = str_replace( array( '.', '_' ), ' ', $event_type );

		// Uppercase the first letter of each word.
		$event_type = ucwords( $event_type );

		// Remove spaces.
		return str_replace( ' ', '', $event_type );
	}
}
