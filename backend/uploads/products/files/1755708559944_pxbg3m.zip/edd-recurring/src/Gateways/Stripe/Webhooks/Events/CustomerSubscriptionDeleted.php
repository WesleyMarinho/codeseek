<?php
/**
 * Stripe Customer Subscription Deleted event.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks\Events
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks\Events;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class CustomerSubscriptionDeleted
 *
 * @since 2.13.0
 */
class CustomerSubscriptionDeleted extends Event {

	/**
	 * Processes the event.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process() {
		if ( ! $this->subscription || in_array( $this->subscription->status, array( 'completed', 'canceled' ), true ) ) {
			return;
		}

		$this->subscription->cancel();
		$this->subscription->add_note( __( 'Subscription deleted in Stripe.', 'edd-recurring' ) );
	}
}
