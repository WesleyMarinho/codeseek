<?php
/**
 * Stripe Customer Subscription Updated event.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks\Events
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks\Events;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class CustomerSubscriptionUpdated
 *
 * @since 2.13.0
 */
class CustomerSubscriptionUpdated extends Event {

	/**
	 * Processes the event.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process() {
		if ( ! $this->subscription ) {
			return;
		}

		if ( ! empty( $this->data->cancel_at_period_end ) ) {
			// This is a subscription that has been cancelled but not deleted until period end.
			$this->subscription->cancel();
		}

		if ( 'failing' === $this->subscription->status && ! empty( $this->data->canceled_at ) ) {
			$this->subscription->cancel();
		}

		$old_amount = $this->subscription->recurring_amount;
		$new_amount = $this->object->plan->amount;

		if ( ! edds_is_zero_decimal_currency( $this->object->currency ) ) {
			$new_amount /= 100;
		}

		$old_amount = edd_sanitize_amount( $old_amount );
		$new_amount = edd_sanitize_amount( $new_amount );

		if ( $new_amount !== $old_amount ) {
			$this->subscription->update( array( 'recurring_amount' => $new_amount ) );
			/* translators: %1$s: old amount, %2$s: new amount */
			$this->subscription->add_note( sprintf( __( 'Recurring amount changed from %1$s to %2$s in Stripe.', 'edd-recurring' ), $old_amount, $new_amount ) );
		}
	}
}
