<?php
/**
 * Stripe Webhook Event.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks\Events\Traits
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks\Events\Traits;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Trait Mode
 *
 * @since 2.13.0
 */
trait Mode {
	/**
	 * Verify the webhook mode.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	public function verify_mode() {
		$store_mode = edd_is_test_mode() ? 'test' : 'live';
		$event_mode = $this->event->livemode ? 'live' : 'test';

		return $store_mode === $event_mode;
	}
}
