<?php
/**
 * Stripe Webhook Event.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks\Events
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks\Events;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class Event
 *
 * @since 2.13.0
 */
abstract class Event {
	use Traits\Mode;

	/**
	 * The event object.
	 *
	 * @var \Stripe\Event
	 * @since 2.13.0
	 */
	protected $event;

	/**
	 * The event data.
	 *
	 * @var object
	 * @since 2.13.0
	 */
	protected $data;

	/**
	 * The event object.
	 *
	 * This type will vary by webhook. Each webhook event should define this property with the appropriate type.
	 *
	 * @var object
	 * @since 2.13.0
	 */
	protected $object;

	/**
	 * The subscription object.
	 *
	 * @var \EDD_Subscription
	 * @since 2.13.0
	 */
	public $subscription;

	/**
	 * Event constructor.
	 *
	 * @since 2.13.0
	 *
	 * @param \Stripe\Event $event The event object.
	 */
	public function __construct( $event ) {
		$this->event        = $event;
		$this->data         = $event->data;
		$this->object       = $event->data->object;
		$this->subscription = $this->get_subscription();
	}

	/**
	 * Check the event mode against the store mode.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	abstract public function process();

	/**
	 * Check if the requirements are met for processing the event.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	public function requirements_met() {
		if ( ! $this->subscription ) {
			return false;
		}

		$parent_payment_id = $this->subscription->get_original_payment_id();
		$webhook_key       = $this->get_webhook_key();
		$webhook_attempt   = edd_get_order_meta( $parent_payment_id, $webhook_key, true );

		if ( ! empty( $webhook_attempt ) ) {
			return false;
		}

		// Log this Event ID in the Subscription's parent order meta to avoid running the process again.
		edd_update_order_meta( $parent_payment_id, $webhook_key, $this->event->id );

		return true;
	}

	/**
	 * Get the subscription.
	 *
	 * @since 2.13.0
	 * @return \EDD_Subscription|false
	 */
	protected function get_subscription() {

		edd_debug_log( 'Stripe Webhook: Event ID/type: ' . $this->event->id . ' / ' . $this->event->type );

		if ( ! empty( $this->object->object ) && 'subscription' === $this->object->object ) {
			edd_debug_log( 'Stripe Webhook: Subscription ID from object object: ' . $this->object->id );

			return edd_recurring_get_subscription_by( 'profile_id', $this->object->id );
		}

		if ( ! empty( $this->object->subscription ) ) {
			edd_debug_log( 'Stripe Webhook: Subscription ID from object: ' . $this->object->subscription );

			return edd_recurring_get_subscription_by( 'profile_id', $this->object->subscription );
		}

		if ( ! empty( $this->object->metadata->edd_subscription_id ) ) {
			edd_debug_log( 'Stripe Webhook: Subscription ID from metadata: ' . $this->object->metadata->edd_subscription_id );

			return edd_recurring_get_subscription( $this->object->metadata->edd_subscription_id );
		}

		edd_debug_log( 'Stripe Webhook: No subscription found for' . $this->event->id );

		return false;
	}

	/**
	 * Get the webhook key.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	private function get_webhook_key() {
		return sprintf( '_edd_recurring_stripe_event_%s', $this->event->id );
	}
}
