<?php
/**
 * Class to load Stripe specific functionality that doesn't need to be in the main gateway class.
 *
 * @package     EDD\Recurring\Gateways\Stripe
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use EDD\EventManagement\SubscriberInterface;

/**
 * Class Loader
 */
class Loader implements SubscriberInterface {

	/**
	 * Get the subscribed events.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'wp_ajax_edd_recurring_revert_failed_pm_update'   => 'revert_failed_payment_method_update',
			'wp_ajax_edd_recurring_update_pm_elements'        => 'update_payment_method_payment_elements',
			'wp_ajax_nopriv_edd_recurring_update_pm_elements' => 'update_payment_method_payment_elements',
		);
	}

	/**
	 * AJAX callback to revert a failed payment method update on Stripe.
	 *
	 * @since 2.13.0
	 */
	public function revert_failed_payment_method_update() {
		$subscription_id            = filter_input( INPUT_POST, 'subscription_id', FILTER_SANITIZE_SPECIAL_CHARS );
		$original_payment_method_id = filter_input( INPUT_POST, 'original_payment_method_id', FILTER_SANITIZE_SPECIAL_CHARS );
		$nonce                      = filter_input( INPUT_POST, 'nonce', FILTER_SANITIZE_SPECIAL_CHARS );

		if ( ! $subscription_id || ! $original_payment_method_id || ! $nonce ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request parameters for reverting payment method.', 'edd-recurring' ) ) );
		}

		// Verify the nonce. The action includes the subscription ID.
		if ( ! wp_verify_nonce( $nonce, 'edd_recurring_revert_pm_update_' . $subscription_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Nonce verification failed.', 'edd-recurring' ) ) );
		}

		// The $subscription_id POSTed here is the Stripe Subscription ID.
		$edd_subscription = edd_recurring_get_subscription_by( 'profile_id', $subscription_id );

		if ( ! $edd_subscription ) {
			wp_send_json_error( array( 'message' => __( 'Could not load subscription for revert.', 'edd-recurring' ) ) );
		}

		if ( ! $edd_subscription->current_user_can() ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to update this subscription.', 'edd-recurring' ) ) );
		}

		$previous_status = $edd_subscription->status;

		try {
			// Proactively set to needs_attention and add a note.
			// $edd_subscription->update( array( 'status' => 'needs_attention' ) ); // Status is only changed if Stripe revert fails, per user intent.
			$edd_subscription->add_note( __( 'Client-side payment method confirmation failed. Attempting to revert payment method on Stripe.', 'edd-recurring' ) );

			// Attempt to revert on Stripe.
			edds_api_request(
				'Subscription',
				'update',
				$subscription_id, // This is the Stripe Subscription ID.
				array(
					'default_payment_method' => $original_payment_method_id,
				)
			);

			// If Stripe revert was successful, restore previous status.
			// $edd_subscription->update( array( 'status' => $previous_status ) ); // Status is not changed if Stripe revert succeeds, per user intent.
			$edd_subscription->add_note(
				__( 'Stripe payment method successfully reverted.', 'edd-recurring' )
			);
			wp_send_json_success( array( 'message' => __( 'Payment method change reverted on Stripe.', 'edd-recurring' ) ) );

		} catch ( \Exception $e ) {
			// Stripe revert failed or another issue occurred. Set EDD Subscription to 'needs_attention'.
			$edd_subscription->update( array( 'status' => 'needs_attention' ) );
			$error_message = $e->getMessage();
			edd_debug_log( 'EDD Recurring Stripe: Failed to revert payment method for Stripe subscription ' . $subscription_id . '. Error: ' . $error_message );
			$edd_subscription->add_note(
				sprintf(
					/* translators: %s: Error message from Stripe or system. */
					__( 'Stripe payment method revert FAILED. Subscription requires manual attention. Error: %s', 'edd-recurring' ),
					$error_message
				)
			);

			/* translators: %s: Error message from Stripe or system. */
			wp_send_json_error( array( 'message' => sprintf( __( 'New payment method confirmation failed. We also encountered an issue restoring your previous payment method on Stripe: %s. Please contact support.', 'edd-recurring' ), $error_message ) ) );
		}
	}

	/**
	 * AJAX handler for updating a Subscription's default payment method using Payment Elements.
	 *
	 * @since 2.13.0
	 * @throws \Exception If Stripe API calls fail.
	 */
	public function update_payment_method_payment_elements() {
		$nonce = filter_input( INPUT_POST, 'nonce', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'update-payment' ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Invalid request. Please try again.', 'edd-recurring' ),
				)
			);
		}

		$subscription_id   = filter_input( INPUT_POST, 'subscription_id', FILTER_SANITIZE_SPECIAL_CHARS ); // This is Stripe Subscription ID.
		$payment_method_id = filter_input( INPUT_POST, 'payment_method_id', FILTER_SANITIZE_SPECIAL_CHARS ); // This is the new Stripe PaymentMethod ID.

		if ( ! $subscription_id || ! $payment_method_id ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Unable to locate Subscription or Payment Method. Please try again.', 'edd-recurring' ),
				)
			);
		}

		$payment_method_exists                 = filter_input( INPUT_POST, 'payment_method_exists', FILTER_VALIDATE_BOOLEAN );
		$billing_address_raw                   = filter_input( INPUT_POST, 'billing_address', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
		$original_payment_method_id_for_revert = null;
		$retrieved_setup_intent                = null;
		$stripe_subscription_object            = null;
		$edd_subscription_id_for_js            = null; // Initialize EDD Subscription ID for JS.

		try {
			// Retrieve the subscription to get its current default payment method BEFORE updating.
			// This is crucial for the revert functionality.
			$stripe_sub_for_original_pm = edds_api_request(
				'Subscription',
				'retrieve',
				array(
					'id'     => $subscription_id,
					'expand' => array( 'latest_invoice.payment_intent', 'pending_setup_intent' ),
				)
			);
			if ( ! empty( $stripe_sub_for_original_pm->default_payment_method ) ) {
				$original_payment_method_id_for_revert = $stripe_sub_for_original_pm->default_payment_method;
			}

			// Get EDD Subscription ID to pass back to JS for the second AJAX call.
			$edd_subscription_object_for_id = edd_recurring_get_subscription_by( 'profile_id', $subscription_id );
			if ( $edd_subscription_object_for_id && $edd_subscription_object_for_id->id > 0 ) {
				$edd_subscription_id_for_js = $edd_subscription_object_for_id->id;
			}

			// If the new payment method is the same as the original, don't do anything, but act like it was a success.
			if ( $original_payment_method_id_for_revert === $payment_method_id && $payment_method_exists ) {
				wp_send_json_success(
					array(
						'message'                    => esc_html__( 'Payment method is already up to date.', 'edd-recurring' ),
						'subscription'               => $stripe_sub_for_original_pm,
						'setup_intent'               => null, // No setup intent needed as no change.
						'original_payment_method_id' => $original_payment_method_id_for_revert,
						'edd_subscription_id'        => $edd_subscription_id_for_js, // Pass EDD Sub ID even if no change.
					)
				);
				return;
			}

			$customer_id = $stripe_sub_for_original_pm->customer;
			if ( empty( $customer_id ) ) { // Use Yoda condition.
				// Attempt to get customer ID from EDD customer record if not directly on Stripe subscription.
				// $edd_subscription_object_for_id is already loaded above.
				if ( $edd_subscription_object_for_id && $edd_subscription_object_for_id->customer_id ) {
					$edd_customer = new \EDD_Customer( $edd_subscription_object_for_id->customer_id );
					if ( $edd_customer && $edd_customer->id > 0 ) {
						$customer_id = edds_get_stripe_customer_id( $edd_customer->user_id, true ); // true to create if not exists.
						if ( empty( $customer_id ) && ! empty( $edd_customer->email ) ) {
							// Fallback: try to get by email, then create.
							$stripe_customer_object = edds_get_stripe_customer_by_email( $edd_customer->email );
							if ( $stripe_customer_object ) {
								$customer_id = $stripe_customer_object->id;
							} else {
								// Create Stripe customer if none found.
								$stripe_customer_object = edds_create_stripe_customer( $edd_customer->email, $payment_method_id );
								$customer_id            = $stripe_customer_object->id;
							}
						}
					}
				}
			}

			if ( empty( $customer_id ) ) { // Use Yoda condition.
				throw new \Exception( __( 'Could not determine Stripe Customer ID for this subscription.', 'edd-recurring' ) );
			}

			// If it's a new PaymentMethod, retrieve it and call its attach() method.
			if ( false === $payment_method_exists ) {
				$payment_method_object = edds_api_request( 'PaymentMethod', 'retrieve', $payment_method_id );
				if ( $payment_method_object ) {
					$payment_method_object->attach( array( 'customer' => $customer_id ) );
				} else {
					throw new \Exception( __( 'Could not retrieve new PaymentMethod to attach to customer.', 'edd-recurring' ) );
				}
			} elseif ( $payment_method_exists && ! empty( $billing_address_raw ) ) {
				// Update an existing payment method's billing details if provided.
				$billing_address_sanitized = array_map( 'sanitize_text_field', $billing_address_raw );
				if ( ! empty( array_filter( $billing_address_sanitized ) ) ) { // Check if array has actual values after sanitizing.
					edds_api_request(
						'PaymentMethod',
						'update',
						$payment_method_id,
						array(
							'billing_details' => array(
								'address' => $billing_address_sanitized,
							),
						)
					);
				}
			}

			// Set the Subscription's default payment method.
			$stripe_subscription_object = edds_api_request(
				'Subscription',
				'update',
				$subscription_id,
				array(
					'default_payment_method' => $payment_method_id,
					'expand'                 => array( 'latest_invoice.payment_intent', 'pending_setup_intent' ),
				)
			);

			$response_data = array(
				'message'                    => esc_html__( 'Payment method updated with Stripe.', 'edd-recurring' ),
				'subscription'               => $stripe_subscription_object,
				'setup_intent'               => null,
				'original_payment_method_id' => $original_payment_method_id_for_revert,
				'edd_subscription_id'        => $edd_subscription_id_for_js, // Pass EDD Sub ID back to JS.
			);

			if ( ! empty( $stripe_subscription_object->pending_setup_intent ) ) {
				// The pending_setup_intent field can be an ID (string) or an expanded SetupIntent object.
				$setup_intent_id_or_object = $stripe_subscription_object->pending_setup_intent;
				$si_id_to_retrieve         = null;

				if ( is_string( $setup_intent_id_or_object ) ) {
					$si_id_to_retrieve = $setup_intent_id_or_object;
				} elseif ( is_object( $setup_intent_id_or_object ) && ! empty( $setup_intent_id_or_object->id ) ) {
					// It's already an expanded object.
					if ( in_array( $setup_intent_id_or_object->status, array( 'requires_action', 'requires_confirmation' ), true ) ) {
						$retrieved_setup_intent = $setup_intent_id_or_object;
					}
				}

				if ( $si_id_to_retrieve && ! $retrieved_setup_intent ) {
					// If we have an ID and haven't set the SI object yet, retrieve it.
					$temp_si = edds_api_request( 'SetupIntent', 'retrieve', $si_id_to_retrieve );
					if ( $temp_si && isset( $temp_si->status ) && in_array( $temp_si->status, array( 'requires_action', 'requires_confirmation' ), true ) ) {
						$retrieved_setup_intent = $temp_si;
					}
				}

				if ( $retrieved_setup_intent ) {
						$response_data['setup_intent'] = $retrieved_setup_intent;
					// Message is updated by JS if SI is present.
				}
			}

			// If a payment was successful and there's an intent, try to pay the latest open invoice.
			// This is similar to how EDD Stripe core handles it after adding a PM.
			if ( empty( $response_data['setup_intent'] ) && ! empty( $stripe_subscription_object->latest_invoice ) ) { // Use Yoda condition.
				$latest_invoice = null;
				if ( is_string( $stripe_subscription_object->latest_invoice ) ) {
					$latest_invoice = edds_api_request( 'Invoice', 'retrieve', $stripe_subscription_object->latest_invoice, array( 'expand' => array( 'payment_intent' ) ) );
				} elseif ( is_object( $stripe_subscription_object->latest_invoice ) ) {
					$latest_invoice = $stripe_subscription_object->latest_invoice;
					// If payment_intent is a string on the already expanded latest_invoice, expand it now.
					if ( ! empty( $latest_invoice->payment_intent ) && is_string( $latest_invoice->payment_intent ) ) {
						$latest_invoice->payment_intent = edds_api_request( 'PaymentIntent', 'retrieve', $latest_invoice->payment_intent );
					}
				}

				if ( $latest_invoice && 'open' === $latest_invoice->status && ! empty( $latest_invoice->payment_intent ) ) {
					$intent_to_confirm = is_string( $latest_invoice->payment_intent ) ? edds_api_request( 'PaymentIntent', 'retrieve', $latest_invoice->payment_intent ) : $latest_invoice->payment_intent;
					if ( $intent_to_confirm && 'requires_payment_method' === $intent_to_confirm->status ) {
						// The invoice's PI might need confirmation with the new PM.
						// This is an advanced scenario; often Stripe handles retrying invoices automatically.
						// For now, we won't auto-confirm this PI to keep the flow simpler.
						// Stripe's dunning should pick it up.
					} elseif ( $intent_to_confirm && in_array( $intent_to_confirm->status, array( 'requires_confirmation', 'requires_action' ), true ) ) {
						// If the latest invoice's PI also needs action, prefer the SetupIntent for the PM update itself.
						// This means we won't send this PI client secret if a pending_setup_intent exists.
						// The logic above already prioritizes pending_setup_intent.
					}
				}
			}

			wp_send_json_success( $response_data );
		} catch ( \Exception $e ) {
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				)
			);
		}
	}
}
