<?php
/**
 * Stripe Customer Subscription Created event.
 *
 * @package     EDD\Recurring\Gateways\Stripe\Webhooks\Events
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Gateways\Stripe\Webhooks\Events;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class CustomerSubscriptionCreated
 *
 * @since 2.13.0
 */
class CustomerSubscriptionCreated extends Event {

	/**
	 * Processes the event.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process() {
		if ( $this->subscription ) {
			$this->activate( $this->subscription );
			return;
		}

		$subscriptions = $this->get_subscriptions_from_order();
		if ( ! $subscriptions ) {
			return;
		}

		foreach ( $subscriptions as $subscription ) {
			$this->activate( $subscription );
		}
	}

	/**
	 * Activates the subscription.
	 *
	 * @since 2.13.0
	 * @param \EDD_Subscription $subscription The subscription object.
	 */
	private function activate( $subscription ) {

		if ( empty( $this->object->status ) || 'active' !== $this->object->status ) {
			return;
		}

		// If the subscription was activated on the charge.succeeded event, don't activate it again.
		if ( in_array( $subscription->status, array( 'active', 'trialling' ), true ) ) {
			edd_debug_log( sprintf( 'Subscription %d is already active or trialling.', $subscription->id ) );
			return;
		}

		$subscription->update(
			array(
				'status' => empty( $subscription->trial_period ) ? 'active' : 'trialling',
			)
		);

		$subscription->add_note( 'Subscription activated via Stripe webhook.' );
	}

	/**
	 * Gets the subscription from the event.
	 *
	 * @since 2.13.0
	 * @return \EDD_Subscription|bool
	 */
	private function get_subscriptions_from_order() {
		if ( empty( $this->object->metadata->payment_key ) ) {
			return false;
		}

		$order = edd_get_order_by( 'payment_key', $this->object->metadata->payment_key );
		if ( ! $order ) {
			return false;
		}

		edd_debug_log( 'Stripe Webhook: Order ID from metadata: ' . $order->id );

		$subscription_db = new \EDD_Subscriptions_DB();

		return $subscription_db->get_subscriptions(
			array(
				'parent_payment_id' => $order->id,
				'status'            => 'pending',
			)
		);
	}
}
