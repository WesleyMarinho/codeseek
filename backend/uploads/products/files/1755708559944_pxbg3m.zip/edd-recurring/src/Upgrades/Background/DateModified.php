<?php
/**
 * Background upgrade for updating the date modified column.
 *
 * @package     EDD\Upgrades\Background
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Upgrades\Background;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * DateModified upgrade class.
 *
 * @since 2.13.0
 */
class DateModified extends Upgrade {

	/**
	 * Mark the upgrade as silent.
	 *
	 * @var boolean
	 */
	protected $is_silent = true;

	/**
	 * The number of database rows which should prevent the upgrade running via the background process.
	 *
	 * @var int
	 */
	protected $warning_count = 0;

	/**
	 * The number of items to process per step.
	 *
	 * @var int
	 */
	protected $per_step = 100;

	/**
	 * The name of the upgrade.
	 *
	 * @since 2.13.0
	 * @var string
	 */
	public static function get_upgrade_name(): string {
		return 'subscriptions_date_modified';
	}

	/**
	 * Process the upgrade step.
	 * The database is modified directly since Berlin will
	 * always change the date modified to the current date/time.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process_step(): void {
		if ( ! $this->can_process_step() ) {
			return;
		}

		$items = $this->get_items( false );
		if ( empty( $items ) ) {
			$this->mark_complete();
			return;
		}

		global $wpdb;

		foreach ( $items as $item ) {
			$date_modified = $this->get_subscription_date_modified( $item );
			edd_debug_log( 'Updating subscription ' . $item->id . ' with date modified: ' . $date_modified );
			$wpdb->update(
				$wpdb->edd_subscriptions,
				array( 'date_modified' => $date_modified ),
				array( 'id' => $item->id ),
				array( '%s' ),
				array( '%d' )
			);
		}

		$this->add_or_update_initial_notification();

		// Schedule the next step.
		self::schedule_next_event( time() + MINUTE_IN_SECONDS );
	}

	/**
	 * Get the items to process.
	 *
	 * @since 2.13.0
	 * @param bool $count Whether to return the count of items.
	 * @return array|bool
	 */
	public function get_items( $count = false ) {

		if ( $count ) {
			return edd_recurring_count_subscriptions();
		}

		$step     = get_option( self::get_upgrade_name() . '_step', 0 );
		$step     = absint( $step );
		$per_step = $this->get_count_per_step();

		$subscriptions = edd_recurring_get_subscriptions(
			array(
				'number' => $per_step,
				'offset' => $step * $per_step,
			)
		);

		update_option( self::get_upgrade_name() . '_step', ++$step, false );

		return $subscriptions;
	}

	/**
	 * Get the complete notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_complete_notification(): array {
		return array();
	}

	/**
	 * Get the in progress notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_in_progress_notification(): array {
		return array();
	}

	/**
	 * Get the CLI notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_cli_notification(): array {
		return array();
	}

	/**
	 * Mark the upgrade as complete.
	 * Ensures that the step option is deleted.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	protected function mark_complete() {
		parent::mark_complete();
		delete_option( self::get_upgrade_name() . '_step' );
	}

	/**
	 * Gets the subscription last modified date based on the subscription notes.
	 *
	 * @since 2.13.0
	 * @param \EDD_Subscription $subscription The subscription object.
	 * @return string
	 */
	private function get_subscription_date_modified( $subscription ) {
		$notes = $subscription->get_notes( 1000 );
		if ( empty( $notes ) ) {
			return $subscription->created;
		}

		$latest_note = reset( $notes );
		$note_parts  = explode( ' - ', $latest_note );
		$timestamp   = strtotime( reset( $note_parts ) );
		$timestamp   = $timestamp - get_option( 'gmt_offset' ) * HOUR_IN_SECONDS;

		return gmdate( 'Y-m-d H:i:s', $timestamp );
	}
}
