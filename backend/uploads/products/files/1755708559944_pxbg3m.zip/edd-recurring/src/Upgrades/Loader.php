<?php
/**
 * Loader for Recurring Upgrades.
 *
 * @package     EDD\Recurring\Upgrades
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Upgrades;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\EventManagement\SubscriberInterface;
use EDD\EventManagement\EventManager;

/**
 * Class Loader
 *
 * @since 2.13.0
 * @package EDD\Upgrades
 */
class Loader implements SubscriberInterface {

	/**
	 * Get the events to subscribe to.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'edd_setup_components' => 'add_events',
		);
	}

	/**
	 * Add the upgrade events.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function add_events() {
		$upgrade_classes = array(
			new Background\StripeTrials(),
			new Background\DateModified(),
			new Background\GatewayColumn(),
			new Background\Notes(),
		);

		$events = new EventManager();
		foreach ( $upgrade_classes as $upgrade_class ) {
			$events->add_subscriber( $upgrade_class );
		}
	}
}
