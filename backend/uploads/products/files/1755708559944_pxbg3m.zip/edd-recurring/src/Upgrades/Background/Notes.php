<?php
/**
 * Background upgrade for populating the gateway column.
 *
 * @package     EDD\Upgrades\Background
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Upgrades\Background;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Notes upgrade class.
 *
 * @since 2.13.0
 */
class Notes extends Upgrade {

	/**
	 * The number of database rows which should prevent the upgrade running via the background process.
	 *
	 * @var int
	 */
	protected $warning_count = 0;

	/**
	 * The name of the upgrade.
	 *
	 * @since 2.13.0
	 * @var string
	 */
	public static function get_upgrade_name(): string {
		return 'subscriptions_notes';
	}

	/**
	 * Hook into actions and filters.
	 *
	 * @since 2.13.0
	 */
	public static function get_subscribed_events() {
		if ( ! edd_has_upgrade_completed( 'subscriptions_date_modified' ) ) {
			return array();
		}

		return parent::get_subscribed_events();
	}

	/**
	 * Process the upgrade step.
	 * The database is modified directly since Berlin will
	 * always change the date modified to the current date/time.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process_step(): void {
		if ( ! $this->can_process_step() ) {
			return;
		}

		$items = $this->get_items( false );
		if ( empty( $items ) ) {
			$this->mark_complete();
			return;
		}

		global $wpdb;

		foreach ( $items as $item ) {
			$notes = $item->get_notes( 1000 );

			foreach ( $notes as $note ) {
				$note_parts   = explode( ' - ', $note );
				$date_created = \EDD\Recurring\Utilities\Date::get_gmdate_from_string( reset( $note_parts ) );
				$args         = array(
					'object_id'   => $item->id,
					'object_type' => 'subscription',
					'content'     => $note,
				);

				if ( false !== $date_created ) {
					$args['date_created'] = $date_created;
					if ( ! empty( $note_parts[1] ) ) {
						$args['content'] = $note_parts[1];
					}
				}

				$note_id = edd_add_note( $args );
			}

			// Use the $wpdb object to update the notes column to an empty string because the column is not registered in Berlin.
			$wpdb->update(
				$wpdb->edd_subscriptions,
				array( 'notes' => '' ),
				array( 'id' => $item->id )
			);
			edd_recurring_update_subscription_meta( $item->id, 'notes_migrated', time() );
		}

		$this->add_or_update_initial_notification();

		// Schedule the next step.
		self::schedule_next_event( time() + ( 2 * MINUTE_IN_SECONDS ) );
	}

	/**
	 * Get the items to process.
	 *
	 * @since 2.13.0
	 * @param bool $count Whether to return the count of items.
	 * @return array|bool
	 */
	public function get_items( $count = false ) {

		if ( $count ) {
			return edd_recurring_count_subscriptions(
				array(
					'notes__not_in' => array( '' ),
					'meta_query'    => array(
						array(
							'key'     => 'notes_migrated',
							'compare' => 'NOT EXISTS',
						),
					),
				)
			);
		}

		return edd_recurring_get_subscriptions(
			array(
				'number'        => 30,
				'notes__not_in' => array( '' ),
				'meta_query'    => array(
					array(
						'key'     => 'notes_migrated',
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);
	}

	/**
	 * Get the complete notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_complete_notification(): array {
		return array(
			'title'   => __( 'Subscription Upgrade Complete', 'edd-recurring' ),
			'content' => __( 'Subscription notes have been moved for all subscriptions.', 'edd-recurring' ),
		);
	}

	/**
	 * Get the in progress notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_in_progress_notification(): array {
		return array(
			'title'   => __( 'Subscription Upgrade In Progress', 'edd-recurring' ),
			'content' => __( 'Subscription notes are being moved for all subscriptions. This may take a long time to complete depending on the number of subscriptions but, your site will remain fully functional while it is running.', 'edd-recurring' ),
		);
	}

	/**
	 * Get the CLI notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_cli_notification(): array {
		return array();
	}

	/**
	 * Marks the upgrade process as complete.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	protected function mark_complete() {
		parent::mark_complete();

		global $wpdb;
		// Remove the notes column.
		$wpdb->query( "ALTER TABLE {$wpdb->edd_subscriptions} DROP COLUMN notes" );
	}
}
