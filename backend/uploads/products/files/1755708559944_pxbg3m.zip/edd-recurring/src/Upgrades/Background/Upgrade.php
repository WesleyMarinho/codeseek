<?php
/**
 * Base class for background upgrades.
 *
 * @package     EDD\Upgrades\Background
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Upgrades\Background;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\EventManagement\SubscriberInterface;
use EDD\Utils\Date;

/**
 * Base class for upgrades.
 *
 * @since 2.13.0
 */
abstract class Upgrade implements SubscriberInterface, UpgradeInterface {

	/**
	 * The number of database rows which should prevent the upgrade running via the background process.
	 *
	 * @var int
	 */
	protected $warning_count = 25000;

	/**
	 * Whether the upgrade should be silent.
	 *
	 * @var bool
	 */
	protected $is_silent = false;

	/**
	 * The number of items to process per step.
	 *
	 * @var int
	 */
	protected $per_step = 50;

	/**
	 * Hook into actions and filters.
	 *
	 * @since 2.13.0
	 */
	public static function get_subscribed_events() {
		// If the upgrade has already been run, don't hook anything.
		if ( empty( static::get_upgrade_name() ) || edd_has_upgrade_completed( static::get_upgrade_name() ) ) {
			return array();
		}

		// Always hook the migration hook.
		$hooks = array(
			static::get_cron_action() => 'process_step',
		);

		// Always hook the CLI command.
		$hooks['init'] = array( 'maybe_register_cli_command', 99 );

		if ( ! wp_next_scheduled( static::get_cron_action() ) && ! get_option( 'edd_running_cli_upgrade_' . static::get_upgrade_name() ) ) {
			$hooks['shutdown'] = array( 'maybe_schedule_background_update', 99 );
		}

		return $hooks;
	}

	/**
	 * Maybe schedule the background update.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function maybe_schedule_background_update() {
		// If we've already scheduled the cleanup, no need to schedule it again.
		if ( wp_next_scheduled( static::get_cron_action() ) ) {
			return;
		}

		$items = $this->get_items( true );
		if ( empty( $items ) ) {
			$this->mark_complete();
			return;
		}

		// Only update the total count option if it doesn't exist. This prevents it from being overridden in some edge cases.
		$total = get_option( $this->get_total_count_option() );
		if ( empty( $total ) ) {
			// Set the total amount in a transient so we can use it later.
			update_option( $this->get_total_count_option(), $items, false );
			$total = $items;
		}

		$this->add_or_update_initial_notification();

		// If we have a warning count and the total count is greater than or equal to the warning count, don't schedule the next step.
		if ( ! empty( $this->warning_count ) && $total >= $this->warning_count ) {
			return;
		}

		wp_schedule_single_event(
			time() + MINUTE_IN_SECONDS,
			static::get_cron_action()
		);
	}

	/**
	 * Schedules the next event.
	 *
	 * @since 2.13.0
	 * @param int|null $timestamp The timestamp to schedule the event for.
	 * @return void
	 */
	public static function schedule_next_event( $timestamp = null ) {
		if ( null === $timestamp ) {
			$timestamp = time() + MINUTE_IN_SECONDS;
		}

		if ( wp_next_scheduled( static::get_cron_action() ) ) {
			return;
		}

		// If running via the cli, don't schedule the next event.
		if ( get_option( 'edd_running_cli_upgrade_' . static::get_upgrade_name() ) ) {
			return;
		}

		wp_schedule_single_event(
			$timestamp,
			static::get_cron_action()
		);
	}

	/**
	 * Maybe register the CLI command.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function maybe_register_cli_command() {
		if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
			return;
		}

		\WP_CLI::add_command( 'edd upgrade', array( $this, 'do_cli' ) );
	}

	/**
	 * Runs the upgrade via WP-CLI.
	 *
	 * @since 2.13.0
	 *
	 * @param array $args       The arguments passed to the command.
	 * @param array $assoc_args The associative arguments passed to the command.
	 *
	 * @return void
	 */
	public function do_cli( $args, $assoc_args ) {
		if ( ! isset( $args[0] ) || static::get_upgrade_name() !== $args[0] ) {
			\WP_CLI::error( __( 'Invalid upgrade name.', 'edd-recurring' ) );
			return;
		}
		// If the upgrade has already been run, show a message and return.
		if ( edd_has_upgrade_completed( static::get_upgrade_name() ) ) {
			/* translators: %s is the upgrade name */
			\WP_CLI::error( sprintf( __( 'The %s upgrade has already been run.', 'edd-recurring' ), static::get_upgrade_name() ) );
		}

		// Set the max execution time to 0.
		@ini_set('max_execution_time', 0);

		// If the upgrade is already running via CLI, show a message, and confirm if they want to start over.
		if ( get_option( 'edd_running_cli_upgrade_' . static::get_upgrade_name() ) ) {
			\WP_CLI::confirm( __( 'An upgrade was already started via CLI. Would you like to restart it?', 'edd-recurring' ) );
			delete_option( 'edd_running_cli_upgrade_' . static::get_upgrade_name() );
		}

		// If the current upgrade has a scheduled background process, prompt the user to remove it.
		if ( wp_next_scheduled( static::get_cron_action() ) ) {
			// Prompt the user to confirm if they want to cancel the scheduled background process.
			\WP_CLI::confirm( __( 'A background process is already scheduled for this upgrade. Would you like to cancel it and run this upgrade via CLI?', 'edd-recurring' ) );
			wp_unschedule_event( wp_next_scheduled( static::get_cron_action() ), static::get_cron_action() );

			// Set an option to indicate that the upgrade has been run via CLI.
			update_option( 'edd_running_cli_upgrade_' . static::get_upgrade_name(), true, false );
		}

		$total    = $this->get_items( true );
		$progress = new \cli\progress\Bar( 'Processing...', $total );

		while ( $this->get_items( false ) > 0 ) {
			$this->process_step();
			// Update the in-progress notification.
			$this->add_or_update_initial_notification();
			$progress->tick();
		}

		$progress->finish();
		/* translators: %s is the upgrade name */
		\WP_CLI::success( sprintf( __( 'The %s upgrade has been completed.', 'edd-recurring' ), static::get_upgrade_name() ) );

		// Delete the option that indicates that the upgrade has been run via CLI.
		delete_option( 'edd_running_cli_upgrade_' . static::get_upgrade_name() );
	}

	/**
	 * Gets the name of the cron action.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	protected static function get_cron_action(): string {
		return 'edd_' . static::get_upgrade_name();
	}

	/**
	 * Gets the percentage complete.
	 *
	 * @since 2.13.0
	 *
	 * @return int
	 */
	protected function get_percentage_complete() {
		static $percent_complete;

		if ( ! is_null( $percent_complete ) ) {
			return $percent_complete;
		}

		// Get the total amount of rows remaining.
		$total_rows_remaining = $this->get_items( true );

		// Get the total we started with.
		$total_rows_start = get_option( $this->get_total_count_option() );

		// Format a % complete without decimals.
		$percent_complete = absint( number_format( ( ( $total_rows_start - $total_rows_remaining ) / $total_rows_start ) * 100, 0 ) );

		// Just in case we end up over 100%, somehow...make it 100%.
		if ( $percent_complete > 100 ) {
			$percent_complete = 100;
		}

		return $percent_complete;
	}

	/**
	 * Marks the upgrade process as complete.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	protected function mark_complete() {
		// Set the upgrade as complete.
		edd_set_upgrade_complete( static::get_upgrade_name() );

		// Delete the total count option. It may not exist, but we should delete it anyway.
		$had_total = get_option( $this->get_total_count_option() );
		delete_option( $this->get_total_count_option() );

		// If there was no total count, we will not show a notification.
		if ( empty( $had_total ) ) {
			return;
		}

		$initial_notification = $this->get_initial_notification();
		if ( ! empty( $initial_notification ) ) {
			EDD()->notifications->update( $initial_notification->id, array( 'dismissed' => 1 ) );
		}

		if ( $this->is_silent ) {
			return;
		}

		EDD()->notifications->maybe_add_local_notification(
			wp_parse_args(
				$this->get_complete_notification(),
				array(
					'remote_id'  => $this->get_notification_id(),
					'buttons'    => '',
					'conditions' => '',
					'type'       => 'success',
					'title'      => '',
					'content'    => '',
				)
			)
		);
	}

	/**
	 * Adds or updates the initial notification about the migration.
	 *
	 * @since 2.13.0
	 *
	 * @return void
	 */
	protected function add_or_update_initial_notification() {
		if ( $this->is_silent ) {
			return;
		}

		$initial_notification = $this->get_initial_notification();
		$percent_complete     = $this->get_percentage_complete();
		$total_count          = get_option( $this->get_total_count_option(), 0 );
		$notification         = wp_parse_args(
			$this->get_notification_params( $total_count ),
			array(
				'remote_id'  => $this->get_notification_id( true ),
				'buttons'    => '',
				'conditions' => '',
				'type'       => 'info',
				'title'      => '',
				'content'    => '',
			)
		);

		$notification['title'] = $notification['title'] . ' ' . $percent_complete . '%';

		if ( ! empty( $initial_notification ) ) {
			$date = new Date();
			$date->setTimestamp( time() )->setTimezone( new \DateTimeZone( 'UTC' ) );

			// Update the notification.
			EDD()->notifications->update(
				$initial_notification->id,
				array(
					'title'        => $notification['title'],
					'date_created' => $date->format( 'mysql' ),
				)
			);
		} else {
			// Add the notification.
			EDD()->notifications->maybe_add_local_notification( $notification );
		}
	}

	/**
	 * Determines if the step can be processed.
	 *
	 * @since 2.13.0
	 *
	 * @return bool
	 */
	protected function can_process_step() {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return true;
		}

		return edd_doing_cron();
	}

	/**
	 * Get the CLI notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	protected function get_cli_notification(): array {
		return array(
			'title'   => __( 'Database Update Required', 'edd-recurring' ),
			'content' => sprintf(
				/* Translators: %s is the CLI command to run */
				__( 'Easy Digital Downloads needs to update Stripe subscription information in the database, but due to the number of records, you should run this via CLI using <code>%s</code>.', 'edd-recurring' ),
				'wp edd upgrade ' . self::$upgrade_name
			),
		);
	}

	/**
	 * Get the number of items to process per step.
	 *
	 * @since 2.13.0
	 * @return int
	 */
	protected function get_count_per_step() {
		return apply_filters( 'edd_recurring_upgrade_' . static::get_upgrade_name() . '_per_step', $this->per_step );
	}

	/**
	 * Gets the initial notification about the migration.
	 *
	 * @since 2.13.0
	 *
	 * @return object
	 */
	private function get_initial_notification() {
		return EDD()->notifications->get_item_by( 'remote_id', $this->get_notification_id( true ) );
	}

	/**
	 * Gets the notification ID for the migration.
	 *
	 * @since 2.13.0
	 *
	 * @param bool $in_progress Whether to get the in progress or complete notification ID.
	 * @return string
	 */
	private function get_notification_id( $in_progress = false ): string {
		$upgrade_name = substr( md5( static::get_upgrade_name() ), 0, 10 );

		return $in_progress ? $upgrade_name . '-working' : $upgrade_name . '-complete';
	}

	/**
	 * Gets the total count option name.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	private function get_total_count_option(): string {
		return 'edd_' . static::get_upgrade_name() . '_total';
	}

	/**
	 * Gets the notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	private function get_notification_params( $total_count ): array {
		if ( ! empty( $this->warning_count ) && $total_count >= $this->warning_count ) {
			return $this->get_cli_notification();
		}

		return $this->get_in_progress_notification();
	}
}
