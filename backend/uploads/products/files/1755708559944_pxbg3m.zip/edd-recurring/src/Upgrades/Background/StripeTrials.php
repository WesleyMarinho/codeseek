<?php
/**
 * Background upgrade for Stripe trialling subscriptions.
 *
 * @package     EDD\Upgrades\Background
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Upgrades\Background;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * StripeTrials upgrade class.
 *
 * @since 2.13.0
 */
class StripeTrials extends Upgrade {

	/**
	 * The name of the upgrade.
	 *
	 * @since 2.13.0
	 * @var string
	 */
	public static function get_upgrade_name(): string {
		return 'stripe_trials';
	}

	/**
	 * Process the upgrade step.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function process_step(): void {
		if ( ! $this->can_process_step() ) {
			return;
		}

		$items = $this->get_items( false );
		if ( empty( $items ) ) {
			$this->mark_complete();
			return;
		}

		foreach ( $items as $item ) {
			$stripe_subscription = null;
			try {
				$stripe_subscription = edds_api_request( 'Subscription', 'retrieve', $item->profile_id );
			} catch ( \Exception $e ) {
				edd_debug_log( sprintf( 'Error retrieving Stripe subscription %s: %s', $item->profile_id, $e->getMessage() ) );
				continue;
			}

			if ( ! $stripe_subscription ) {
				edd_debug_log( sprintf( 'Stripe subscription %s not found.', $item->profile_id ) );
				continue;
			}

			if ( empty( $stripe_subscription->current_period_end ) ) {
				continue;
			}

			$update_args = array(
				'expiration' => date( 'Y-m-d', $stripe_subscription->current_period_end ) . ' 23:59:59', // phpcs:ignore WordPress.DateTime.RestrictedFunctions
			);

			$item->update( $update_args );
			$item->add_note( __( 'Subscription expiration synced with Stripe.', 'edd-recurring' ) );
		}

		$this->add_or_update_initial_notification();

		// Schedule the next step.
		self::schedule_next_event( time() + MINUTE_IN_SECONDS );
	}

	/**
	 * Get the items to process.
	 *
	 * @since 2.13.0
	 * @param bool $count Whether to return the count of items.
	 * @return array|bool
	 */
	public function get_items( $count = false ) {
		$args = array(
			'gateway' => 'stripe',
			'status'  => 'trialling',
			'orderby' => 'id',
			'order'   => 'ASC',
		);

		$db = new \EDD_Subscriptions_DB();
		if ( $count ) {
			return absint( $db->count( $args ) );
		}

		$step = get_option( self::get_upgrade_name() . '_step', 0 );
		$step = absint( $step );

		$args['number'] = 50;
		$args['offset'] = $step * 50;

		update_option( self::get_upgrade_name() . '_step', ++$step, false );

		return $db->get_subscriptions( $args );
	}

	/**
	 * Get the complete notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_complete_notification(): array {
		return array(
			'title'   => __( 'Subscriptions Check Complete!', 'edd-recurring' ),
			'content' => __( 'Easy Digital Downloads has finished syncing your Stripe subscriptions! Thank you for your patience.', 'edd-recurring' ),
		);
	}

	/**
	 * Get the in progress notification parameters.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_in_progress_notification(): array {
		return array(
			/* translators: %d: Percentage complete */
			'title'   => __( 'Updating Subscriptions ( %d%% )', 'edd-recurring' ),
			'content' => __( 'Easy Digital Downloads is updating your store\'s Stripe subscriptions. We\'ll let you know when the process is complete.', 'edd-recurring' ),
		);
	}

	/**
	 * Mark the upgrade as complete.
	 * Ensures that the step option is deleted.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	protected function mark_complete() {
		parent::mark_complete();
		delete_option( self::get_upgrade_name() . '_step' );
	}
}
