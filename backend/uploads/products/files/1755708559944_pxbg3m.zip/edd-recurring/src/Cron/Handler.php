<?php
/**
 * Cron handler for Recurring.
 *
 * @package     EDD\Recurring\Cron
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Cron;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * The Recurring Reminders Class.
 *
 * @since  2.4
 */
class Handler implements \EDD\EventManagement\SubscriberInterface {

	/**
	 * @var EDD_Subscriptions_DB
	 */
	protected $db;

	/**
	 * Get the subscribers.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'init' => 'init',
		);
	}

	/**
	 * Get the instance of this class.
	 *
	 * @since 2.13.0
	 * @return \EDD\Recurring\Cron\Handler
	 */
	public static function get_instance() {
		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self();
		}

		return $instance;
	}


	/**
	 * Set up our actions and properties.
	 *
	 * @since  2.4
	 */
	public function init() {
		if ( ! wp_next_scheduled( 'edd_recurring_daily_scheduled_events' ) ) {
			wp_schedule_event( time(), 'daily', 'edd_recurring_daily_scheduled_events' );
		}

		add_action( 'edd_recurring_daily_scheduled_events', array( $this, 'check_for_expired_subscriptions' ) );
		add_action( 'edd_recurring_daily_scheduled_events', array( $this, 'check_for_abandoned_subscriptions' ) );

		// Subscription cancellations are scheduled in EDD\Recurring\Subscriptions\Cancel.
		add_action( 'edd_recurring_cancel_subscription', array( $this, 'cancel' ), 10, 2 );
		add_action( 'edd_recurring_daily_scheduled_events', array( $this, 'check_for_missed_cancellations' ) );
	}

	/**
	 * Check for expired subscriptions once per day and mark them as expired.
	 *
	 * @since  2.4
	 */
	public function check_for_expired_subscriptions() {

		$args = array(
			'status'     => array( 'active', 'trialling' ),
			'number'     => 999999,
			'expiration' => array(
				'start' => date( 'Y-n-d 00:00:00', strtotime( '-1 day', current_time( 'timestamp' ) ) ),
				'end'   => date( 'Y-n-d 23:59:59', strtotime( '-1 day', current_time( 'timestamp' ) ) ),
			),
		);

		$subs = $this->get_db()->get_subscriptions( $args );

		if ( ! empty( $subs ) ) {

			foreach ( $subs as $sub ) {
				/*
				 * In the future we can query the merchant processor to confirm the subscription is actually expired
				 *
				 * See https://github.com/easydigitaldownloads/edd-recurring/issues/101
				 * See https://github.com/easydigitaldownloads/edd-recurring/issues/614
				 */

				$sub->expire( true );
			}
		}
	}

	/**
	 * Deletes pending subscription records.
	 *
	 * @since 2.5
	 * @return void
	 */
	public function check_for_abandoned_subscriptions() {

		$args = array(
			'status' => 'pending',
			'number' => 1000,
			'date'   => array(
				'end' => '-1 week',
			),
		);

		$subscriptions = $this->get_db()->get_subscriptions( $args );
		if ( empty( $subscriptions ) ) {
			return;
		}

		foreach ( $subscriptions as $subscription ) {
			$order = edd_get_order( $subscription->parent_payment_id );
			if ( in_array( $order->status, edd_get_complete_order_statuses(), true ) ) {
				$subscription = edd_recurring_get_subscription( $subscription->id );
				$subscription->update(
					array(
						'status' => empty( $subscription->trial_period ) ? 'active' : 'trialling',
					)
				);
				$subscription->add_note( __( 'Subscription was marked as active during daily cron check.', 'edd-recurring' ) );
				continue;
			}

			edd_delete_order_meta( $subscription->parent_payment_id, '_edd_subscription_payment' );
			edd_recurring_trash_subscription( $subscription->id );
			$subscription->add_note( __( 'Subscription was trashed during daily cron check.', 'edd-recurring' ) );
		}
	}

	/**
	 * Cancel a subscription.
	 *
	 * @since 2.13.0
	 * @param int    $subscription_id The subscription ID.
	 * @param string $reason          The reason for the cancellation.
	 * @return void
	 */
	public function cancel( $subscription_id, $reason = '' ) {
		$cancellation_handler = new \EDD\Recurring\Subscriptions\Cancel();
		$cancellation_handler->cancel( $subscription_id, $reason );
	}

	/**
	 * Check for any missed cancellation events and run them.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function check_for_missed_cancellations() {
		$subscriptions = edd_recurring_get_subscriptions(
			array(
				'meta_query' => array(
					array(
						'key'     => 'cancel_by',
						'value'   => time(),
						'compare' => '<',
					),
				),
			)
		);
		if ( empty( $subscriptions ) ) {
			return;
		}

		foreach ( $subscriptions as $subscription ) {
			$cancellation_handler = new \EDD\Recurring\Subscriptions\Cancel();
			$cancellation_handler->cancel( $subscription->id, 'missed cron event' );
		}
	}

	/**
	 * Get the subscriptions DB.
	 *
	 * @since 2.13.0
	 * @return \EDD_Subscriptions_DB
	 */
	private function get_db() {
		if ( ! is_null( $this->db ) ) {
			return $this->db;
		}

		$this->db = new \EDD_Subscriptions_DB();

		return $this->db;
	}
}
