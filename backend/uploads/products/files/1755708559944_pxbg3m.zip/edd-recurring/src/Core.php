<?php
/**
 * Core class for Recurring.
 *
 * @package     EDD\Recurring
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\EventManagement\Subscribers;

/**
 * Core class.
 */
class Core extends Subscribers {

	/**
	 * Get the service providers.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	protected function get_service_providers() {
		$providers = array(
			new Database\Components(),
			new Upgrades\Loader(),
			Cron\Handler::get_instance(),
			new Blocks\Loader(),
			new Gateways\Stripe\Loader(),
			new Subscriptions\Update\Page(),
		);

		foreach ( $this->get_integrations() as $integration ) {
			$provider = $this->get_integration_class( $integration );
			if ( $provider ) {
				$providers[] = new $provider();
			}
		}

		return $providers;
	}

	/**
	 * Get the admin providers.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	protected function get_admin_providers() {
		return array(
			new Admin\Filters(),
			new Admin\Orders\Details(),
			new Admin\Upgrades\Loader(),
			new Admin\Dashboard\Widget(),
		);
	}

	/**
	 * Get the integrations.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	private function get_integrations() {
		return array(
			'SoftwareLicensing',
		);
	}

	/**
	 * Get the integration class.
	 *
	 * @since 2.13.0
	 * @param string $integration The integration.
	 * @return string|bool
	 */
	private function get_integration_class( $integration ) {
		$integration_class = __NAMESPACE__ . '\\Integrations\\' . $integration . '\\Integration';
		if ( ! class_exists( $integration_class ) ) {
			return false;
		}

		if ( ! is_subclass_of( $integration_class, __NAMESPACE__ . '\\Integrations\\Integration' ) ) {
			return false;
		}

		if ( ! $integration_class::is_active() ) {
			return false;
		}

		return $integration_class;
	}
}
