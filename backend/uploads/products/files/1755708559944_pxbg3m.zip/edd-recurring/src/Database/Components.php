<?php
/**
 * Database Components.
 *
 * @package     EDD\Recurring\Database
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Database;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\EventManagement\SubscriberInterface;

/**
 * Database Components.
 *
 * @since 2.13.0
 */
class Components implements SubscriberInterface {

	/**
	 * Returns an array of events that this subscriber wants to listen to.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'edd_setup_components' => 'install',
		);
	}

	/**
	 * Install the database components.
	 *
	 * @since 2.13.0
	 */
	public function install() {
		edd_register_component(
			'subscription',
			array(
				'schema' => '\\EDD\\Recurring\\Database\\Schemas\\Subscriptions',
				'table'  => '\\EDD\\Recurring\\Database\\Tables\\Subscriptions',
				'query'  => '\\EDD\\Recurring\\Database\\Queries\\Subscription',
				'object' => '\\EDD\\Recurring\\Subscriptions\\Subscription',
				'meta'   => '\\EDD\\Recurring\\Database\\Tables\\SubscriptionMeta',
			)
		);
	}
}
