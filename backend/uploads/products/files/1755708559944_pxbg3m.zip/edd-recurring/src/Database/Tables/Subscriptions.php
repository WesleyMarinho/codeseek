<?php
/**
 * Subscriptions Table.
 *
 * @package     EDD\Recurring\Database\Tables
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Database\Tables;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Database\Table;

/**
 * Setup the global "edd_subscriptions" database table.
 *
 * @since 2.13.0
 */
final class Subscriptions extends Table {

	/**
	 * Table name.
	 *
	 * @access protected
	 * @since 2.13.0
	 * @var string
	 */
	protected $name = 'subscriptions';

	/**
	 * Database version.
	 *
	 * @access protected
	 * @since 2.13.0
	 * @var int
	 */
	protected $version = 202504020;

	/**
	 * Array of upgrade versions and methods
	 *
	 * @since 2.13.0
	 *
	 * @var array
	 */
	protected $upgrades = array(
		'202504020' => '202504020',
	);

	/**
	 * Setup the database schema.
	 *
	 * @access protected
	 * @since 2.13.0
	 * @return void
	 */
	protected function set_schema() {
		$this->schema = "
			id bigint(20) NOT NULL AUTO_INCREMENT,
			customer_id bigint(20) NOT NULL,
			period varchar(20) NOT NULL,
			initial_amount mediumtext NOT NULL,
			initial_tax_rate mediumtext NOT NULL,
			initial_tax mediumtext NOT NULL,
			recurring_amount mediumtext NOT NULL,
			recurring_tax_rate mediumtext NOT NULL,
			recurring_tax mediumtext NOT NULL,
			bill_times bigint(20) NOT NULL DEFAULT 0,
			transaction_id varchar(255) NOT NULL COLLATE utf8_bin,
			parent_payment_id bigint(20) NOT NULL,
			product_id bigint(20) NOT NULL,
			price_id bigint(20) DEFAULT NULL,
			created datetime NOT NULL,
			date_modified datetime NOT NULL,
			expiration datetime NOT NULL,
			trial_period varchar(20) NOT NULL,
			status varchar(20) NOT NULL default 'pending',
			profile_id varchar(255) NOT NULL COLLATE utf8_bin,
			gateway varchar(100) NOT NULL default '',
			PRIMARY KEY (id),
			KEY profile_id (profile_id),
			KEY transaction (transaction_id),
			KEY customer (customer_id),
			KEY customer_and_status (customer_id, status),
			KEY product_id_customer_id (product_id, customer_id),
			KEY parent_payment_id_product_id (parent_payment_id, product_id)
		";
	}

	/**
	 * Upgrade to set the `date_modified` column to the current timestamp.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	protected function __202504020() { // phpcs:ignore PHPCompatibility.FunctionNameRestrictions.ReservedFunctionNames.MethodDoubleUnderscore
		if ( $this->column_exists( 'gateway' ) ) {
			return true;
		}

		$success = array();

		// Add the date_modified column after the created column.
		$success['date_modified'] = $this->is_success(
			$this->get_db()->query(
				"ALTER TABLE {$this->table_name} ADD COLUMN `date_modified` datetime NOT NULL default CURRENT_TIMESTAMP after `created`;"
			)
		);

		$success['set_modified'] = $this->is_success(
			$this->get_db()->query(
				"UPDATE {$this->table_name} SET date_modified = created;"
			)
		);

		$success['gateway'] = $this->is_success(
			$this->get_db()->query(
				"ALTER TABLE {$this->table_name} ADD COLUMN `gateway` varchar(100) NOT NULL default '' AFTER `profile_id`;"
			)
		);

		// Delete the old version options.
		delete_option( $this->table_prefix . 'edd_subscriptions_db_version' );
		delete_option( 'wp_edd_subscriptions_db_version' );

		return $this->is_success( ! in_array( false, $success ) );
	}
}
