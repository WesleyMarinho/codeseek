<?php
/**
 * Subscription Meta Table.
 *
 * @package     EDD\Recurring\Database\Tables
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Database\Tables;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use EDD\Database\Table;

/**
 * Setup the global "subscriptionmeta" database table.
 *
 * @since 2.13.0
 */
final class SubscriptionMeta extends Table {

	/**
	 * Table name
	 *
	 * @access protected
	 * @since 2.13.0
	 * @var string
	 */
	protected $name = 'subscriptionmeta';

	/**
	 * Database version
	 *
	 * @access protected
	 * @since 2.13.0
	 * @var int
	 */
	protected $version = 202503310;

	/**
	 * Setup the database schema
	 *
	 * @access protected
	 * @since 2.13.0
	 * @return void
	 */
	protected function set_schema() {
		$max_index_length = 191;
		$this->schema     = "meta_id bigint(20) unsigned NOT NULL auto_increment,
			edd_subscription_id bigint(20) unsigned NOT NULL default '0',
			meta_key varchar(255) DEFAULT NULL,
			meta_value longtext DEFAULT NULL,
			PRIMARY KEY (meta_id),
			KEY edd_subscription_id (edd_subscription_id),
			KEY meta_key (meta_key({$max_index_length}))";
	}
}
