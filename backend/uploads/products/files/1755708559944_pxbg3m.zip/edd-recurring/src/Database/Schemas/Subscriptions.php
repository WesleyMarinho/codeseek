<?php
/**
 * Subscriptions Schema Class.
 *
 * @package     EDD\Recurring\Database\Schemas
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Database\Schemas;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Database\Schema;

/**
 * Subscriptions Schema Class.
 *
 * @since 2.13.0
 */
class Subscriptions extends Schema {

	/**
	 * Array of database column objects
	 *
	 * @since 2.13.0
	 * @access public
	 * @var array
	 */
	public $columns = array(

		array(
			'name'     => 'id',
			'type'     => 'bigint',
			'length'   => 20,
			'unsigned' => true,
			'extra'    => 'auto_increment',
			'primary'  => true,
			'sortable' => true,
		),
		array(
			'name'      => 'customer_id',
			'type'      => 'bigint',
			'length'    => 20,
			'unsigned'  => true,
			'default'   => 0,
			'cache_key' => true,
		),
		array(
			'name'       => 'period',
			'type'       => 'varchar',
			'length'     => 20,
			'searchable' => true,
			'sortable'   => true,
		),
		array(
			'name' => 'initial_amount',
			'type' => 'mediumtext',
		),
		array(
			'name'    => 'initial_tax_rate',
			'type'    => 'mediumtext',
			'default' => 0,
		),
		array(
			'name'    => 'initial_tax',
			'type'    => 'mediumtext',
			'default' => 0,
		),
		array(
			'name' => 'recurring_amount',
			'type' => 'mediumtext',
		),
		array(
			'name'    => 'recurring_tax_rate',
			'type'    => 'mediumtext',
			'default' => 0,
		),
		array(
			'name'    => 'recurring_tax',
			'type'    => 'mediumtext',
			'default' => 0,
		),
		array(
			'name'       => 'bill_times',
			'type'       => 'bigint',
			'length'     => 20,
			'allow_null' => false,
			'default'    => 0,
		),
		array(
			'name'       => 'transaction_id',
			'type'       => 'varchar',
			'length'     => 255,
			'allow_null' => false,
		),
		array(
			'name'       => 'parent_payment_id',
			'type'       => 'bigint',
			'length'     => 20,
			'allow_null' => false,
		),
		array(
			'name'       => 'product_id',
			'type'       => 'bigint',
			'length'     => 20,
			'allow_null' => false,
		),
		array(
			'name'       => 'price_id',
			'type'       => 'bigint',
			'length'     => 20,
			'default'    => null,
			'allow_null' => true,
		),
		array(
			'name'       => 'created',
			'type'       => 'datetime',
			'default'    => '', // Defaults to current time in query class.
			'created'    => true,
			'date_query' => true,
			'sortable'   => true,
		),
		array(
			'name'       => 'expiration',
			'type'       => 'datetime',
			'default'    => '', // Defaults to current time in query class.
			'date_query' => true,
			'sortable'   => true,
		),
		array(
			'name'   => 'trial_period',
			'type'   => 'varchar',
			'length' => 20,
		),
		array(
			'name'       => 'status',
			'type'       => 'varchar',
			'length'     => 20,
			'searchable' => true,
			'sortable'   => true,
		),
		array(
			'name'       => 'profile_id',
			'type'       => 'varchar',
			'length'     => 255,
			'searchable' => true,
			'sortable'   => true,
		),
		array(
			'name'       => 'gateway',
			'type'       => 'varchar',
			'length'     => 100,
			'default'    => '',
			'allow_null' => false,
		),
		array(
			'name'     => 'date_modified',
			'type'     => 'datetime',
			'default'  => '',
			'modified' => true,
		),
	);
}
