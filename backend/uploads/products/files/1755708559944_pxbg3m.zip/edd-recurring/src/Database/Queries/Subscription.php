<?php
/**
 * Subscription Query Class.
 *
 * @package     EDD\Recurring\Database\Queries
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Database\Queries;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Database\Query;

/**
 * Class used for querying items.
 *
 * @since 2.13.0
 * @see \EDD\Database\Queries\Query::__construct() for accepted arguments.
 */
class Subscription extends Query {

	/** Table Properties ******************************************************/

	/**
	 * Name of the database table to query.
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $table_name = 'subscriptions';

	/**
	 * String used to alias the database table in MySQL statement.
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $table_alias = 'subs';

	/**
	 * Name of class used to setup the database schema
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $table_schema = '\\EDD\\Recurring\\Database\\Schemas\\Subscriptions';

	/** Item ******************************************************************/

	/**
	 * Name for a single item
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $item_name = 'subscription';

	/**
	 * Plural version for a group of items.
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $item_name_plural = 'subscriptions';

	/**
	 * Callback function for turning IDs into objects
	 *
	 * @since 2.13.0
	 * @access public
	 * @var mixed
	 */
	protected $item_shape = '\\EDD\\Recurring\\Subscriptions\\Subscription';

	/** Cache *****************************************************************/

	/**
	 * Group to cache queries and queried items in.
	 *
	 * @since 2.13.0
	 * @access public
	 * @var string
	 */
	protected $cache_group = 'edd_subscriptions';
}
