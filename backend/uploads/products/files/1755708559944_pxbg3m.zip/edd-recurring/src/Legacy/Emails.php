<?php
/**
 * EDD Recurring Emails
 *
 * @package EDD Recurring
 */

namespace EDD\Recurring\Legacy;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * The Recurring Emails Class
 * This class will be formally deprecated when the minimum EDD version supports email management.
 *
 * @since  2.4
 */
class Emails {

	/**
	 * The subscription object.
	 *
	 * @var EDD_Subscription
	 */
	public $subscription;

	/**
	 * EDD_Recurring_Emails constructor.
	 */
	public function __construct() {
		if ( edd_recurring_are_email_templates_registered() ) {
			return;
		}
		$this->init();
	}

	/**
	 * Initializes the class.
	 *
	 * @return void
	 */
	public function init() {
		if ( edd_get_option( 'enable_payment_received_email' ) ) {
			add_action( 'edd_subscription_post_renew', array( $this, 'send_payment_received' ), 10, 4 );
		}

		if ( edd_get_option( 'enable_payment_failed_email' ) ) {
			add_action( 'edd_recurring_payment_failed', array( $this, 'send_payment_failed' ), 10 );
		}

		if ( edd_get_option( 'enable_subscription_cancelled_email' ) ) {
			add_action( 'edd_subscription_cancelled', array( $this, 'send_subscription_cancelled' ), 10, 2 );
		}

		if ( edd_get_option( 'enable_subscription_cancelled_admin_email' ) ) {
			add_action( 'edd_subscription_cancelled', array( $this, 'send_subscription_cancelled_admin' ), 10, 2 );
		}
	}

	/**
	 * Sends an email when a subscription payment is received.
	 *
	 * @param int               $subscription_id The subscription ID.
	 * @param int               $expiration      The expiration date.
	 * @param \EDD_Subscription $subscription    The subscription object.
	 * @param int               $payment_id      The renewal payment ID.
	 * @return void
	 */
	public function send_payment_received( $subscription_id, $expiration, \EDD_Subscription $subscription, $payment_id = 0 ) {

		// Since it's possible to renew a subscription without a payment, we should not send an email if none is specified.
		if ( empty( $payment_id ) ) {
			return;
		}

		if ( ! $this->can_send_subscription_email( $subscription ) ) {
			return;
		}

		$this->subscription = $subscription;

		$order   = edd_get_order( $payment_id );

		/**
		 * Filters the subject of the payment received email.
		 *
		 * @param string $subject The email subject.
		 */
		$subject = apply_filters( 'edd_recurring_payment_received_subject', edd_get_option( 'payment_received_subject' ) );
		$subject = $this->payment_received_template_tags( $subject, $order->total );
		$subject = edd_do_email_tags( $subject, $payment_id );

		/**
		 * Filters the message of the payment received email.
		 *
		 * @param string $message The email message.
		 */
		$message = apply_filters( 'edd_recurring_payment_received_message', edd_get_option( 'payment_received_message' ) );
		$message = $this->payment_received_template_tags( $message, $order->total );
		$message = edd_do_email_tags( $message, $payment_id );

		EDD()->emails->send( $this->subscription->customer->email, $subject, $message );
	}

	/**
	 * Sends an email when a subscription payment fails.
	 *
	 * @param \EDD_Subscription $subscription The subscription object.
	 * @return void
	 */
	public function send_payment_failed( \EDD_Subscription $subscription ) {

		if ( ! $this->can_send_subscription_email( $subscription ) ) {
			return;
		}
		$this->subscription = $subscription;

		/**
		 * Filters the subject of the payment failed email.
		 *
		 * @param string $subject The email subject.
		 */
		$subject = apply_filters( 'edd_recurring_payment_failed_subject', edd_get_option( 'payment_failed_subject' ) );
		$subject = $this->payment_received_template_tags( $subject, $this->subscription->recurring_amount );

		/**
		 * Filters the message of the payment failed email.
		 *
		 * @param string $message The email message.
		 */
		$message = apply_filters( 'edd_recurring_payment_failed_message', edd_get_option( 'payment_failed_message' ) );
		$message = $this->payment_received_template_tags( $message, $this->subscription->recurring_amount );

		EDD()->emails->send( $this->subscription->customer->email, $subject, $message );
	}

	/**
	 * Sends an email to the customer when a subscription is cancelled.
	 *
	 * @param int               $subscription_id The subscription ID.
	 * @param \EDD_Subscription $subscription    The subscription object.
	 * @return void
	 */
	public function send_subscription_cancelled( $subscription_id, \EDD_Subscription $subscription ) {

		if ( ! $this->can_send_subscription_email( $subscription ) ) {
			return;
		}

		$this->subscription = $subscription;

		/**
		 * Filters the subject of the subscription cancelled email.
		 *
		 * @param string $subject The email subject.
		 */
		$subject = apply_filters( 'edd_recurring_subscription_cancelled_subject', edd_get_option( 'subscription_cancelled_subject' ) );
		$subject = $this->filter_reminder_template_tags( $subject, $subscription_id );

		/**
		 * Filters the message of the subscription cancelled email.
		 *
		 * @param string $message The email message.
		 */
		$message = apply_filters( 'edd_recurring_subscription_cancelled_message', edd_get_option( 'subscription_cancelled_message' ) );
		$message = $this->filter_reminder_template_tags( $message, $subscription_id );

		EDD()->emails->send( $this->subscription->customer->email, $subject, $message );
	}

	/**
	 * Sends an email to the admin when a subscription is cancelled.
	 *
	 * @param int              $subscription_id The subscription ID.
	 * @param \EDD_Subscription $subscription    The subscription object.
	 * @return void
	 */
	public function send_subscription_cancelled_admin( $subscription_id, \EDD_Subscription $subscription ) {

		$this->subscription = $subscription;

		$email_to = edd_get_admin_notice_emails();

		/**
		 * Filters the subject of the subscription cancelled email sent to the admin.
		 *
		 * @param string $subject The email subject.
		 */
		$subject = apply_filters( 'edd_recurring_subscription_cancelled_subject', edd_get_option( 'subscription_cancelled_admin_subject' ) );
		$subject = $this->filter_reminder_template_tags( $subject, $subscription_id );

		/**
		 * Filters the message of the subscription cancelled email sent to the admin.
		 *
		 * @param string $message The email message.
		 */
		$message = apply_filters( 'edd_recurring_subscription_cancelled_message', edd_get_option( 'subscription_cancelled_admin_message' ) );
		$message = $this->filter_reminder_template_tags( $message, $subscription_id );

		EDD()->emails->send( $email_to, $subject, $message );
	}

	/**
	 * Sends a reminder email to a customer.
	 *
	 * @param int $subscription_id The subscription ID.
	 * @param int $notice_id       The notice ID.
	 * @return bool
	 */
	public function send_reminder( $subscription_id = 0, $notice_id = 0 ) {
		if ( empty( $subscription_id ) ) {
			return false;
		}
		$subscription = edd_recurring_get_subscription( $subscription_id );
		if ( ! $subscription ) {
			return false;
		}

		$this->subscription = $subscription;
		if ( ! $this->can_send_subscription_email( $this->subscription ) ) {
			return false;
		}

		$notices = edd_recurring()::$reminders;
		$send    = apply_filters( 'edd_recurring_send_reminder', true, $subscription_id, $notice_id );

		if ( ! $send ) {
			return false;
		}

		$email_to = $this->subscription->customer->email;
		$notice   = $notices->get_notice( $notice_id );
		$message  = ! empty( $notice['message'] ) ? $notice['message'] : __( "Hello {name},\n\nYour subscription for {subscription_name} will renew or expire on {expiration}.", 'edd-recurring' );
		$message  = $this->filter_reminder_template_tags( $message, $subscription_id );

		$subject = ! empty( $notice['subject'] ) ? $notice['subject'] : __( 'Your Subscription is About to Renew or Expire', 'edd-recurring' );
		$subject = $this->filter_reminder_template_tags( $subject, $subscription_id );

		$sent = EDD()->emails->send( $email_to, $subject, $message );

		$log_id = wp_insert_post(
			array(
				'post_title'  => __( 'LOG - Subscription Reminder Notice Sent', 'edd-recurring' ),
				'post_name'   => 'log-subscription-reminder-notice-' . $subscription_id . '_sent-' . $this->subscription->customer_id . '-' . md5( time() ),
				'post_type'   => 'edd_subscription_log',
				'post_status' => 'publish',
			)
		);

		add_post_meta( $log_id, '_edd_recurring_log_customer_id', $this->subscription->customer_id );
		add_post_meta( $log_id, '_edd_recurring_log_subscription_id', $subscription_id );
		add_post_meta( $log_id, '_edd_recurring_reminder_notice_id', (int) $notice_id );

		if ( isset( $notice['type'] ) ) {
			add_post_meta( $log_id, '_edd_recurring_reminder_notice_type', $notice['type'] );
		}

		wp_set_object_terms( $log_id, 'subscription_reminder_notice', 'edd_log_type', false );

		if ( ! empty( $this->subscription->customer->user_id ) ) {

			// Prevents reminder notices from being sent more than once.
			add_user_meta( $this->subscription->customer->user_id, sanitize_key( '_edd_recurring_reminder_sent_' . $subscription_id . '_' . $notice_id . '_' . $this->subscription->get_total_payments() ), time() );
		}

		return $sent;
	}

	/**
	 * Replaces template tags in a reminder email.
	 *
	 * @param string $text            The text to be parsed (subject or message).
	 * @param int    $subscription_id The subscription ID.
	 * @return string
	 */
	public function filter_reminder_template_tags( $text = '', $subscription_id = 0 ) {
		$download      = edd_get_download( $this->subscription->product_id );
		$customer_name = $this->subscription->customer->name;
		$expiration    = strtotime( $this->subscription->expiration );

		$text = str_replace( '{name}', $customer_name, $text );

		// Make sure a valid download object was found before attempting to use its methods.
		if ( $download instanceof \EDD_Download ) {
			$text = str_replace( '{subscription_name}', $download->get_name(), $text );
		}

		$text = str_replace( '{expiration}', date_i18n( get_option( 'date_format' ), $expiration ), $text );
		$text = str_replace( '{amount}', edd_currency_filter( edd_format_amount( $this->subscription->recurring_amount ), edd_get_payment_currency_code( $this->subscription->parent_payment_id ) ), $text );
		$text = str_replace( '{subscription_id}', absint( $this->subscription->id ), $text );
		$text = str_replace( '{subscription_period}', esc_html( __( $this->subscription->period, 'edd-recurring' ) ), $text );
		$text = str_replace(
			'{subscription_details}',
			edd_recurring_get_subscription_billing_text(
				array(
					'period' => $this->subscription->period,
					'times'  => $this->subscription->bill_times,
				)
			),
			$text
		);
		$url  = edd_get_admin_url(
			array(
				'page' => 'edd-subscriptions',
				'id'   => $subscription_id,
			)
		);
		$text = str_replace( '{subscription_link}', $url, $text );

		/**
		 * Filters the reminder email template tags.
		 *
		 * @param string $text            The text to be parsed (subject or message).
		 * @param int    $subscription_id The subscription ID.
		 */
		return apply_filters( 'edd_recurring_filter_reminder_template_tags', $text, $subscription_id );
	}

	/**
	 * Replaces template tags in a payment received email.
	 *
	 * @param string $text   The text to be parsed (subject or message).
	 * @param string $amount The payment amount.
	 * @return string
	 */
	public function payment_received_template_tags( $text = '', $amount = '' ) {
		$download      = edd_get_download( $this->subscription->product_id );
		$customer_name = $this->subscription->customer->name;
		$expiration    = strtotime( $this->subscription->expiration );

		$text = str_replace( '{name}', $customer_name, $text );

		// Make sure a valid download object was found before attempting to use its methods.
		if ( $download instanceof \EDD_Download ) {
			$text = str_replace( '{subscription_name}', $download->get_name(), $text );
		}

		$text = str_replace( '{expiration}', date_i18n( get_option( 'date_format' ), $expiration ), $text );
		$text = str_replace( '{amount}', edd_currency_filter( edd_format_amount( $amount ), edd_get_payment_currency_code( $this->subscription->parent_payment_id ) ), $text );
		$text = str_replace( '{subscription_id}', absint( $this->subscription->id ), $text );
		$text = str_replace( '{subscription_period}', esc_html( __( $this->subscription->period, 'edd-recurring' ) ), $text );
		$text = str_replace(
			'{subscription_details}',
			edd_recurring_get_subscription_billing_text(
				array(
					'period' => $this->subscription->period,
					'times'  => $this->subscription->bill_times,
				)
			),
			$text
		);

		/**
		 * Filters the payment received email template tags.
		 *
		 * @param string $text   The text to be parsed (subject or message).
		 * @param string $amount The payment amount.
		 * @param int    $subscription_id The subscription ID.
		 */
		return apply_filters( 'edd_recurring_payment_received_template_tags', $text, $amount, $this->subscription->id );
	}

	/**
	 * Whether a subscription email can be sent based on customer data.
	 *
	 * @param \EDD_Subscription $subscription
	 * @return bool
	 */
	private function can_send_subscription_email( \EDD_Subscription $subscription ) {

		// If there isn't a valid email address, don't send the email.
		if ( empty( $subscription->customer->email ) ) {
			return false;
		}

		// If the customer is not active, don't send the email.
		if ( empty( $subscription->customer->status ) || 'active' !== $subscription->customer->status ) {
			return false;
		}

		// If the customer is not a user, don't send the email. Recurring payments are only supported for users.
		if ( empty( $subscription->customer->user_id ) ) {
			return false;
		}

		return true;
	}
}
