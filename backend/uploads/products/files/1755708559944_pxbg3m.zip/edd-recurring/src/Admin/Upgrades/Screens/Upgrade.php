<?php
/**
 * Represents an abstract class for upgrades.
 *
 * This class serves as a base class for implementing upgrade routines in the EDD - Recurring plugin.
 * It provides common functionality and structure for performing upgrades in the WordPress environment.
 *
 * @package     EDD\Recurring\Admin\Upgrades\Screens
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Upgrades\Screens;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class Upgrade
 *
 * @since 2.13.0
 */
abstract class Upgrade {

	/**
	 * The type of notice to display. This will be used as part of the CSS class.
	 *
	 * @since 2.13.0
	 * @var string
	 */
	protected $type = 'warning';

	/**
	 * Upgrade constructor.
	 */
	public function __construct() {
		if ( empty( $this->get_id() ) ) {
			return;
		}

		add_action( 'admin_notices', array( $this, 'show_notice' ) );
		add_action( "edd_admin_upgrades_render_{$this->get_id()}", array( $this, 'validate' ) );
		add_action( 'edd_download_batch_export', array( $this, 'modify_request' ), -100 );
		add_filter( 'edd_settings_page_title', array( $this, 'update_title' ), 10, 2 );
	}

	/**
	 * Gets the ID of the upgrade.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	abstract protected function get_id(): string;

	/**
	 * Gets the message for the admin notice.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	abstract protected function get_admin_message(): string;

	/**
	 * Gets the message for the upgrade notice.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	abstract protected function get_update_message(): string;

	/**
	 * Gets the export class.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	abstract protected function get_export_class(): string;

	/**
	 * Whether the upgrade is needed.
	 *
	 * @return boolean
	 */
	abstract protected function needs_upgrade(): bool;

	/**
	 * Public function to begin rendering the upgrade form.
	 * All this does is verify the nonce and then call the render() method.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	final public function validate( $nonce ) {
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, "edd-upgrade-{$this->get_id()}" ) ) {
			$this->completed_notice();
			return;
		}

		$this->render();
	}

	/**
	 * This is really hacky, but important until EDD core better supports namespaced classes.
	 * During the download, `EDD\Admin\Export` gets converted to:
	 * `EDD\\\\Admin\\\\Export` . This breaks the `class_exists()`
	 * check in EDD core ( @see edd_process_batch_export_download() ). Therefore, we hook in before
	 * that runs to strip slashes, which makes everything work again. Dumb, but temporarily necessary.
	 *
	 * @link https://github.com/awesomemotive/easy-digital-downloads-pro/issues/1150
	 * @since 2.13.0
	 */
	public function modify_request() {
		if ( ! isset( $_REQUEST['class'] ) ) {
			return;
		}
		$class = $this->get_export_class();
		if ( stripslashes( $_REQUEST['class'] ) === $class ) {
			$_REQUEST['class'] = $class;
		}
	}

	/**
	 * Updates the title of the page.
	 *
	 * @since 2.13.0
	 * @param string $page_title The current page title.
	 * @param string $current_page The current page slug.
	 * @return string
	 */
	public function update_title( $page_title, $current_page ) {
		if ( self::get_upgrade_slug() === $current_page ) {
			return __( 'Upgrades', 'edd-recurring' );
		}

		return $page_title;
	}

	/**
	 * Actually renders the upgrade form.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	protected function render() {
		if ( edd_has_upgrade_completed( $this->get_id() ) ) {
			$this->completed_notice();
			return;
		}

		?>
		<div id="edd-migration-nav-warn" class="notice edd-notice notice-info">
			<p>
				<?php _e( '<strong>Important:</strong> Please leave this screen open and do not navigate away until the process completes.', 'edd-recurring' ); ?>
			</p>
		</div>

		<div class="metabox-holder">
			<div class="postbox">
				<h2 class="hndle">
					<span><?php esc_html_e( 'Update Subscription Records', 'edd-recurring' ); ?></span>
				</h2>
				<div class="inside update-subscription-records-control">
					<p>
					<?php echo wp_kses_post( $this->get_update_message() ); ?>
					</p>
					<form method="post" id="edd-<?php echo esc_attr( $this->get_id() ); ?>-form" class="edd-export-form edd-import-export-form">
						<span class="step-instructions-wrapper">

							<?php wp_nonce_field( 'edd_ajax_export', 'edd_ajax_export' ); ?>

							<?php if ( ! $this->is_complete() ) : ?>
								<span class="edd-migration allowed">
									<input type="submit" id="<?php echo esc_attr( $this->get_id() ); ?>-submit" value="<?php esc_html_e( 'Update Subscriptions', 'edd-recurring' ); ?>" class="button button-primary"/>
								</span>
							<?php else : ?>
								<input type="submit" disabled id="<?php echo esc_attr( $this->get_id() ); ?>-submit" value="<?php esc_html_e( 'Subscription Update Complete', 'edd-recurring' ); ?>" class="button button-secondary"/>
							<?php endif; ?>

							<input type="hidden" name="edd-export-class" value="<?php echo esc_attr( $this->get_export_class() ); ?>" />
						</span>
					</form>
				</div><!-- .inside -->
			</div><!-- .postbox -->
		</div>
		<p class="edd-upgrade__action" style="display: none;">
			<a href="<?php echo esc_url( admin_url() ); ?>" class="button button-primary"><?php esc_html_e( 'Return to the dashboard', 'edd-recurring' ); ?></a>
		</p>
		<?php
		wp_enqueue_script( 'edd-recurring-upgrade', EDD_RECURRING_PLUGIN_URL . 'assets/js/upgrade.js', array( 'edd-admin-upgrades' ), EDD_RECURRING_VERSION, true );
	}

	/**
	 * Check if the upgrade is complete.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	protected function is_complete() {
		return edd_has_upgrade_completed( $this->get_id() );
	}

	/**
	 * Sets an upgrade as completed.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	protected function mark_complete() {
		return edd_set_upgrade_complete( $this->get_id() );
	}

	/**
	 * Prints the admin notice for the upgrade.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function show_notice() {
		if ( ! $this->can_show_notice() ) {
			return;
		}

		$message = $this->get_admin_message();
		if ( empty( $message ) ) {
			return;
		}

		?>
		<div class="notice edd-notice notice-<?php echo esc_attr( $this->type ); ?>">
		<?php
		echo wp_kses_post( wpautop( $message ) );
		printf(
			'<p><a href="%s" class="button button-primary">%s</a></p>',
			esc_url(
				add_query_arg(
					array(
						'page'        => self::get_upgrade_slug(),
						'edd-upgrade' => $this->get_id(),
						'_wpnonce'    => wp_create_nonce( "edd-upgrade-{$this->get_id()}" ),
					),
					admin_url( 'admin.php' )
				)
			),
			esc_html( $this->get_admin_notice_button_text() )
		);
		?>
		</div>
		<?php
	}

	/**
	 * Gets the upgrade slug.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	public static function get_upgrade_slug() {
		if ( class_exists( '\\EDD\Admin\\Upgrades\\Screen' ) ) {
			return 'edd-upgrades';
		}

		return 'edd-recurring-upgrades';
	}

	/**
	 * Method to determine if the upgrade can run.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	protected function can_upgrade() {
		if ( ! current_user_can( 'manage_shop_settings' ) ) {
			return false;
		}

		return wp_verify_nonce( $_GET['_wpnonce'], 'edd-upgrade' );
	}

	/**
	 * Whether the notice can be displayed.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	protected function can_show_notice() {
		if ( $this->is_complete() ) {
			return false;
		}

		$page = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( self::get_upgrade_slug() === $page ) {
			return false;
		}

		if ( ! $this->needs_upgrade() ) {
			$this->mark_complete();
			return false;
		}

		return \current_user_can( 'manage_shop_settings' );
	}

	/**
	 * Shows the completed notice.
	 *
	 * @param string $message Optional. The message to display.
	 * @return void
	 */
	protected function completed_notice( $message = '' ) {
		?>
		<div id="edd-migration-ready" class="notice edd-notice notice-success">
			<h2>
				<?php esc_html_e( 'Database Upgrade Complete', 'edd-recurring' ); ?>
			</h2>
			<?php
			if ( empty( $message ) ) {
				$message = __( 'All database upgrades have been completed.', 'edd-recurring' );
			}
			echo wp_kses_post( wpautop( $message ) );
			?>
		</div>

		<p>
			<a href="<?php echo esc_url( admin_url() ); ?>" class="button button-primary"><?php esc_html_e( 'Return to the dashboard', 'edd-recurring' ); ?></a>
		</p>
		<?php
	}

	/**
	 * Gets the admin notice button text.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	protected function get_admin_notice_button_text(): string {
		return __( 'Run Upgrade', 'edd-recurring' );
	}
}
