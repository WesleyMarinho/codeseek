<?php
/**
 * Recurring Revenue Report
 *
 * @package EDD\Recurring\Admin\Reports
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Reports;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Recurring Revenue Report
 *
 * @since 2.13.0
 */
class RecurringRevenue {
	/**
	 * Get the Monthly Recurring Revenue (MRR).
	 *
	 * @since 2.13.0
	 * @return float
	 */
	public static function get_mrr() {
		$mrr = get_transient( 'edd_recurring_mrr' );
		if ( false !== $mrr ) {
			return $mrr;
		}

		global $wpdb;

		$now = ( new \EDD\Utils\Date() )->format( 'mysql' );
		$mrr = (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT
					SUM(
						CASE
							-- For unlimited subscriptions (bill_times = 0), use full recurring amount
							WHEN s.bill_times = 0 THEN
								CASE
									WHEN s.period = 'day' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 30.4375
									WHEN s.period = 'week' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 4.34812
									WHEN s.period = 'month' THEN (s.recurring_amount / COALESCE(o.rate, 1))
									WHEN s.period = 'quarter' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 3
									WHEN s.period = 'semi-year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 6
									WHEN s.period = 'year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 12
									ELSE 0
								END
							-- For limited subscriptions (bill_times > 0), calculate remaining payments and prorate
							WHEN s.bill_times > 0 THEN
								CASE
									-- Calculate remaining payments: bill_times - times_billed (including original if no trial)
									WHEN s.bill_times > (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END) THEN
										CASE
											WHEN s.period = 'day' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 30.4375 *
												LEAST(12, s.bill_times - (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END)) / 12
											WHEN s.period = 'week' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 4.34812 *
												LEAST(12, s.bill_times - (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END)) / 12
											WHEN s.period = 'month' THEN (s.recurring_amount / COALESCE(o.rate, 1)) *
												LEAST(12, s.bill_times - (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END)) / 12
											WHEN s.period = 'quarter' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 3 *
												LEAST(4, s.bill_times - (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END)) / 4
											WHEN s.period = 'semi-year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 6 *
												LEAST(2, s.bill_times - (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END)) / 2
											WHEN s.period = 'year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) / 12 *
												LEAST(1, s.bill_times - (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END))
											ELSE 0
										END
									ELSE 0
								END
							ELSE 0
						END
					) AS monthly_recurring_revenue
				FROM {$wpdb->prefix}edd_subscriptions s
				LEFT JOIN {$wpdb->prefix}edd_orders o ON s.parent_payment_id = o.id
				LEFT JOIN (
					SELECT
						om.meta_value AS subscription_id,
						COUNT(r.id) AS renewal_count
					FROM {$wpdb->prefix}edd_orders r
					INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id AND om.meta_key = 'subscription_id'
					WHERE r.status IN ('complete', 'edd_subscription')
					AND r.type = 'sale'
					GROUP BY om.meta_value
				) renewal_counts ON s.id = renewal_counts.subscription_id
				WHERE
					s.expiration > %s
					AND s.status = 'active'",
				$now
			)
		);

		set_transient( 'edd_recurring_mrr', $mrr, HOUR_IN_SECONDS );

		return $mrr;
	}

	/**
	 * Get the Annual Recurring Revenue (ARR).
	 *
	 * @since 2.13.0
	 * @return float
	 */
	public static function get_arr() {
		$arr = get_transient( 'edd_recurring_arr' );
		if ( false !== $arr ) {
			return $arr;
		}

		global $wpdb;

		$now = ( new \EDD\Utils\Date() )->format( 'mysql' );
		$arr = (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT
					SUM(
						CASE
							-- For unlimited subscriptions (bill_times = 0), use full recurring amount
							WHEN s.bill_times = 0 THEN
								CASE
									WHEN s.period = 'day' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 365.25
									WHEN s.period = 'week' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 52.17857
									WHEN s.period = 'month' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 12
									WHEN s.period = 'quarter' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 4
									WHEN s.period = 'semi-year' THEN (s.recurring_amount / COALESCE(o.rate, 1)) * 2
									WHEN s.period = 'year' THEN (s.recurring_amount / COALESCE(o.rate, 1))
									ELSE 0
								END
							-- For limited subscriptions (bill_times > 0), calculate remaining payments and prorate
							WHEN s.bill_times > 0 THEN
								CASE
									-- Calculate remaining payments: bill_times - times_billed (including original if no trial)
									WHEN s.bill_times > (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END) THEN
										(s.recurring_amount / COALESCE(o.rate, 1)) *
										(s.bill_times - (COALESCE(renewal_counts.renewal_count, 0) + CASE WHEN s.trial_period IS NULL OR s.trial_period = '' THEN 1 ELSE 0 END)) *
										CASE
											WHEN s.period = 'day' THEN 365.25
											WHEN s.period = 'week' THEN 52.17857
											WHEN s.period = 'month' THEN 12
											WHEN s.period = 'quarter' THEN 4
											WHEN s.period = 'semi-year' THEN 2
											WHEN s.period = 'year' THEN 1
											ELSE 0
										END
									ELSE 0
								END
							ELSE 0
						END
					) AS annual_recurring_revenue
				FROM {$wpdb->prefix}edd_subscriptions s
				LEFT JOIN {$wpdb->prefix}edd_orders o ON s.parent_payment_id = o.id
				LEFT JOIN (
					SELECT
						om.meta_value AS subscription_id,
						COUNT(r.id) AS renewal_count
					FROM {$wpdb->prefix}edd_orders r
					INNER JOIN {$wpdb->prefix}edd_ordermeta om ON r.id = om.edd_order_id AND om.meta_key = 'subscription_id'
					WHERE r.status IN ('complete', 'edd_subscription')
					AND r.type = 'sale'
					GROUP BY om.meta_value
				) renewal_counts ON s.id = renewal_counts.subscription_id
				WHERE
					( s.expiration IS NULL OR s.expiration > %s )
					AND s.status = 'active'",
				$now
			)
		);

		set_transient( 'edd_recurring_arr', $arr, HOUR_IN_SECONDS );

		return $arr;
	}
}
