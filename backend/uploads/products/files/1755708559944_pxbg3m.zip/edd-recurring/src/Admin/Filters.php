<?php
/**
 * Filters class.
 *
 * @package     EDD\Recurring\Admin
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.12.1
 */

namespace EDD\Recurring\Admin;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use EDD\EventManagement\SubscriberInterface;

/**
 * Class Filters
 *
 * @package EDD\Recurring\Admin
 * @since 2.12.1
 */
class Filters implements SubscriberInterface {

	/**
	 * Registers the event listeners.
	 *
	 * @since 2.12.1
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'edd_order_statuses_tooltip' => 'add_subscription_status_tooltip',
			'edd_flyout_docs_link'       => 'add_docs_link',
		);
	}

	/**
	 * Add a tooltip to the subscription status in the order list.
	 *
	 * @since 2.12.1
	 * @param array $statuses The order statuses.
	 * @return array
	 */
	public function add_subscription_status_tooltip( $statuses ) {
		$statuses['edd_subscription'] = array(
			'title'       => __( 'Renewal', 'edd-recurring' ),
			'description' => __( 'An automatic renewal order that was completed for a subscription.', 'edd-recurring' ),
		);

		return $statuses;
	}

	/**
	 * Add a link to the recurring payments documentation.
	 *
	 * @since 2.12.1
	 * @param string $link The link to the documentation.
	 * @return string
	 */
	public function add_docs_link( $link ) {
		$section = filter_input( INPUT_GET, 'section', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( edd_is_admin_page( 'settings', 'gateways' ) && 'recurring' === $section ) {
			return 'https://easydigitaldownloads.com/categories/docs/recurring-payments/';
		}

		if ( edd_is_admin_page( 'settings', 'emails' ) && 'recurring' === $section ) {
			return 'https://easydigitaldownloads.com/docs/recurring-payments-subscription-emails/';
		}

		$page = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( 'edd-subscriptions' !== $page ) {
			return $link;
		}

		$action = filter_input( INPUT_GET, 'edd-action', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( 'add_subscription' === $action ) {
			return 'https://easydigitaldownloads.com/docs/recurring-payments-manually-create-subscriptions/';
		}

		return 'https://easydigitaldownloads.com/categories/docs/recurring-payments/';
	}
}
