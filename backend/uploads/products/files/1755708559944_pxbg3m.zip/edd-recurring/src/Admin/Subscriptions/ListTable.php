<?php
/**
 * Subscription List Table Class
 *
 * @package     EDD\Recurring\Admin\Subscriptions
 * @copyright   Copyright (c) 2013, Pippin Williamson
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.4
 */

namespace EDD\Recurring\Admin\Subscriptions;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Admin\List_Table;

/**
 * EDD Subscriptions List Table Class
 *
 * @access      private
 */
class ListTable extends List_Table {

	/**
	 * Number of results to show per page
	 *
	 * @since       2.4
	 */
	public $per_page        = 30;
	public $total_count     = 0;
	public $active_count    = 0;
	public $pending_count   = 0;
	public $expired_count   = 0;
	public $completed_count = 0;
	public $trialling_count = 0;
	public $cancelled_count = 0;
	public $failing_count   = 0;

	/**
	 * Get things started
	 *
	 * @access      private
	 * @since       2.4
	 * @return      void
	 */
	public function __construct() {

		// Set parent defaults.
		parent::__construct(
			array(
				'singular' => 'subscription',
				'plural'   => 'subscriptions',
				'ajax'     => false,
			)
		);

		add_action( 'edd_admin_filter_bar_subscriptions', array( $this, 'filter_bar_items' ) );
		add_action( 'edd_after_admin_filter_bar_subscriptions', array( $this, 'filter_bar_searchbox' ) );
	}

	/**
	 * Adds the advanced filters to the subscriptions table.
	 *
	 * @since 2.11.8
	 * @return void
	 */
	public function advanced_filters() {
		edd_admin_filter_bar( 'subscriptions' );
	}

	/**
	 * Outputs the filter bar searchbox.
	 *
	 * @since 2.11.8
	 * @return void
	 */
	public function filter_bar_searchbox() {
		$this->search_box( __( 'Search', 'edd-recurring' ), 'subscriptions' );
	}

	/**
	 * Adds the items to the filter bar.
	 *
	 * @since 2.11.8
	 * @return void
	 */
	public function filter_bar_items() {
		$this->gateway_filter();
		$this->product_filter();
		$this->status_filter();
		?>
		<span id="edd-after-core-filters">
			<input type="submit" class="button button-secondary" value="<?php esc_html_e( 'Filter', 'edd-recurring' ); ?>"/>
		<?php
		if ( ! empty( $this->get_gateway() ) || ! empty( $this->get_product_id() ) || ! empty( $this->get_status() ) ) :
			$clear_url = edd_get_admin_url(
				array(
					'page' => 'edd-subscriptions',
				)
			);
			?>
				<a href="<?php echo esc_url( $clear_url ); ?>" class="button-secondary">
				<?php esc_html_e( 'Clear', 'edd-recurring' ); ?>
				</a>
			<?php endif; ?>
		</span>
			<?php
	}

	/**
	 * Renders the gateway filter.
	 *
	 * @since 2.11.8
	 * @return void
	 */
	private function gateway_filter() {
		$gateway      = $this->get_gateway();
		$gateways     = array(
			'' => __( 'All gateways', 'edd-recurring' ),
		);
		$all_gateways = edd_get_payment_gateways();

		// Add "all" and pluck labels.
		if ( ! empty( $all_gateways ) ) {
			$gateways = array_merge(
				$gateways,
				wp_list_pluck( $all_gateways, 'admin_label' )
			);
		}
		?>
		<span id="edd-gateway-filter">
			<label for="gateway" class="screen-reader-text"><?php esc_html_e( 'Filter subscriptions by gateway:', 'edd-recurring' ); ?></label>
		<?php
		echo EDD()->html->select(
			array(
				'options'          => $gateways,
				'name'             => 'gateway',
				'id'               => 'gateway',
				'selected'         => esc_attr( $gateway ),
				'show_option_all'  => false,
				'show_option_none' => false,
			)
		);
		?>
		</span>
		<?php
	}

	/**
	 * Renders the status filter.
	 *
	 * @since 2.11.8
	 * @return void
	 */
	private function status_filter() {
		$status       = $this->get_status();
		$statuses     = array(
			'' => __( 'All statuses', 'edd-recurring' ),
		);
		$all_statuses = edd_recurring_get_subscription_statuses();

		if ( ! empty( $all_statuses ) ) {
			$statuses = array_merge(
				$statuses,
				$all_statuses
			);
		}
		?>
		<span id="edd-recurring-status-filter">
			<label for="status" class="screen-reader-text"><?php esc_html_e( 'Filter subscriptions by status:', 'edd-recurring' ); ?></label>
		<?php
		echo EDD()->html->select(
			array(
				'options'          => $statuses,
				'name'             => 'status',
				'id'               => 'status',
				'selected'         => esc_attr( $status ),
				'show_option_all'  => false,
				'show_option_none' => false,
			)
		);
		?>
		</span>
		<?php
	}

	/**
	 * Renders the product filter.
	 *
	 * @since 2.11.8
	 * @return void
	 */
	private function product_filter() {
		$product_id = $this->get_product_id();
		add_filter( 'edd_product_dropdown_args', 'edd_recurring_product_dropdown_recurring_only' );
		echo '<span id="edd-product-filter">';
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo EDD()->html->product_dropdown(
			array(
				'name'       => 'product_id',
				'chosen'     => true,
				'variations' => false,
				'required'   => false,
				'selected'   => absint( $product_id ),
			)
		);
		echo '</span>';
		remove_filter( 'edd_product_dropdown_args', 'edd_recurring_product_dropdown_recurring_only' );
	}

	/**
	 * Retrieve the view types
	 *
	 * @access public
	 * @since 2.4
	 * @return array $views All the views available
	 */
	public function get_views() {

		$current = $this->get_status();
		$views   = array(
			'all' => sprintf(
				'<a href="%s"%s>%s</a>&nbsp;<span class="count">(%d)</span>',
				edd_get_admin_url(
					array(
						'post_type' => 'download',
						'page'      => 'edd-subscriptions',
					)
				),
				empty( $current ) ? ' class="current"' : '',
				__( 'All', 'edd-recurring' ),
				$this->get_count( '' )
			),
		);
		foreach ( edd_recurring_get_subscription_statuses() as $status => $label ) {
			$count = $this->get_count( $status );
			if ( ! $count ) {
				continue;
			}
			$views[ $status ] = sprintf(
				'<a href="%s"%s>%s</a>&nbsp;<span class="count">(%d)</span>',
				edd_get_admin_url(
					array(
						'post_type' => 'download',
						'page'      => 'edd-subscriptions',
						'status'    => $status,
					)
				),
				$current === $status ? ' class="current"' : '',
				$label,
				$count
			);
		}

		return apply_filters( 'edd_recurring_subscriptions_table_views', $views );
	}

	/**
	 * Show the search field
	 *
	 * @since 2.5
	 * @access public
	 *
	 * @param string $text Label for the search box
	 * @param string $input_id ID of the search box
	 *
	 * @return void
	 */
	public function search_box( $text, $input_id ) {

		if ( empty( $_REQUEST['s'] ) && ! $this->has_items() ) {
			return;
		}

		$input_id = $input_id . '-search-input';

		if ( ! empty( $_REQUEST['orderby'] ) ) {
			echo '<input type="hidden" name="orderby" value="' . esc_attr( $_REQUEST['orderby'] ) . '" />';
		}

		if ( ! empty( $_REQUEST['order'] ) ) {
			echo '<input type="hidden" name="order" value="' . esc_attr( $_REQUEST['order'] ) . '" />';
		}
		?>
		<p class="search-box">
		<?php do_action( 'edd_recurring_subscription_search_box' ); ?>
			<label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo esc_html( $text ); ?>:</label>
			<input type="search" id="<?php echo esc_attr( $input_id ); ?>" name="s" value="<?php _admin_search_query(); ?>" />
		<?php submit_button( $text, 'button', false, false, array( 'ID' => 'search-submit' ) ); ?><br/>
		</p>
		<?php
	}

	/**
	 * Render most columns
	 *
	 * @access      private
	 * @since       2.4
	 * @return      string
	 */
	protected function column_default( $item, $column_name ) {
		if ( 'id' !== $column_name ) {
			/**
			 * Allow custom column data to be added.
			 *
			 * @since 2.12.0
			 * @param string           $value The value of the column.
			 * @param EDD_Subscription $item
			 */
			return apply_filters( "edd_subscription_column_{$column_name}", '', $item );
		}
		if ( ! current_user_can( 'view_subscriptions' ) ) {
			return '#' . $item->id;
		}
		$url     = add_query_arg(
			array(
				'post_type' => 'download',
				'page'      => 'edd-subscriptions',
				'id'        => absint( $item->id ),
			),
			admin_url( 'edit.php' )
		);
		$output  = '<a href="' . esc_url( $url ) . '">#' . esc_html( $item->id ) . '</a>';
		$output .= '<div class="row-actions"><a href="' . esc_url( $url ) . '">' . esc_html__( 'View Details', 'edd-recurring' ) . '</a></div>';

		return $output;
	}

	/**
	 * Customer column
	 *
	 * @access      private
	 * @since       2.4
	 * @return      string
	 */
	function column_customer_id( $item ) {
		$subscriber = new \EDD_Recurring_Subscriber( $item->customer_id );
		$customer   = ! empty( $subscriber->name ) ? $subscriber->name : $subscriber->email;
		$url        = edd_get_admin_url(
			array(
				'page' => 'edd-customers',
				'view' => 'overview',
				'id'   => absint( $subscriber->id ),
			)
		);

		return '<a href="' . esc_url( $url ) . '">' . $customer . '</a>';
	}


	/**
	 * Status column
	 *
	 * @access      private
	 * @since       2.4
	 * @return      string
	 */
	function column_status( $item ) {
		return $item->get_status_badge();
	}

	/**
	 * Period column
	 *
	 * @access      private
	 * @since       2.4
	 * @return      string
	 */
	function column_period( $item ) {
		$period         = EDD_Recurring()->get_pretty_subscription_frequency( $item->period );
		$billing_cycle  = edd_currency_filter( edd_format_amount( $item->recurring_amount ), edd_get_payment_currency_code( $item->parent_payment_id ) ) . ' / ' . $period;
		$initial_amount = edd_currency_filter( edd_format_amount( $item->initial_amount ), edd_get_payment_currency_code( $item->parent_payment_id ) );
		ob_start();
		?>
		<?php esc_html_e( 'Initial Amount', 'edd-recurring' ); ?>: <?php echo esc_html( $initial_amount ); ?><br>
		<?php echo esc_html( $billing_cycle ); ?>
		<?php
		return ob_get_clean();
	}

	/**
	 * Initial Amount column
	 *
	 * @access      private
	 * @since       2.4
	 * @return      string
	 */
	function column_initial_amount( $item ) {
		return edd_currency_filter( edd_format_amount( $item->initial_amount ), edd_get_payment_currency_code( $item->parent_payment_id ) );
	}

	/**
	 * Renewal date column
	 *
	 * @access      private
	 * @since       2.4
	 * @return      string
	 */
	function column_renewal_date( $item ) {
		return ! empty( $item->expiration ) ? date_i18n( get_option( 'date_format' ), strtotime( $item->expiration ) ) : __( 'N/A', 'edd-recurring' );
	}

	/**
	 * Payment column
	 *
	 * @access      private
	 * @since       2.4
	 * @return      string
	 */
	function column_parent_payment_id( $item ) {
		return '<a href="' . esc_url( admin_url( 'edit.php?post_type=download&page=edd-payment-history&view=view-order-details&id=' . $item->parent_payment_id ) ) . '">' . edd_get_payment_number( $item->parent_payment_id ) . '</a>';
	}

	/**
	 * Gets the gateway column text.
	 *
	 * @since 2.11.8
	 * @param EDD_Subscription $item
	 * @return string
	 */
	function column_gateway( $item ) {
		return edd_get_gateway_admin_label( $item->gateway );
	}

	/**
	 * Product ID column
	 *
	 * @access      private
	 * @since       2.4
	 * @return      string
	 */
	function column_product_id( $item ) {
		$download = edd_get_download( $item->product_id );

		if ( $download instanceof \EDD_Download ) {
			$product_name = $download->get_name();
			if ( ! is_null( $item->price_id ) && $download->has_variable_prices() ) {
				$prices = $download->get_prices();
				if ( isset( $prices[ $item->price_id ] ) && ! empty( $prices[ $item->price_id ]['name'] ) ) {
					$product_name .= ' &mdash; ' . $prices[ $item->price_id ]['name'];
				}
			}

			return '<a href="' . esc_url( admin_url( 'post.php?action=edit&post=' . $item->product_id ) ) . '">' . $product_name . '</a>';
		}

		return '&mdash;';
	}

	/**
	 * Retrieve the table columns
	 *
	 * @access      public
	 * @since       2.4
	 * @return      array
	 */
	public function get_columns() {
		$columns = array(
			'id'                => __( 'Subscription', 'edd-recurring' ),
			'customer_id'       => __( 'Customer', 'edd-recurring' ),
			'product_id'        => edd_get_label_singular(),
			'period'            => __( 'Billing Details', 'edd-recurring' ),
			'parent_payment_id' => __( 'Order', 'edd-recurring' ),
			'renewal_date'      => __( 'Renewal Date', 'edd-recurring' ),
			'status'            => __( 'Status', 'edd-recurring' ),
			'gateway'           => __( 'Gateway', 'edd-recurring' ),
		);

		return apply_filters( 'edd_report_subscription_columns', $columns );
	}

	/**
	 * Retrieve the sortable columns.
	 *
	 * @since 2.13.1
	 * @return array Array of all the sortable columns.
	 */
	public function get_sortable_columns() {
		return apply_filters(
			'edd_subscriptions_table_sortable_columns',
			array(
				'id'           => array( 'id', false ),
				'renewal_date' => array( 'expiration', false ),
			)
		);
	}

	protected function bulk_actions( $which = '' ) {
		if ( 'top' === $which ) {
			$this->views();
		}
	}

	/**
	 * Gets the currently queried gateway.
	 *
	 * @since 2.11.8
	 * @return string
	 */
	private function get_gateway() {
		return isset( $_GET['gateway'] ) ? sanitize_text_field( $_GET['gateway'] ) : '';
	}

	/**
	 * Gets the currently queried product ID.
	 *
	 * @since 2.11.8
	 * @return string
	 */
	private function get_product_id() {
		return filter_input( INPUT_GET, 'product_id', FILTER_SANITIZE_NUMBER_INT );
	}

	/**
	 * Setup the final data for the table.
	 *
	 * @since       2.4
	 * @uses        $this->_column_headers
	 * @uses        $this->items
	 * @uses        $this->get_columns()
	 * @uses        $this->get_sortable_columns()
	 * @uses        $this->get_pagenum()
	 * @uses        $this->set_pagination_args()
	 * @return      array
	 */
	public function prepare_items() {

		$columns  = $this->get_columns();
		$hidden   = array(); // No hidden columns
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array( $columns, $hidden, $sortable );
		$this->items           = $this->get_data( $this->get_args() );
		$total_items           = $this->get_count( $this->get_status() );

		$this->set_pagination_args(
			array(
				'total_items' => $total_items,
				'per_page'    => $this->per_page,
				'total_pages' => ceil( $total_items / $this->per_page ),
			)
		);
	}

	/**
	 * Gets the data for the table.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public function get_data() {
		$db = new \EDD_Subscriptions_DB();

		return $db->get_subscriptions( $this->get_args() );
	}

	/**
	 * Gets the query parameters for the table.
	 *
	 * @return array
	 */
	private function get_args() {
		$status       = $this->get_status();
		$gateway      = $this->get_gateway();
		$product      = $this->get_product_id();
		$current_page = $this->get_pagenum();
		$search       = $this->get_search();
		$args         = array(
			'number' => $this->per_page,
			'offset' => $this->per_page * ( $this->get_paged() - 1 ),
		);

		if ( $search ) {
			$args['search'] = $search;
		}

		if ( $status ) {
			$args['status'] = $status;
		}

		if ( ! empty( $gateway ) ) {
			$args['gateway'] = $gateway;
		}

		if ( ! empty( $product ) ) {
			$args['product_id'] = $product;
		}

		// Handle sorting parameters.
		$orderby = filter_input( INPUT_GET, 'orderby', FILTER_SANITIZE_SPECIAL_CHARS );
		$order   = filter_input( INPUT_GET, 'order', FILTER_SANITIZE_SPECIAL_CHARS );

		if ( ! empty( $orderby ) ) {
			$args['orderby'] = $orderby;
		}

		if ( ! empty( $order ) && in_array( strtoupper( $order ), array( 'ASC', 'DESC' ), true ) ) {
			$args['order'] = $order;
		}

		return $args;
	}

	/**
	 * Gets the number of subscriptions for a specific status.
	 *
	 * @since 2.13.0
	 * @param string $status
	 * @return int
	 */
	private function get_count( $status = '' ) {
		if ( empty( $status ) ) {
			$status = 'any';
		}
		if ( array_key_exists( $status, $this->counts ) ) {
			return $this->counts[ $status ];
		}

		$db   = new \EDD_Subscriptions_DB();
		$args = array();
		if ( $status && 'any' !== $status ) {
			$args['status'] = $status;
		}
		$search = $this->get_search();
		if ( $search ) {
			$args['search'] = $search;
		}
		$product_id = $this->get_product_id();
		if ( $product_id ) {
			$args['product_id'] = $product_id;
		}

		$this->counts[ $status ] = $db->count( $args );

		return $this->counts[ $status ];
	}

	/**
	 * Retrieve the subscription counts.
	 *
	 * @since 1.4
	 * @deprecated 2.13.0 in favor of get_count().
	 * @return void
	 */
	public function get_subscription_counts() {

		$db = new \EDD_Subscriptions_DB();

		$args   = array();
		$search = filter_input( INPUT_GET, 's', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( $search ) {
			$args['search'] = $search;
		}

		$this->total_count = $db->count( $args );

		$statuses = edd_recurring_get_subscription_statuses();
		foreach ( $statuses as $status ) {
			if ( ! property_exists( $this, $status . '_count' ) ) {
				continue;
			}
			$this->get_count( $status );
		}
	}
}
