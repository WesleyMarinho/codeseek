<?php
/**
 * Recurring Dashboard Widget.
 *
 * @package EDD\Recurring\Admin\Dashboard
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Dashboard;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\EventManagement\SubscriberInterface;
use EDD\HTML\Tooltip;
use EDD\Recurring\Admin\Reports\RecurringRevenue;

/**
 * Recurring Dashboard Widget.
 *
 * @since 2.13.0
 */
class Widget implements SubscriberInterface {

	/**
	 * Get the subscribed events.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'edd_sales_summary_widget_after_stats' => 'widget',

		);
	}

	/**
	 * Display the widget
	 *
	 * @since  2.4.15
	 * @return void
	 */
	public function widget() {
		?>
		<div class="table table_left table_current_month">
			<table>
				<thead>
					<tr>
						<td colspan="2">
							<?php _e( 'Subscriptions Created', 'edd-recurring' ); ?>
							<?php
							$content  = __( 'This is the number of subscriptions created in the specified period.', 'edd-recurring' );
							$content .= "\n\n";
							$content .= __( 'These counts reflect subscriptions that are active or trialling that were created during the specified period.', 'edd-recurring' );
							$tooltip  = new Tooltip(
								array(
									'content' => $content,
								)
							);
							$tooltip->output();
							?>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="first t"><?php _e( 'This Year', 'edd-recurring' ); ?></td>
						<td class="b"><?php echo $this->get_subscription_count( 'year' ); ?></td>
					</tr>
					<tr>
						<td class="first t"><?php _e( 'This Month', 'edd-recurring' ); ?></td>
						<td class="b"><?php echo $this->get_subscription_count( 'month' ); ?></td>
					</tr>
					<tr>
						<td class="first t"><?php _e( 'Total', 'edd-recurring' ); ?></td>
						<td class="b"><?php echo $this->get_subscription_count(); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="table table_right table_totals">
			<table>
				<thead>
					<tr>
						<td colspan="2">
							<?php _e( 'Estimated Recurring Revenue', 'edd-recurring' ); ?>
							<?php
							$content  = __( 'Estimated recurring revenue is calculated on the frequency and recurring amount of active subscriptions.', 'edd-recurring' );
							$content .= "\n\n";
							$content .= __( 'Example: A yearly subscription of $120 will add $10 to the Monthly Recurring Revenue (MRR) (by dividing $120 over 12 months) and $120 to the Annual Recurring Revenue (ARR).', 'edd-recurring' );
							$content .= "\n\n";
							$content .= __( 'These numbers help track long-term business growth, but they don\'t represent the actual cash collected each month.', 'edd-recurring' );
							$tooltip  = new Tooltip(
								array(
									'content' => $content,
								)
							);
							$tooltip->output();
							?>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="t"><?php _e( 'Monthly', 'edd-recurring' ); ?></td>
						<td class="last b"><?php echo $this->format_revenue( RecurringRevenue::get_mrr() ); ?></td>
					</tr>
					<tr>
						<td class="t"><?php _e( 'Annual', 'edd-recurring' ); ?></td>
						<td class="last b"><?php echo $this->format_revenue( RecurringRevenue::get_arr() ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div style="clear: both"></div>
		<?php
	}

	/**
	 * Retrieve subscription count for given period
	 *
	 * @since  2.4.15
	 *
	 * @param string $period Period to retrieve count for.
	 *
	 * @return int
	 */
	public function get_subscription_count( $period = '' ) {

		$start = '';
		$end   = '';

		if ( ! empty( $period ) ) {

			switch ( $period ) {

				case 'year':
					$current_date = new \EDD\Utils\Date();
					$start        = $current_date->copy()->startOfYear()->format( 'mysql' );
					$end          = $current_date->copy()->endOfYear()->format( 'mysql' );
					break;

				case 'month':
					$current_date = new \EDD\Utils\Date();
					$start        = $current_date->copy()->startOfMonth()->format( 'mysql' );
					$end          = $current_date->copy()->endOfMonth()->format( 'mysql' );
					break;
			}
		}

		// Setting the status for active and trialling subscriptions.
		$args = array(
			'status__in' => array( 'active', 'trialling' ),
		);

		if ( ! empty( $start ) && ! empty( $end ) ) {
			$args['date_query'] = array(
				array(
					'column'    => 'created',
					'after'     => $start,
					'before'    => $end,
					'inclusive' => true,
				),
			);
		}

		/**
		 * Filter the subscription count args. Useful for adding additional statuses, etc.
		 *
		 * @since  2.12.0
		 * @param  array  $args   The args
		 * @param  string $period The period
		 * @param  object $this   The widget object
		 * @return array
		 */
		$args = apply_filters( 'edd_recurring_summary_widget_subscription_count_args', $args, $period, $this );

		return edd_format_amount( edd_recurring_count_subscriptions( $args ), false );
	}

	/**
	 * Retrieve estimated revenue for the number of days given
	 *
	 * @since  2.4.15
	 *
	 * @param int $days Number of days (0 to 365).
	 *
	 * @return float
	 */
	public function get_estimated_revenue( $days = 0 ) {

		global $wpdb;

		// Cast days to int.
		$days = absint( $days );

		// How long to cache values for.
		$expiration = HOUR_IN_SECONDS;

		// "Total"
		if ( empty( $days ) ) {

			// Get the transient.
			$key    = 'edd_recurring_estimated_revenue';
			// $amount = get_transient( $key );
			$amount = false;

			// No transient.
			if ( false === $amount ) {

				// SQL.
				$sql = "SELECT SUM(recurring_amount)
						  FROM {$wpdb->prefix}edd_subscriptions
						  WHERE
							  ( expiration >= %s )
							  AND status IN( 'active', 'trialling' )";

				// Boundary.
				$now = ( new \EDD\Utils\Date() )->format( 'mysql' );

				// Query the database.
				$prepared_sql = $wpdb->prepare( $sql, $now );
				$amount       = $wpdb->get_var( $prepared_sql );

				// Cache.
				set_transient( $key, $amount, $expiration );
			}

			// "Next X Days".
		} else {
			// Get the transient.
			$key    = 'edd_recurring_estimated_revenue_' . $days;
			// $amount = get_transient( $key );
			$amount = false;

			// No transient.
			if ( false === $amount ) {

				// Calculate the ratio based on number of $days.
				$yid   = 365; // Year in days.
				$ratio = ( $yid / $days );

				// Array of period => interval.
				$sum_cases = array(
					'day'       => 365,
					'week'      => 52,
					'month'     => 12,
					'quarter'   => 4,
					'semi-year' => 2,
					'year'      => 1,
				);

				// Default sums array.
				$sums = array();

				// Loop through sums and combine into array of SQL.
				foreach ( $sum_cases as $period => $interval ) {

					// Adjust the SQL according to the days ratio, rounded up.
					$math = ceil( $interval / $ratio );

					// Add SUM case to array.
					$sums[] = "SUM( CASE WHEN period='{$period}' THEN recurring_amount * {$math} END ) AS '{$period}'";
				}

				// Combine SUM() clauses into usable SQL.
				$sum_sql = join( ",\n ", $sums );

				// SQL.
				$sql = "SELECT {$sum_sql}
							 FROM {$wpdb->prefix}edd_subscriptions
							 WHERE
							 ( expiration >= %s AND expiration <= %s )
							 AND status IN( 'active', 'trialling' )";

				// Boundaries (all day today, all day final day).
				$now_date = new \EDD\Utils\Date();
				$now      = $now_date->format( 'mysql' );
				$end_date = $now_date->addDays( $days )->format( 'mysql' );

				// Query the database.
				$prepared_sql = $wpdb->prepare( $sql, $now, $end_date );
				$amounts      = $wpdb->get_results( $prepared_sql, ARRAY_A );

				// Sum the values.
				$amount = array_sum( reset( $amounts ) );

				// Cache.
				set_transient( $key, $amount, $expiration );

			}
		}

		// If the value is empty, ensure we set it to a numeric empty.
		if ( empty( $amount ) ) {
			$amount = 0;
		}

		return edd_currency_filter( edd_format_amount( edd_sanitize_amount( $amount ) ) );
	}

	/**
	 * Format the revenue amount.
	 *
	 * @since 2.13.0
	 * @param float $amount The amount to format.
	 * @return string
	 */
	private function format_revenue( $amount ) {
		return edd_currency_filter( edd_format_amount( edd_sanitize_amount( $amount ) ) );
	}
}
