<?php
/**
 * Admin upgrade screen.
 *
 * @package     EDD\Recurring\Admin\Upgrades
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Upgrades;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class Screen
 *
 * @since 2.13.0
 */
class Screen {

	/**
	 * Renders the upgrade screen.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public static function render() {
		?>
		<div class="wrap">
			<hr class="wp-header-end">
			<?php self::do_content(); ?>
		</div>
		<?php
	}

	/**
	 * Renders the upgrade screen content.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	private static function do_content() {
		$action = self::get_action();
		if ( empty( $action ) ) {
			esc_html_e( 'No upgrade selected.', 'edd-recurring' );
			return;
		}

		self::do_upgrade( $action );
	}

	/**
	 * Gets the action from the GET request.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	private static function get_action() {
		return filter_input( INPUT_GET, 'edd-upgrade', FILTER_SANITIZE_SPECIAL_CHARS );
	}

	/**
	 * Sets up the upgrade routine and calls the appropriate function.
	 *
	 * @since 2.13.0
	 * @param string $action The upgrade action.
	 * @return void
	 */
	private static function do_upgrade( $action ) {

		add_filter( 'edd_load_admin_scripts', '__return_true' );
		edd_load_admin_scripts( 'edd-admin-upgrades' );

		do_action( "edd_admin_upgrades_render_{$action}", wp_create_nonce( "edd-upgrade-{$action}" ) );

		// Remove the above filter.
		remove_filter( 'edd_load_admin_scripts', '__return_true' );
	}
}
