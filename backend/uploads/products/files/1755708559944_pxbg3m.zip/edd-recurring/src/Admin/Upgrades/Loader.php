<?php
/**
 * Admin Upgrades handler.
 *
 * @package     EDD\Recurring\Admin\Upgrades\Screens
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Upgrades;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class Loader
 *
 * @since 2.13.0
 */
class Loader implements \EDD\EventManagement\SubscriberInterface {

	/**
	 * Registers the event listeners.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'admin_init'        => 'register_upgrades',
			'admin_notices'     => 'maybe_show_resume_notice',
			'edd_is_admin_page' => array( 'mark_as_admin', 10, 5 ),
			'admin_menu'        => array( 'register_upgrade_page', 9999 ),
		);
	}

	/**
	 * Registers the upgrade routines.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function register_upgrades() {
		if ( ! current_user_can( 'manage_shop_settings' ) ) {
			return;
		}

		$upgrades = $this->get_upgrades();
		if ( empty( $upgrades ) ) {
			return;
		}

		foreach ( $upgrades as $upgrade ) {
			if ( is_subclass_of( $upgrade, '\\EDD\\Recurring\\Admin\\Upgrades\\Screens\\Upgrade' ) ) {
				new $upgrade();
			}
		}
	}

	/**
	 * Maybe shows the resume upgrade notice.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function maybe_show_resume_notice() {
		if ( ! $this->can_show_notice() ) {
			return;
		}

		$resume_upgrade = edd_maybe_resume_upgrade();
		if ( ! empty( $resume_upgrade ) ) {
			$this->resume_upgrade( $resume_upgrade );
		}
	}

	/**
	 * Marks the specified page and view as admin.
	 *
	 * @since 2.13.0
	 * @param mixed  $found The value indicating whether the page and view were found.
	 * @param string $page The page being checked.
	 * @param string $view The view being checked.
	 * @param string $passed_page The passed page value.
	 * @param string $passed_view The passed view value.
	 * @return mixed The updated value indicating whether the page and view are admin.
	 */
	public function mark_as_admin( $found, $page, $view, $passed_page, $passed_view ) {
		if ( $found || ! empty( $passed_page ) ) {
			return $found;
		}

		if ( $this->get_upgrade_slug() === $page ) {
			return true;
		}

		return $found;
	}

	/**
	 * Gets the upgrade routines.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	private function get_upgrades() {
		return array(
			Screens\MissingStripe::class,
		);
	}

	/**
	 * Shows the resume upgrade notice.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	private function resume_upgrade( $resume_upgrade ) {
		?>
		<div class="notice error">
			<p>
				<?php
				printf(
					wp_kses_post(
						/* translators: 1. opening link tag; 2. closing link tag */
						__( 'Easy Digital Downloads needs to complete a database upgrade that was previously started. %1$sResume the upgrade%2$s.', 'edd-recurring' )
					),
					'<a href="' . esc_url( add_query_arg( $resume_upgrade, admin_url( 'index.php' ) ) ) . '">',
					'</a>'
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Whether the notice can be displayed.
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	protected function can_show_notice() {
		$page = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( $this->get_upgrade_slug() === $page ) {
			return false;
		}

		return \current_user_can( 'manage_shop_settings' );
	}

	/**
	 * Registers the hidden upgrades page.
	 * If the EDD core upgrades have been updated, this will exit early.
	 *
	 * @since 2.13.0
	 */
	public function register_upgrade_page() {
		if ( class_exists( '\\EDD\Admin\\Upgrades\\Screen' ) ) {
			return;
		}

		add_submenu_page(
			'index.php',
			__( 'EDD Upgrades', 'edd-recurring' ),
			__( 'EDD Upgrades', 'edd-recurring' ),
			'manage_shop_settings',
			$this->get_upgrade_slug(),
			array( '\\EDD\\Recurring\\Admin\\Upgrades\\Screen', 'render' )
		);
		add_action(
			'admin_head',
			function () {
				remove_submenu_page( 'index.php', $this->get_upgrade_slug() );
				$page = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_SPECIAL_CHARS );
				if ( $this->get_upgrade_slug() === $page ) {
					remove_all_actions( 'admin_notices' );
					remove_all_actions( 'all_admin_notices' );
					if ( class_exists( '\\EDD\\Admin\\Menu\\Header' ) ) {
						$header = new \EDD\Admin\Menu\Header();
						add_action( 'admin_notices', array( $header, 'render' ), 1 );
					}
				}
			}
		);
	}

	/**
	 * Gets the upgrade slug.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	private function get_upgrade_slug() {
		return Screens\Upgrade::get_upgrade_slug();
	}
}
