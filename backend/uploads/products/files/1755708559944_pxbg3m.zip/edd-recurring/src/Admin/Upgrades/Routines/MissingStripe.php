<?php
/**
 * Creates a missing Stripe subscriptions upgrade routine.
 *
 * @package     EDD\Recurring\Admin\Upgrades\Screens
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Upgrades\Routines;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * MissingStripe Class
 *
 * @since 2.13.0
 */
class MissingStripe extends \EDD_Batch_Export {

	/**
	 * Our export type. Used for export-type specific filters/actions.
	 *
	 * @var string
	 * @since 2.13.0
	 */
	public $export_type = 'recurring_missing_stripe';

	/**
	 * Allows for a non-download batch processing to be run.
	 *
	 * @since  2.13.0
	 * @var boolean
	 */
	public $is_void = true;

	/**
	 * Sets the number of items to pull on each step.
	 *
	 * @since  2.13.0
	 * @var integer
	 */
	public $per_step = 50;

	/**
	 * Get the Export Data
	 *
	 * @since 2.13.0
	 * @return array $data The data for the CSV file
	 */
	public function get_data() {

		$stripe     = new \EDD\Recurring\Gateways\Stripe\MissingSubscription();
		$step_items = $stripe->find(
			array(
				'limit'  => $this->per_step,
				'offset' => ( $this->step - 1 ) * $this->per_step,
			)
		);

		if ( empty( $step_items ) ) {
			return false;
		}

		$fixed = array();
		foreach ( $step_items as $order ) {
			$fixed[] = \EDD\Recurring\Gateways\Stripe\MissingSubscription::fix( $order->order_id );
		}

		return $fixed;
	}

	/**
	 * Return the calculated completion percentage
	 *
	 * @since 2.13.0
	 * @return int
	 */
	public function get_percentage_complete() {

		$total      = $this->get_total();
		$percentage = 0;
		if ( $total > 0 ) {
			$percentage = ( ( $this->step * $this->per_step ) / $total ) * 100;
		}

		if ( $percentage > 100 ) {
			$percentage = 100;
		}

		return $percentage;
	}

	/**
	 * Process a step
	 *
	 * @since 2.13.0
	 * @return bool
	 */
	public function process_step() {

		if ( ! $this->can_export() ) {
			wp_die(
				__( 'You do not have permission to run this upgrade.', 'edd-recurring' ),
				__( 'Error', 'edd-recurring' ),
				array( 'response' => 403 )
			);
		}

		$had_data = $this->get_data();

		if ( $had_data ) {
			$this->done = false;
			return true;
		}

		$this->done = true;
		delete_option( 'edd_' . $this->export_type );
		$this->message = __( 'Subscription records have been successfully updated.', 'edd-recurring' );
		edd_set_upgrade_complete( $this->export_type );
		return false;
	}

	/**
	 * Set headers for the export
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function headers() {
		ignore_user_abort( true );

		if ( ! edd_is_func_disabled( 'set_time_limit' ) ) {
			set_time_limit( 0 );
		}
	}

	/**
	 * Perform the export.
	 *
	 * @access public
	 * @since 2.13.0
	 * @return void
	 */
	public function export() {
		$this->headers();
		edd_die();
	}

	/**
	 * Get the total number of items to export.
	 *
	 * @since 2.13.0
	 * @return int
	 */
	private function get_total() {
		$total = get_option( 'edd_' . $this->export_type, false );
		if ( false !== $total ) {
			return absint( $total );
		}
		$stripe = new \EDD\Recurring\Gateways\Stripe\MissingSubscription();
		$items  = $stripe->find(
			array(
				'limit' => 99999,
			)
		);
		$total  = count( $items );
		update_option( 'edd_' . $this->export_type, $total );

		return absint( $total );
	}
}
