<?php
/**
 * Loads the RecurringRevenue pointer.
 *
 * @package EDD\Recurring\Admin\Pointers
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since 2.13.0
 */

namespace EDD\Recurring\Admin\Pointers;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class RecurringRevenue
 *
 * @since 2.12.0
 */
class RecurringRevenue {

	/**
	 * Maybe show an admin pointer showing a message about the new menu locations.
	 *
	 * @since 2.12.0
	 *
	 * @param array $pointers Array of pointers.
	 *
	 * @return array
	 */
	public static function register_pointer( $pointers ) {
		if ( ! current_user_can( 'view_shop_reports' ) ) {
			return $pointers;
		}

		if ( ! edd_is_admin_page( 'edd-reports' ) ) {
			return $pointers;
		}

		// Add this to any reports view.
		$view = isset( $_GET['view'] ) ? sanitize_text_field( wp_unslash( $_GET['view'] ) ) : '';

		// If we don't have a registered view, bail.
		if ( empty( $view ) ) {
			return $pointers;
		}

		if ( 'recurring_subscriptions' === $view ) { // If we are on the new reports page, add specific pointers.
			$pointers[] = array(
				'pointer_id' => 'recurring_subscription_mrr_tile',
				'target'     => '#recurring_subscription_mrr',
				'options'    => array(
					'content'  => sprintf(
						'<h3>%s</h3><p>%s</p>',
						__( 'Monthly Recurring Revenue (MRR)', 'edd-recurring' ),
						__( '<p>A projection of monthly revenue based on the value of all active subscriptions.</p><p>For example, an annual plan worth $120 contributes $10/month to MRR.</p>', 'edd-recurring' )
					),
					'position' => array(
						'edge'  => 'top',
						'align' => 'left',
					),
				),
			);

			$pointers[] = array(
				'pointer_id' => 'recurring_subscription_arr_tile',
				'target'     => '#recurring_subscription_arr',
				'options'    => array(
					'content'  => sprintf(
						'<h3>%s</h3><p>%s</p>',
						__( 'Annual Recurring Revenue (ARR)', 'edd-recurring' ),
						__( '<p>A projection of annual revenue based on the value of all active subscriptions.</p><p>For example, a monthly plan worth $10 contributes $120/year to ARR.</p>', 'edd-recurring' )
					),
					'position' => array(
						'edge'  => 'top',
						'align' => 'left',
					),
				),
			);

		} else { // If we are on other reports, point to the new report in the menu.

			$content = sprintf(
				'<h3>%s</h3><p>%s</p>',
				__( 'New Report Tiles Available!', 'edd-recurring' ),
				__( 'Introducing: <strong>Recurring Revenue Tiles</strong>. <br />Gain even more insights into your recurring revenue business with quick glance of your MRR and ARR.', 'edd-recurring' ),
			);

			$pointers[] = array(
				'pointer_id' => 'edd_recurring_revenue_tiles',
				'target'     => '#edd_general_recurring_subscriptions-nav-item',
				'options'    => array(
					'content'  => $content,
					'position' => array(
						'edge'  => 'left',
						'align' => 'left',
					),
				),
			);
		}

		return $pointers;
	}
}
