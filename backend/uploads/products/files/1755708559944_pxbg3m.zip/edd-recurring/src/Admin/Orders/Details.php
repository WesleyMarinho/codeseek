<?php
/**
 * Order details for subscriptions.
 *
 * @package     EDD\Recurring\Admin\Orders
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Orders;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Order details for subscriptions.
 */
class Details implements \EDD\EventManagement\SubscriberInterface {

	/**
	 * Get the events to subscribe to.
	 *
	 * @since 2.13.0
	 * @return array
	 */
	public static function get_subscribed_events() {
		return array(
			'edd_get_order_details_sections' => array( 'subscription_section', 10, 2 ),
			'edd_missing_subscription'       => 'fix_missing_subscription',
			'admin_notices'                  => 'missing_subscription_notice',
		);
	}

	/**
	 * Add the subscription section to the order details.
	 *
	 * @since 2.13.0
	 * @param array                  $sections The sections.
	 * @param \EDD\Orders\Order|null $order    The order.
	 * @return array
	 */
	public function subscription_section( $sections, $order ) {
		if ( edd_is_add_order_page() ) {
			return $sections;
		}

		if ( $this->order_has_subscription( $order ) ) {
			$sections[] = array(
				'id'       => 'subscriptions',
				'label'    => __( 'Subscriptions', 'edd-recurring' ),
				'icon'     => 'update',
				'callback' => array( $this, 'details' ),
			);
		}

		return $sections;
	}

	/**
	 * Display the subscription details.
	 *
	 * @since 2.13.0
	 * @param \EDD\Orders\Order $order The order.
	 * @return void
	 */
	public function details( $order ) {
		$is_parent_order = edd_get_order_meta( $order->id, '_edd_subscription_payment', true );
		if ( $is_parent_order ) {
			$subs = edd_recurring_get_subscriptions(
				array(
					'parent_payment_id' => $order->id,
					'order'             => 'ASC',
				)
			);
			if ( ! empty( $subs ) ) {
				foreach ( $subs as $sub ) {
					include EDD_RECURRING_PLUGIN_DIR . 'includes/admin/views/orders/order-details.php';
				}
				return;
			}
		}

		$sub    = false;
		$sub_id = edd_get_order_meta( $order->id, 'subscription_id', true );
		if ( $sub_id ) {
			$sub = edd_recurring_get_subscription( $sub_id );
		} elseif ( ! empty( $order->parent ) ) {
			$subs = edd_recurring_get_subscriptions(
				array(
					'parent_payment_id' => $order->parent,
					'order'             => 'ASC',
				)
			);
			$sub  = reset( $subs );
		}
		if ( $sub ) {
			include EDD_RECURRING_PLUGIN_DIR . 'includes/admin/views/orders/order-details.php';
			return;
		}

		$this->show_fixer( $order );
	}

	/**
	 * Fix a missing subscription.
	 *
	 * @since 2.13.0
	 * @param array $data The data.
	 * @return void
	 */
	public function fix_missing_subscription( $data ) {
		if ( ! $this->can_fix( $data ) ) {
			return;
		}

		$order_id = absint( $data['id'] );
		$fixed    = \EDD\Recurring\Gateways\Stripe\MissingSubscription::fix( $order_id );
		$args     = array(
			'page'        => 'edd-payment-history',
			'view'        => 'view-order-details',
			'id'          => $order_id,
			'edd-message' => true === $fixed ? 'missing-subscription' : 'missing-subscription-error',
		);

		edd_redirect( edd_get_admin_url( $args ) );
	}

	/**
	 * Show a notice if the subscription tool was used.
	 *
	 * @since 2.13.0
	 * @return void
	 */
	public function missing_subscription_notice() {
		if ( ! edd_is_admin_page( 'payments' ) ) {
			return;
		}

		$order_id = filter_input( INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT );
		if ( ! $order_id ) {
			return;
		}

		$message = filter_input( INPUT_GET, 'edd-message', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( empty( $message ) || ! in_array( $message, array( 'missing-subscription', 'missing-subscription-error' ), true ) ) {
			return;
		}

		$args = array(
			'id'      => 'missing-subscription',
			'message' => __( 'The subscription was created successfully.', 'edd-recurring' ),
			'class'   => 'success',
		);

		if ( 'missing-subscription-error' === $message ) {
			$args = array(
				'id'      => 'missing-subscription-error',
				'message' => edd_get_order_meta( $order_id, '_edd_recurring_missing_subscription_error', true ),
				'class'   => 'error',
			);
		}
		if ( empty( $args['message'] ) ) {
			$args['message'] = __( 'The subscription could not be created.', 'edd-recurring' );
		}

		EDD()->notices->add_notice( $args );
	}

	/**
	 * Check if the order has a subscription.
	 *
	 * @since 2.13.0
	 * @param \EDD\Orders\Order $order The order.
	 * @return bool
	 */
	private function order_has_subscription( $order ) {
		if ( edd_get_order_meta( $order->id, 'subscription_id' ) ) {
			return true;
		}

		if ( edd_get_order_meta( $order->id, '_edd_subscription_payment', true ) ) {
			return true;
		}

		if ( ! empty( $order->parent ) && 'sale' === $order->type ) {
			return true;
		}

		$subscription = edd_recurring_get_subscription_by( 'parent_payment_id', $order->id );
		if ( $subscription ) {
			if ( empty( $order->parent ) ) {
				edd_update_order_meta( $order->id, '_edd_subscription_payment', 1 );
			}

			return true;
		}

		if ( edd_get_order_meta( $order->id, '_edd_recurring_missing_subscription_error', true ) ) {
			return false;
		}

		foreach ( $order->items as $item ) {
			$product = new \EDD\Recurring\Downloads\Product( $item->product_id );
			if ( $product->is_recurring( $item->price_id ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if the user can fix the missing subscription.
	 *
	 * @since 2.13.0
	 * @param array $data The data.
	 * @return bool
	 */
	private function can_fix( $data ) {
		if ( ! current_user_can( 'manage_subscriptions' ) ) {
			return false;
		}

		if ( empty( $data['id'] ) ) {
			return false;
		}

		if ( empty( $data['edd-nonce'] ) || ! wp_verify_nonce( $data['edd-nonce'], 'edd-missing-subscription-' . $data['id'] ) ) {
			return false;
		}

		$order = edd_get_order( $data['id'] );

		return $order && 'stripe' === $order->gateway;
	}

	/**
	 * Show a fixer for missing subscriptions.
	 *
	 * @since 2.13.0
	 * @param \EDD\Orders\Order $order The order.
	 * @return void
	 */
	private function show_fixer( $order ) {
		if ( 'stripe' !== $order->gateway || ! empty( $order->parent ) ) {
			return;
		}

		$url = edd_get_admin_url(
			array(
				'page'       => 'edd-payment-history',
				'view'       => 'view-order-details',
				'id'         => $order->id,
				'edd-action' => 'missing_subscription',
				'edd-nonce'  => wp_create_nonce( 'edd-missing-subscription-' . $order->id ),
			)
		);
		?>
		<div>
			<p><?php esc_html_e( 'It looks like this order should have a subscription in EDD, but it\'s missing. You can optionally try to recreate it automatically.', 'edd-recurring' ); ?></p>
			<a class="button button-secondary" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Create Subscription', 'edd-recurring' ); ?></a>
		</div>
		<?php
	}
}
