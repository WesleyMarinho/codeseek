<?php

namespace EDD\Recurring\Admin\Reports;

defined( 'ABSPATH' ) || exit;

use EDD\Reports;

class RevenueBreakdown {

	/**
	 * The reports registry.
	 *
	 * @var \EDD\Reports\Data\Report_Registry
	 */
	private $reports;

	/**
	 * The report ID.
	 *
	 * @var string
	 */
	private $id = 'recurring_revenue_breakdown';

	/**
	 * The label for the date range.
	 *
	 * @var string
	 */
	private $label;

	/**
	 * The date range.
	 *
	 * @var array
	 */
	private $dates;

	/**
	 * The product selected.
	 *
	 * @var array
	 */
	private $product;

	/**
	 * The SQL clauses for the query.
	 *
	 * @var array
	 */
	private $sql_clauses;

	/**
	 * The column to query.
	 *
	 * @var string
	 */
	private $column;

	/**
	 * The base colors for the charts.
	 *
	 * @var array
	 */
	private $colors = array(
		'green'  => '1,125,92',
		'blue'   => '1,96,135',
		'yellow' => '240,195,60',
		'red'    => '214,54,56',
	);

	/**
	 * Whether or not Software Licensing is enabled.
	 *
	 * @var bool
	 */
	private $sl_enabled;

	/**
	 * Registers the revenue attribution reports.
	 *
	 * @param \EDD\Reports\Data\Report_Registry $reports
	 * @return void
	 */
	public function __construct( $reports ) {
		$this->reports    = $reports;
		$options          = Reports\get_dates_filter_options();
		$dates            = Reports\get_filter_value( 'dates' );
		$this->product    = $this->get_product();
		$this->label      = $options[ $dates['range'] ];
		$this->sl_enabled = (bool) function_exists( 'edd_software_licensing' );

		try {
			$this->register_report();
			$this->register_tiles();
			$this->register_charts();
		} catch ( \Exception $e ) {
			// Do nothing.
		}

		add_action( 'edd_before_admin_filter_bar_reports', array( $this, 'maybe_filter_products' ) );
		add_action( 'edd_after_admin_filter_bar_reports', array( $this, 'remove_filter_products' ) );
	}

	/**
	 * Registers the revenue attribution top level report.
	 *
	 * @since 2.12.0
	 */
	public function register_report() {
		$this->reports->add_report(
			$this->id,
			array(
				'label'     => __( 'Revenue Breakdown', 'edd-recurring' ),
				'icon'      => 'chart-pie',
				'priority'  => 60,
				'endpoints' => array(
					'tiles'  => array_keys( $this->get_tiles() ),
					'charts' => array(
						'recurring_revenue_breakdown_chart',
						'recurring_revenue_breakdown_pie_sales',
						'recurring_revenue_breakdown_pie',
					),
				),
				'filters'   => array(
					'dates',
					'taxes',
					'currencies',
					'products',
				),
			)
		);
	}

	/**
	 * Maybe adds the filter for the products dropdown.
	 * We have to check the report ID because the action is run for a lot of different contexts.
	 *
	 * @since 2.12.0
	 * @param mixed $report
	 * @return void
	 */
	public function maybe_filter_products( $report ) {
		if ( empty( $report->object_id ) || $this->id !== $report->object_id ) {
			return;
		}
		add_filter( 'edd_product_dropdown_args', 'edd_recurring_product_dropdown_recurring_only' );
	}

	/**
	 * Removes the filter for the products dropdown.
	 * We have to check the report ID because the action is run for a lot of different contexts.
	 *
	 * @since 2.12.0
	 * @param mixed $report
	 * @return void
	 */
	public function remove_filter_products( $report ) {
		if ( empty( $report->object_id ) || $this->id !== $report->object_id ) {
			return;
		}
		remove_filter( 'edd_product_dropdown_args', 'edd_recurring_product_dropdown_recurring_only' );
	}

	/**
	 * Registers the revenue attribution tiles.
	 *
	 * @since 2.12.0
	 * @return void
	 */
	private function register_tiles() {
		foreach ( $this->get_tiles() as $tile => $args ) {
			$this->reports->register_endpoint( $tile, $args );
		}
	}

	/**
	 * Returns the tiles for the revenue attribution report.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_tiles() {
		$tiles = array(
			'recurring_revenue_breakdown_new'       => array(
				'label' => __( 'New Revenue', 'edd-recurring' ),
				'views' => array(
					'tile' => array(
						'data_callback' => array( $this, 'get_new_revenue' ),
						'display_args'  => array(
							'comparison_label' => $this->label . ' &mdash; ' . __( 'Gross', 'edd-recurring' ),
						),
					),
				),
			),
			'recurring_revenue_breakdown_recurring' => array(
				'label' => __( 'Renewal Revenue', 'edd-recurring' ),
				'views' => array(
					'tile' => array(
						'data_callback' => array( $this, 'get_renewal_revenue' ),
						'display_args'  => array(
							'comparison_label' => $this->label . ' &mdash; ' . __( 'Gross', 'edd-recurring' ),
						),
					),
				),
			),
		);

		if ( $this->sl_enabled ) {
			$tiles['recurring_revenue_breakdown_upgrades'] = array(
				'label' => __( 'Upgrade Revenue', 'edd-recurring' ),
				'views' => array(
					'tile' => array(
						'data_callback' => function () {
							global $wpdb;
							$dates = $this->get_date_objects();
							$args = array(
								'range'        => $dates['range'],
								'relative'     => true,
								'currency'     => $this->get_currency(),
								'revenue_type' => 'gross',
								'output'       => 'formatted',
								'where_sql'    => "AND total != 0
									AND id IN (
									SELECT edd_order_id
									FROM {$wpdb->edd_ordermeta} om
									WHERE {$wpdb->edd_orders}.id = om.edd_order_id
									AND meta_key = \"_edd_sl_upgraded_payment_id\"
								)",
							);

							if ( ! empty( $this->product ) ) {
								$args['where_sql'] .= $this->get_product_where_statement();
							}

							$stats = new \EDD\Stats( $args );

							return $stats->get_order_earnings();
						},
						'display_args'  => array(
							'comparison_label' => $this->label . ' &mdash; ' . __( 'Gross', 'edd-recurring' ),
						),
					),
				),
			);
		}

		return $tiles;
	}

	/**
	 * Gets the new revenue for the time period.
	 *
	 * @since 2.12.0
	 * @param string $output
	 * @return string|array
	 */
	public function get_new_revenue( $output = 'formatted' ) {
		global $wpdb;

		add_filter( 'edd_payment_stats_post_statuses', array( $this, 'new_sales_statuses_only' ), 99, 1 );

		$dates = $this->get_date_objects();

		$args = array(
			'range'         => $dates['range'],
			'function'      => 'SUM',
			'exclude_taxes' => Reports\get_taxes_excluded_filter(),
			'currency'      => $this->get_currency(),
			'relative'      => true,
			'output'        => $output,
			'revenue_type'  => 'gross',
			'where_sql'     => "
			 AND {$wpdb->edd_orders}.total != 0
			 AND {$wpdb->edd_orders}.id NOT IN(
				 SELECT om.edd_order_id
				 FROM {$wpdb->edd_ordermeta} om
				 WHERE {$wpdb->edd_orders}.id = om.edd_order_id
				 AND om.meta_key IN ( '_edd_sl_is_renewal', '_edd_sl_upgraded_payment_id' )
			 )",
		);

		if ( ! empty( $this->product ) ) {
			$args['where_sql'] .= $this->get_product_where_statement();
		}

		$stats       = new \EDD\Stats( $args );
		$new_revenue = $stats->get_order_earnings();

		remove_filter( 'edd_payment_stats_post_statuses', array( $this, 'new_sales_statuses_only' ), 99, 1 );

		return $new_revenue;
	}

	/**
	 * Gets the renewal revenue for the time period.
	 *
	 * @since 2.12.0
	 * @param string $output
	 * @return string|array
	 */
	public function get_renewal_revenue( $output = 'formatted' ) {
		global $wpdb;

		add_filter( 'edd_payment_stats_post_statuses', array( $this, 'recurring_sales_statuses_only' ), 99, 1 );

		$dates = $this->get_date_objects();

		$args = array(
			'range'         => $dates['range'],
			'function'      => 'SUM',
			'exclude_taxes' => Reports\get_taxes_excluded_filter(),
			'currency'      => $this->get_currency(),
			'relative'      => true,
			'output'        => $output,
			'revenue_type'  => 'gross',
			'where_sql'     => "
			 AND {$wpdb->edd_orders}.total != 0
			 AND {$wpdb->edd_orders}.id IN(
				 SELECT edd_order_id FROM {$wpdb->edd_ordermeta} om
				 WHERE {$wpdb->edd_orders}.id = om.edd_order_id
				 AND meta_key IN ( '_edd_sl_is_renewal', 'subscription_id' )
			 )",
		);

		if ( ! empty( $this->product ) ) {
			$args['where_sql'] .= $this->get_product_where_statement();
		}

		$stats           = new \EDD\Stats( $args );
		$renewal_revenue = $stats->get_order_earnings();

		remove_filter( 'edd_payment_stats_post_statuses', array( $this, 'recurring_sales_statuses_only' ), 99, 1 );

		return $renewal_revenue;
	}

	/**
	 * Registers the revenue attribution chart.
	 *
	 * @since 2.12.0
	 * @return void
	 */
	private function register_charts() {
		$product_label = __( 'All Products', 'edd-recurring' );

		if ( ! empty( $this->product ) ) {
			$download = edd_get_download( $this->product['download_id'] );
			if ( $download ) {
				$product_label = edd_get_download_name( $this->product['download_id'], $this->product['price_id'] );
			}
		}

		$this->reports->register_endpoint(
			'recurring_revenue_breakdown_chart',
			array(
				// translators: %s is the product label.
				'label' => sprintf( __( 'Revenue Breakdown - %s', 'edd-recurring' ), $product_label ) . ' &mdash; ' . $this->label,
				'views' => array(
					'chart' => array(
						'data_callback' => array( $this, 'new_vs_renewal_sales' ),
						'type'          => 'bar',
						'stacked'       => true,
						'options'       => array(
							'datasets' => $this->get_datasets(),
							'scales'   => array(
								'yAxes' => array(
									array(
										'id'        => 'new-y',
										'type'      => 'linear',
										'display'   => true,
										'stacked'   => true,
										'ticks'     => array(
											'formattingType' => 'format',
											'beginAtZero' => true,
											'precision'   => 0,
										),
										'gridLines' => array(
											'display' => true,
										),
									),
								),
								'xAxes' => array(
									array(
										'type'     => 'time',
										'display'  => true,
										'stacked'  => true,
										'offset'   => true,
										'ticks'    => array(
											'source'      => 'auto',
											'maxRotation' => 0,
										),
										'position' => 'bottom',
										'time'     => $this->get_time_for_axes(),
									),
								),
							),
						),
					),
				),
			)
		);

		$labels = array(
			__( 'New Sales', 'edd-recurring' ),
			__( 'Renewals', 'edd-recurring' ),
		);
		if ( $this->sl_enabled ) {
			$labels[] = __( 'Upgrades', 'edd-recurring' );
		}
		$backgrounds = array(
			"rgba({$this->colors['green']},.8)",
			"rgba({$this->colors['blue']},.8)",
			"rgba({$this->colors['yellow']},.8)",
		);
		$this->reports->register_endpoint(
			'recurring_revenue_breakdown_pie_sales',
			array(
				'label' => __( 'Sales By Type', 'edd-recurring' ) . ' &mdash; ' . $this->label,
				'views' => array(
					'chart' => array(
						'data_callback' => function () {
							$pie_pieces = array(
								absint( $this->get_new_sales_counts() ),
								absint( $this->get_renewal_counts() ),
							);
							if ( $this->sl_enabled ) {
								$pie_pieces[] = absint( $this->get_upgrade_counts() );
							}

							return array(
								'sales' => $pie_pieces,
							);
						},
						'type'          => 'pie',
						'options'       => array(
							'cutoutPercentage' => 0,
							'datasets'         => array(
								'sales' => array(
									'label'           => __( 'Sales', 'edd-recurring' ),
									'backgroundColor' => $backgrounds,
								),
							),
							'labels'           => $labels,
						),
					),
				),
			)
		);
		$this->reports->register_endpoint(
			'recurring_revenue_breakdown_pie',
			array(
				'label' => __( 'Earnings By Type', 'edd-recurring' ) . ' &mdash; ' . $this->label,
				'views' => array(
					'chart' => array(
						'data_callback' => function () {
							$pie_pieces = array(
								$this->get_new_earnings_results(),
								$this->get_renewal_results(),
							);
							if ( $this->sl_enabled ) {
								$pie_pieces[] = $this->get_upgrade_results();
							}

							$results = array();
							foreach ( $pie_pieces as $key => $piece ) {
								$results[ $key ] = 0.00;
								if ( empty( $piece ) ) {
									continue;
								}
								foreach ( $piece as $earnings ) {
									$results[ $key ] += $earnings->earnings;
								}
								$results[ $key ] = round( $results[ $key ], 2 );
							}

							return array(
								'earnings' => $results,
							);
						},
						'type'          => 'pie',
						'options'       => array(
							'cutoutPercentage' => 0,
							'datasets'         => array(
								'earnings' => array(
									'label'           => __( 'Earnings', 'edd-recurring' ),
									'backgroundColor' => $backgrounds,
									'type'            => 'currency',
								),
							),
							'labels'           => $labels,
						),
					),
				),
			)
		);
	}

	/**
	 * The callback function which fetches the data for the revenue attribution bar chart.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	public function new_vs_renewal_sales() {
		$period = $this->get_period();

		$earnings_new_results     = $this->get_new_earnings_results();
		$earnings_renewal_results = $this->get_renewal_results();

		$new_revenue       = array();
		$recurring_revenue = array();
		$upgrade_revenue   = null;

		if ( $this->sl_enabled ) {
			$upgrade_results = $this->get_upgrade_results();
			$upgrade_revenue = array();
		}

		/**
		 * Initialise all arrays with timestamps and set values to 0.
		 *
		 * We use the Chart based dates for this loop, so the graph shows in the proper date ranges while the actual DB queries are all UTC based.
		 */
		$chart_dates = $this->get_chart_dates();
		while ( strtotime( $chart_dates['start']->copy()->format( 'mysql' ) ) <= strtotime( $chart_dates['end']->copy()->format( 'mysql' ) ) ) {
			$timestamp     = $chart_dates['start']->copy()->format( 'U' );
			$date_on_chart = $chart_dates['start'];

			$new_revenue[ $timestamp ][0] = $date_on_chart->format( 'Y-m-d H:i:s' );
			$new_revenue[ $timestamp ][1] = 0;

			$recurring_revenue[ $timestamp ][0] = $date_on_chart->format( 'Y-m-d H:i:s' );
			$recurring_revenue[ $timestamp ][1] = 0.00;

			if ( ! is_null( $upgrade_revenue ) ) {
				$upgrade_revenue[ $timestamp ][0] = $date_on_chart->format( 'Y-m-d H:i:s' );
				$upgrade_revenue[ $timestamp ][1] = 0.00;
			}

			// Loop through each date there were sales/earnings, which we queried from the database.
			foreach ( $earnings_new_results as $earnings_result ) {
				$date_of_db_value = EDD()->utils->date( $earnings_result->date );

				// Add any sales/earnings that happened during this hour.
				if ( 'hour' === $period ) {
					// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
					if ( $date_of_db_value->format( 'Y-m-d H' ) === $date_on_chart->format( 'Y-m-d H' ) ) {
						$new_revenue[ $timestamp ][1] += $earnings_result->earnings;
					}
				} elseif ( 'day' === $period ) {
					// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
					if ( $date_of_db_value->format( 'Y-m-d' ) === $date_on_chart->format( 'Y-m-d' ) ) {
						$new_revenue[ $timestamp ][1] += $earnings_result->earnings;
					}
				} elseif ( $date_of_db_value->format( 'Y-m' ) === $date_on_chart->format( 'Y-m' ) ) {
					$new_revenue[ $timestamp ][1] += $earnings_result->earnings;
				}
			}

			// Loop through each date there were sales/earnings, which we queried from the database.
			foreach ( $earnings_renewal_results as $earnings_result ) {
				$date_of_db_value = EDD()->utils->date( $earnings_result->date );

				// Add any sales/earnings that happened during this hour.
				if ( 'hour' === $period ) {
					// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
					if ( $date_of_db_value->format( 'Y-m-d H' ) === $date_on_chart->format( 'Y-m-d H' ) ) {
						$recurring_revenue[ $timestamp ][1] += $earnings_result->earnings;
					}
					// Add any sales/earnings that happened during this day.
				} elseif ( 'day' === $period ) {
					// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
					if ( $date_of_db_value->format( 'Y-m-d' ) === $date_on_chart->format( 'Y-m-d' ) ) {
						$recurring_revenue[ $timestamp ][1] += $earnings_result->earnings;
					}
					// Add any sales/earnings that happened during this month.
				} elseif ( $date_of_db_value->format( 'Y-m' ) === $date_on_chart->format( 'Y-m' ) ) {
					$recurring_revenue[ $timestamp ][1] += $earnings_result->earnings;
				}
			}

			if ( $this->sl_enabled ) {
				// Loop through each date there were sales/earnings, which we queried from the database.
				foreach ( $upgrade_results as $earnings_result ) {
					$date_of_db_value = EDD()->utils->date( $earnings_result->date );

					// Add any sales/earnings that happened during this hour.
					if ( 'hour' === $period ) {
						// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
						if ( $date_of_db_value->format( 'Y-m-d H' ) === $date_on_chart->format( 'Y-m-d H' ) ) {
							$upgrade_revenue[ $timestamp ][1] += $earnings_result->earnings;
						}
						// Add any sales/earnings that happened during this day.
					} elseif ( 'day' === $period ) {
						// If the date of this db value matches the date on this line graph/chart, set the y axis value for the chart to the number in the DB result.
						if ( $date_of_db_value->format( 'Y-m-d' ) === $date_on_chart->format( 'Y-m-d' ) ) {
							$upgrade_revenue[ $timestamp ][1] += $earnings_result->earnings;
						}
						// Add any sales/earnings that happened during this month.
					} elseif ( $date_of_db_value->format( 'Y-m' ) === $date_on_chart->format( 'Y-m' ) ) {
						$upgrade_revenue[ $timestamp ][1] += $earnings_result->earnings;
					}
				}
			}

			// Move the chart along to the next hour/day/month to get ready for the next loop.
			if ( 'hour' === $period ) {
				$chart_dates['start']->addHour( 1 );
			} elseif ( 'day' === $period ) {
				$chart_dates['start']->addDays( 1 );
			} else {
				$chart_dates['start']->addMonth( 1 );
			}
		}

		$data = array(
			'new'       => array_values( $new_revenue ),
			'recurring' => array_values( $recurring_revenue ),
		);
		if ( ! is_null( $upgrade_revenue ) ) {
			$data['upgrades'] = array_values( $upgrade_revenue );
		}

		return $data;
	}

	/**
	 * Resrict the status keys to only new purchaes which do not include 'edd_subscription'.
	 *
	 * @since 2.12.0
	 * @param array $statuses
	 * @return array
	 */
	public function new_sales_statuses_only( $statuses ) {
		return array( 'complete', 'partially_refunded' );
	}

	/**
	 * Restrict statuses to only recurring sales.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	public function recurring_sales_statuses_only() {
		return array( 'edd_subscription', 'complete', 'partially_refunded' );
	}

	/**
	 * Gets the results for new earnings.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_new_earnings_results() {
		global $wpdb;
		$dates       = $this->get_date_objects();
		$sql_clauses = $this->get_sql_clauses();

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT SUM({$this->get_column()}) AS earnings, {$sql_clauses['select']}
				 FROM {$wpdb->edd_orders} edd_o
				 WHERE edd_o.date_created >= %s AND edd_o.date_created <= %s
				 AND edd_o.status IN ( 'complete', 'partially_refunded' )
				 AND edd_o.type = 'sale'
				 AND edd_o.id NOT IN (
					 SELECT edd_order_id
					 FROM {$wpdb->edd_ordermeta} om
					 WHERE edd_o.id = om.edd_order_id
					 AND om.meta_key IN ( '_edd_sl_is_renewal', '_edd_sl_upgraded_payment_id' )
				 )
				 {$sql_clauses['where']}
				 GROUP BY {$sql_clauses['groupby']}
				 ORDER BY {$sql_clauses['orderby']} ASC",
				$dates['start']->copy()->format( 'mysql' ),
				$dates['end']->copy()->format( 'mysql' )
			)
		);
	}

	/**
	 * Gets the counts for new earnings.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_new_sales_counts() {
		global $wpdb;
		$dates       = $this->get_date_objects();
		$sql_clauses = $this->get_sql_clauses();

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(edd_o.id) AS sales, {$sql_clauses['select']}
				 FROM {$wpdb->edd_orders} edd_o
				 WHERE edd_o.date_created >= %s AND edd_o.date_created <= %s
				 AND edd_o.status IN ( 'complete', 'partially_refunded' )
				 AND edd_o.type = 'sale'
				 AND edd_o.id NOT IN (
					 SELECT edd_order_id
					 FROM {$wpdb->edd_ordermeta} om
					 WHERE edd_o.id = om.edd_order_id
					 AND om.meta_key IN ( '_edd_sl_is_renewal', '_edd_sl_upgraded_payment_id' )
				 )
				 {$sql_clauses['where']}",
				$dates['start']->copy()->format( 'mysql' ),
				$dates['end']->copy()->format( 'mysql' )
			)
		);
	}

	/**
	 * Gets the results for license renewal earnings.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_renewal_results() {
		global $wpdb;
		$dates       = $this->get_date_objects();
		$sql_clauses = $this->get_sql_clauses();

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT SUM({$this->get_column()}) AS earnings, {$sql_clauses['select']}
				 FROM {$wpdb->edd_orders} edd_o
				 WHERE edd_o.date_created >= %s AND edd_o.date_created <= %s
				 AND edd_o.status IN ( 'edd_subscription', 'complete', 'partially_refunded' )
				 AND edd_o.type = 'sale'
				 AND edd_o.id IN (
					 SELECT om.edd_order_id
					 FROM {$wpdb->edd_ordermeta} om
					 WHERE edd_o.id = om.edd_order_id
					 AND edd_o.id IN(
						 SELECT om.edd_order_id
						 FROM {$wpdb->edd_ordermeta} om
						 WHERE edd_o.id = om.edd_order_id
						 AND om.meta_key IN ( '_edd_sl_is_renewal', 'subscription_id' )
					 )
				 )
				 {$sql_clauses['where']}
				 GROUP BY {$sql_clauses['groupby']}
				 ORDER BY {$sql_clauses['orderby']} ASC",
				$dates['start']->copy()->format( 'mysql' ),
				$dates['end']->copy()->format( 'mysql' )
			)
		);
	}

	/**
	 * Gets the counts for license renewal earnings.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_renewal_counts() {
		global $wpdb;
		$dates       = $this->get_date_objects();
		$sql_clauses = $this->get_sql_clauses();

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(edd_o.id) AS sales, {$sql_clauses['select']}
				 FROM {$wpdb->edd_orders} edd_o
				 WHERE edd_o.date_created >= %s AND edd_o.date_created <= %s
				 AND edd_o.status IN ( 'edd_subscription', 'complete', 'partially_refunded' )
				 AND edd_o.type = 'sale'
				 AND edd_o.id IN (
					 SELECT om.edd_order_id
					 FROM {$wpdb->edd_ordermeta} om
					 WHERE edd_o.id = om.edd_order_id
					 AND edd_o.id IN(
						 SELECT om.edd_order_id
						 FROM {$wpdb->edd_ordermeta} om
						 WHERE edd_o.id = om.edd_order_id
						 AND om.meta_key IN ( '_edd_sl_is_renewal', 'subscription_id' )
					 )
				 )
				 {$sql_clauses['where']}",
				$dates['start']->copy()->format( 'mysql' ),
				$dates['end']->copy()->format( 'mysql' )
			)
		);
	}

	/**
	 * Gets the results for upgrades.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_upgrade_results() {
		global $wpdb;
		$dates       = $this->get_date_objects();
		$sql_clauses = $this->get_sql_clauses();

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT SUM({$this->get_column()}) AS earnings, {$sql_clauses['select']}
				 FROM {$wpdb->edd_orders} edd_o
				 WHERE edd_o.date_created >= %s AND edd_o.date_created <= %s
				 AND edd_o.status IN ( 'complete', 'partially_refunded' )
				 AND edd_o.type = 'sale'
				 AND edd_o.id IN (
					 SELECT om.edd_order_id
					 FROM {$wpdb->edd_ordermeta} om
					 WHERE edd_o.id = om.edd_order_id
					 AND om.meta_key = '_edd_sl_upgraded_payment_id'
				 )
				 {$sql_clauses['where']}
				 GROUP BY {$sql_clauses['groupby']}
				 ORDER BY {$sql_clauses['orderby']} ASC",
				$dates['start']->copy()->format( 'mysql' ),
				$dates['end']->copy()->format( 'mysql' )
			)
		);
	}

	/**
	 * Gets the counts for upgrades.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_upgrade_counts() {
		global $wpdb;
		$dates       = $this->get_date_objects();
		$sql_clauses = $this->get_sql_clauses();

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(edd_o.id), {$sql_clauses['select']}
				 FROM {$wpdb->edd_orders} edd_o
				 WHERE edd_o.date_created >= %s AND edd_o.date_created <= %s
				 AND edd_o.status IN ( 'complete', 'partially_refunded' )
				 AND edd_o.type = 'sale'
				 AND edd_o.id IN (
					 SELECT om.edd_order_id
					 FROM {$wpdb->edd_ordermeta} om
					 WHERE edd_o.id = om.edd_order_id
					 AND om.meta_key = '_edd_sl_upgraded_payment_id'
				 )
				 {$sql_clauses['where']}",
				$dates['start']->copy()->format( 'mysql' ),
				$dates['end']->copy()->format( 'mysql' )
			)
		);
	}

	/**
	 * Gets the dataset properties for the bar chart.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_datasets() {
		$datasets = array(
			'new'       => array(
				'label'                => __( 'New', 'edd-recurring' ),
				'backgroundColor'      => "rgba({$this->colors['green']},.3)",
				'borderColor'          => "rgba({$this->colors['green']},.75)",
				'fill'                 => true,
				'borderWidth'          => 2,
				'type'                 => 'currency',
				'pointBackgroundColor' => 'rgb(255,255,255)',
				'yAxisID'              => 'new-y',
			),
			'recurring' => array(
				'label'                => __( 'Renewals', 'edd-recurring' ),
				'backgroundColor'      => "rgba({$this->colors['blue']},.3)",
				'borderColor'          => "rgba({$this->colors['blue']},.75)",
				'fill'                 => true,
				'borderWidth'          => 2,
				'type'                 => 'currency',
				'pointBackgroundColor' => 'rgb(255,255,255)',
				'yAxisID'              => 'new-y',
			),
		);

		if ( $this->sl_enabled ) {
			$datasets['upgrades'] = array(
				'label'                => __( 'Upgrades', 'edd-recurring' ),
				'backgroundColor'      => "rgba({$this->colors['yellow']},.3)",
				'borderColor'          => "rgba({$this->colors['yellow']},.75)",
				'fill'                 => true,
				'borderWidth'          => 2,
				'type'                 => 'currency',
				'pointBackgroundColor' => 'rgb(255,255,255)',
				'yAxisID'              => 'new-y',
			);
		}

		return $datasets;
	}

	/**
	 * Gets the time period to use for the bar chart axes.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_time_for_axes() {
		$period      = $this->get_period();
		$time_unit   = 'month';
		$time_format = 'MMM YYYY';

		if ( 'day' === $period ) {
			$time_unit   = 'day';
			$time_format = 'MMM D';
		} elseif ( 'hour' === $period ) {
			$time_unit   = 'hour';
			$time_format = 'hA';
		}

		return array(
			'unit'          => $time_unit,
			'tooltipFormat' => $time_format,
		);
	}

	/**
	 * Gets the date objects for the reports.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_date_objects() {
		if ( is_null( $this->dates ) ) {
			$this->dates = Reports\get_dates_filter( 'objects' );
		}

		return $this->dates;
	}

	/**
	 * Gets the chart dates.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_chart_dates() {
		return Reports\parse_dates_for_range( null, 'now', false );
	}

	/**
	 * Gets the column to use for the query.
	 *
	 * @since 2.12.0
	 * @return string
	 */
	private function get_column() {
		if ( is_null( $this->column ) ) {
			$this->column = Reports\get_taxes_excluded_filter() ? '(total - tax)' : 'total';
			$currency     = $this->get_currency();
			if ( empty( $currency ) || 'convert' === $currency ) {
				$this->column .= ' / rate';
			}
		}

		return $this->column;
	}

	/**
	 * Gets the SQL clauses for the query.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_sql_clauses() {
		if ( is_null( $this->sql_clauses ) ) {
			$this->sql_clauses = Reports\get_sql_clauses( $this->get_period() );
			$currency          = $this->get_currency();
			if ( ! empty( $currency ) && array_key_exists( strtoupper( $currency ), edd_get_currencies() ) ) {
				global $wpdb;
				$this->sql_clauses['where'] = $wpdb->prepare( ' AND currency = %s ', strtoupper( $currency ) );
			}

			if ( ! empty( $this->product ) ) {
				global $wpdb;

				$price_id_sql = ! is_null( $this->product['price_id'] ) ?
					$wpdb->prepare( ' AND oi.price_id = %d', $this->product['price_id'] ) :
					'';

				$this->sql_clauses['where'] .= $wpdb->prepare(
					" AND edd_o.id IN (
						SELECT oi.order_id
						FROM {$wpdb->edd_order_items} oi
						WHERE oi.product_id = %d
						{$price_id_sql}
					)",
					$this->product['download_id']
				);
			}
		}

		return $this->sql_clauses;
	}

	/**
	 * Gets the where statement for the query.
	 *
	 * This should only be used when using the Stats class, for example, in the tiles.
	 *
	 * @since 2.12.0
	 * @return string
	 */
	private function get_product_where_statement() {
		global $wpdb;

		if ( empty( $this->product ) ) {
			return '';
		}

		$price_id_sql = is_null( $this->product['price_id'] ) ?
			'' :
			" AND oi.price_id = {$this->product['price_id']}";

		$product_sql = "
			AND {$wpdb->edd_orders}.id IN (
				SELECT oi.order_id
				FROM {$wpdb->edd_order_items} oi
				WHERE {$wpdb->edd_orders}.id = oi.order_id
				AND oi.product_id = {$this->product['download_id']}
				{$price_id_sql}
			)
		";

		return $product_sql;
	}

	/**
	 * Gets the currency for the reports.
	 *
	 * @since 2.12.0
	 * @return string
	 */
	private function get_currency() {
		return Reports\get_filter_value( 'currencies' );
	}

	/**
	 * Gets the product for the reports.
	 *
	 * @since 2.12.0
	 * @return array
	 */
	private function get_product() {
		$parsed_product = edd_parse_product_dropdown_value( Reports\get_filter_value( 'products' ) );

		return ! empty( $parsed_product['download_id'] ) ? $parsed_product : array();
	}

	/**
	 * Gets the period for the reports.
	 *
	 * @since 2.12.0
	 * @return string
	 */
	private function get_period() {
		return Reports\get_graph_period();
	}
}
