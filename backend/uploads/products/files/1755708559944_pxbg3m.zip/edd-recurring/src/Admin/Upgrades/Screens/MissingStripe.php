<?php
/**
 * Creates a missing Stripe subscriptions upgrade routine.
 *
 * @package     EDD\Recurring\Admin\Upgrades\Screens
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.0
 */

namespace EDD\Recurring\Admin\Upgrades\Screens;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class MissingStripe
 *
 * @since 2.13.0
 */
class MissingStripe extends Upgrade {

	/**
	 * Gets the ID of the upgrade.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	protected function get_id(): string {
		return 'recurring_missing_stripe';
	}

	/**
	 * Gets the message for the admin notice.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	protected function get_admin_message(): string {
		return esc_html__( 'We\'ve detected that your store may need to synchronize some incorrect or missing subscription data.', 'edd-recurring' );
	}

	/**
	 * Gets the message for the upgrade notice.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	protected function get_update_message(): string {
		return __( 'This update will check for any subscriptions which are active in Stripe, but missing in EDD, and add them to your store.', 'edd-recurring' );
	}

	/**
	 * Gets the export class.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	protected function get_export_class(): string {
		return 'EDD\Recurring\Admin\Upgrades\Routines\MissingStripe';
	}

	/**
	 * Whether the upgrade is needed.
	 *
	 * @return boolean
	 */
	protected function needs_upgrade(): bool {
		$missing     = new \EDD\Recurring\Gateways\Stripe\MissingSubscription();
		$has_missing = $missing->find( array( 'limit' => 1 ) );

		return ! empty( $has_missing );
	}

	/**
	 * Gets the admin notice button text.
	 *
	 * @since 2.13.0
	 * @return string
	 */
	protected function get_admin_notice_button_text(): string {
		return __( 'Sync Subscriptions', 'edd-recurring' );
	}
}
