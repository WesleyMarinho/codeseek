<?php
/**
 * Date utility class.
 *
 * @package     EDD\Recurring\Utilities
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.1
 */

namespace EDD\Recurring\Utilities;

/**
 * Date utility class.
 *
 * @since 2.13.1
 */
class Date {

	/**
	 * Get the GMT date for a date string.
	 *
	 * @since 2.13.1
	 * @param string $date_string The date string to parse.
	 * @return string|false The date created, or false on failure.
	 */
	public static function get_gmdate_from_string( string $date_string ) {
		$timestamp = self::parse_date_string( $date_string );
		if ( false === $timestamp ) {
			return false;
		}

		return gmdate( 'Y-m-d H:i:s', $timestamp - get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
	}

	/**
	 * Parse a date string using WordPress date formats.
	 *
	 * @since 2.13.1
	 * @param string $date_string The date string to parse.
	 * @return int|false The timestamp or false on failure.
	 */
	private static function parse_date_string( string $date_string ) {
		// Try strtotime first - it's fast and handles most common formats.
		$timestamp = strtotime( $date_string );
		if ( false !== $timestamp ) {
			return $timestamp;
		}

		// If strtotime fails, try WordPress format.
		$date_format     = get_option( 'date_format' );
		$time_format     = get_option( 'time_format' );
		$datetime_format = $date_format . ' ' . $time_format;

		$datetime = self::create_datetime_from_format( $datetime_format, $date_string );
		if ( false !== $datetime ) {
			return $datetime->getTimestamp();
		}

		// Fallback to common date formats.
		$common_formats = array(
			'd/m/Y H:i',    // 19/06/2025 23:45.
			'm/d/Y H:i',    // 06/19/2025 23:45.
			'Y-m-d H:i',    // 2025-06-19 23:45.
			'd-m-Y H:i',    // 19-06-2025 23:45.
			'm-d-Y H:i',    // 06-19-2025 23:45.
			'd.m.Y H:i',    // 19.06.2025 23:45.
			'm.d.Y H:i',    // 06.19.2025 23:45.
			'F j, Y g:i A', // June 19, 2025 11:45 PM.
			'j F Y H:i',    // 19 June 2025 23:45.
		);

		foreach ( $common_formats as $format ) {
			$datetime = self::create_datetime_from_format( $format, $date_string );
			if ( false !== $datetime ) {
				return $datetime->getTimestamp();
			}
		}

		// All parsing methods failed.
		return false;
	}

	/**
	 * Create a DateTime object from a format string and validate it.
	 *
	 * @since 2.13.1
	 * @param string $format The format string.
	 * @param string $date_string The date string to parse.
	 * @return \DateTime|false The DateTime object or false on failure.
	 */
	private static function create_datetime_from_format( string $format, string $date_string ) {
		$datetime = \DateTime::createFromFormat( $format, $date_string );

		if ( false === $datetime ) {
			return false;
		}

		// Validate that the parsed date can be formatted back to the original string.
		// This catches cases where DateTime was too permissive in parsing.
		$formatted_back = $datetime->format( $format );
		if ( $formatted_back !== $date_string ) {
			return false;
		}

		return $datetime;
	}
}
