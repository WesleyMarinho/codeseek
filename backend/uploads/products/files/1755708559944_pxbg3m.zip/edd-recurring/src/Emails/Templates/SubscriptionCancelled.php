<?php

namespace EDD\Recurring\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

/**
 * Class SubscriptionCancelled
 *
 * @since 2.12.4
 * @package EDD\Recurring\Templates\Emails
 */
class SubscriptionCancelled extends EmailTemplate {

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $email_id = 'subscription_cancelled';

	/**
	 * The email recipient.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $recipient = 'customer';

	/**
	 * The email context.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $context = 'subscription';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $sender = 'recurring';

	/**
	 * Whether the email can be previewed.
	 *
	 * @since 2.12.4
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether the email can be tested.
	 *
	 * @since 2.12.4
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Name of the template.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_name() {
		return __( 'Subscription Cancelled', 'edd-recurring' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_description() {
		return __( 'This email is sent to the customer when a subscription is cancelled.', 'edd-recurring' );
	}

	/**
	 * Get the default email properties.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Subscription Cancelled', 'edd-recurring' ),
			'content' => __( "Hello {name}\n\nYour subscription for {subscription_name} has been successfully cancelled.", 'edd-recurring' ),
			'status'  => 0,
		);
	}

	/**
	 * Gets a legacy option.
	 *
	 * @since 2.12.4
	 * @param string $key The email template key.
	 * @return mixed
	 */
	protected function get_legacy( $key ) {
		if ( 'status' === $key ) {
			$options = $this->get_options();
			if ( array_key_exists( 'disabled', $options ) ) {
				return (bool) edd_get_option( $options['disabled'], 0 );
			}
		}

		return parent::get_legacy( $key );
	}

	/**
	 * Get the email properties that can be edited.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
			'status',
		);
	}

	/**
	 * Get the preview data.
	 *
	 * @since 2.12.4
	 * @return array|bool
	 */
	protected function get_preview_data() {
		$subscription = PreviewData::get_subscription();
		if ( ! $subscription ) {
			return false;
		}

		return array( $subscription->id );
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_options(): array {
		return array(
			'content'  => 'subscription_cancelled_message',
			'subject'  => 'subscription_cancelled_subject',
			'disabled' => 'enable_subscription_cancelled_email',
		);
	}
}
