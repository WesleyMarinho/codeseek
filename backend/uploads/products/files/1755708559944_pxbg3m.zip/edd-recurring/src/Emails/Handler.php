<?php

namespace EDD\Recurring\Emails;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Registry;

class Handler {

	/**
	 * Handler constructor.
	 *
	 * @since 2.12.4
	 */
	public function __construct() {
		add_action( 'edd_subscription_post_renew', array( $this, 'send_payment_received' ), 10, 4 );
		add_action( 'edd_recurring_payment_failed', array( $this, 'send_payment_failed' ) );
		add_action( 'edd_subscription_cancelled', array( $this, 'send_subscription_cancelled' ), 10, 2 );
	}

	/**
	 * Handles the renewal order received event.
	 *
	 * @since 2.12.4
	 * @param int $subscription_id
	 * @param int $expiration
	 * @param EDD_Subscription $subscription
	 * @param int $order_id
	 */
	public function send_payment_received( $subscription_id, $expiration, \EDD_Subscription $subscription, $order_id = 0 ) {
		if ( empty( $order_id ) ) {
			return;
		}
		if ( ! $this->can_send_subscription_email( $subscription ) ) {
			return;
		}

		// Customer email.
		$email = Registry::get( 'renewal_payment_received', array( $subscription_id, $order_id ) );
		$email->send();

		// Admin email.
		$email = Registry::get( 'renewal_payment_received_admin', array( $subscription_id, $order_id ) );
		$email->send();
	}

	/**
	 * Handles the renewal order failed event.
	 *
	 * @since 2.12.4
	 * @param EDD_Subscription $subscription
	 */
	public function send_payment_failed( \EDD_Subscription $subscription ) {
		if ( ! $this->can_send_subscription_email( $subscription ) ) {
			return;
		}

		$email = Registry::get( 'renewal_payment_failed', array( $subscription->id ) );
		$email->send();
	}

	/**
	 * Handles the subscription cancelled event.
	 *
	 * @since 2.12.4
	 * @param int $subscription_id
	 * @param EDD_Subscription $subscription
	 */
	public function send_subscription_cancelled( $subscription_id, \EDD_Subscription $subscription ) {
		if ( ! $this->can_send_subscription_email( $subscription ) ) {
			return;
		}

		$email = Registry::get( 'subscription_cancelled', array( $subscription_id, $subscription ) );
		$email->send();

		$admin_email = Registry::get( 'subscription_cancelled_admin', array( $subscription_id, $subscription ) );
		$admin_email->send();
	}

	/**
	 * Whether a subscription email can be sent based on customer data.
	 * This is a copy of the same method in EDD_Recurring_Emails::can_send_subscription_email().
	 *
	 * @since 2.12.4
	 * @param EDD_Subscription $subscription
	 * @return bool
	 */
	private function can_send_subscription_email( \EDD_Subscription $subscription ) {

		// If there isn't a valid email address, don't send the email.
		if ( empty( $subscription->customer->email ) ) {
			return false;
		}

		// If the customer is not active, don't send the email.
		if ( empty( $subscription->customer->status ) || 'active' !== $subscription->customer->status ) {
			return false;
		}

		// If the customer is not a user, don't send the email. Recurring payments are only supported for users.
		if ( empty( $subscription->customer->user_id ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Legacy method to send a reminder email.
	 *
	 * @param int $subscription_id
	 * @param int $notice_id
	 * @return void
	 */
	public function send_reminder( $subscription_id, $notice_id ) {
		_edd_deprecated_function( __METHOD__, '2.12.4' );
	}
}
