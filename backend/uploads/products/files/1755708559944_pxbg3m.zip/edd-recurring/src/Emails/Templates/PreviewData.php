<?php

namespace EDD\Recurring\Emails\Templates;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class PreviewData {
	use \EDD\Emails\Templates\Traits\Previews;

	/**
	 * Subscription data.
	 *
	 * @since 2.12.4
	 * @var array|bool
	 */
	private static $subscription_data;

	/**
	 * Notice data.
	 *
	 * @since 2.12.4
	 * @var array|bool
	 */
	private static $notice_data;

	/**
	 * A subscription.
	 *
	 * @since 2.12.4
	 * @var \EDD_Subscription
	 */
	private static $subscription;

	/**
	 * Gets a subscription and data.
	 *
	 * @since 2.12.4
	 * @return array|bool
	 */
	public static function get_subscription_data() {
		if ( is_null( self::$subscription_data ) ) {
			$subscription = self::get_subscription();
			if ( empty( $subscription ) ) {
				self::$subscription_data = false;
			} else {
				self::$subscription_data = array(
					$subscription->id,
					$subscription->parent_payment_id,
				);
			}
		}

		return self::$subscription_data;
	}

	/**
	 * Gets the email preview data.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	public static function get_notice_data() {
		if ( ! is_null( self::$notice_data ) ) {
			return self::$notice_data;
		}
		$subscription = self::get_subscription();
		if ( empty( $subscription ) ) {
			self::$notice_data = false;
		} else {
			self::$notice_data = array(
				$subscription->id,
				$subscription,
			);
		}

		return self::$notice_data;
	}

	/**
	 * Gets a random subscription from the database.
	 *
	 * @since 2.12.4
	 * @return false|\EDD_Subscription
	 */
	public static function get_subscription() {
		if ( ! is_null( self::$subscription ) ) {
			return self::$subscription;
		}
		$subscriptions = self::get_subscriptions();
		if ( empty( $subscriptions ) ) {
			self::$subscription = false;
		} else {
			$count              = count( $subscriptions );
			self::$subscription = $subscriptions[ wp_rand( 0, $count - 1 ) ];
		}

		return self::$subscription;
	}

	/**
	 * Retrieves the subscriptions.
	 *
	 * @since 2.12.4
	 * @return array The subscriptions.
	 */
	private static function get_subscriptions() {
		// Outside of previewing or testing, we can use the global $wpdb object to avoid loading the entire subscription object.
		if ( ! self::doing_preview() ) {
			global $wpdb;

			return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}edd_subscriptions WHERE status = 'active' LIMIT 1" );
		}

		$subscriptions_db = new \EDD_Subscriptions_DB();

		return $subscriptions_db->get_subscriptions(
			array(
				'status' => 'active',
				'number' => 10,
			)
		);
	}
}
