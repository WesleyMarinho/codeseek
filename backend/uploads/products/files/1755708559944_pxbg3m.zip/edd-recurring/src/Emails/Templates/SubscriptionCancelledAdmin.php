<?php

namespace EDD\Recurring\Emails\Templates;

defined( 'ABSPATH' ) || exit;

/**
 * Class SubscriptionCancelledAdmin
 *
 * @since 2.12.4
 * @package EDD\Recurring\Templates\Emails
 */
class SubscriptionCancelledAdmin extends SubscriptionCancelled {

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $email_id = 'subscription_cancelled_admin';

	/**
	 * The email recipient.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $recipient = 'admin';

	/**
	 * The email meta.
	 *
	 * @since 2.12.4
	 * @var array
	 */
	protected $meta = array(
		'recipients' => 'admin',
	);

	/**
	 * Description of the email.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_description() {
		return __( 'This email is sent to admins when a subscription is cancelled.', 'edd-recurring' );
	}

	/**
	 * Get the default email properties.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	public function defaults(): array {
		return array(
			'subject'    => __( 'Subscription {subscription_id} Cancelled', 'edd-recurring' ),
			'content'    => __( "Subscription ID: {subscription_id}\n\nCustomer: {name}\n\nSubscription: {subscription_name}\n\nView Subscription: {subscription_link}", 'edd-recurring' ),
			'recipients' => 'admin',
			'status'     => 0,
		);
	}

	/*Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_options(): array {
		return array(
			'content'  => 'subscription_cancelled_admin_message',
			'subject'  => 'subscription_cancelled_admin_subject',
			'disabled' => 'enable_subscription_cancelled_admin_email',
		);
	}
}
