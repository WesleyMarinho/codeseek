<?php

namespace EDD\Recurring\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

/**
 * Class Notices
 *
 * @since 2.12.4
 * @package EDD\Recurring\Templates\Emails
 */
class Notices extends EmailTemplate {

	/**
	 * The reminders object.
	 *
	 * @since 2.12.4
	 * @var \EDD_Recurring_Reminders
	 */
	protected $reminders;

	/**
	 * The array key for the reminder.
	 *
	 * @since 2.12.4
	 * @var int
	 */
	protected $key;

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 2.12.4
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 2.12.4
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * The email recipient.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $recipient = 'customer';

	/**
	 * The email context.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $context = 'subscription';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $sender = 'recurring';

	/**
	 * The email metadata.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $meta = array(
		'type'   => '',
		'period' => null,
	);

	/**
	 * Notices constructor.
	 *
	 * @param int|string $key
	 */
	public function __construct( $key = 0, $email = null ) {
		parent::__construct( $key, $email );
		$this->reminders = edd_recurring()::$reminders;
		$this->key       = str_replace( 'sub_', '', $key );
		if ( 'new' === $this->key ) {
			$this->can_view = false;
		}
		$this->email_id = 'sub_' . $this->key;
	}

	/**
	 * Name of the template.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_name() {
		return __( 'Subscription Reminder Notice', 'edd-recurring' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_description() {
		return __( 'This is a dynamic notice added by Recurring Payments. It will send to customers at the time you select.', 'edd-recurring' );
	}

	/**
	 * Gets a custom label for the email context.
	 *
	 * @return string
	 */
	public function get_context_label(): string {
		return $this->reminders->get_notice_period_label( $this->email->id );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Your Subscription is About to Renew', 'edd-recurring' ),
			'content' => sprintf(
				/* translators: 1: Name, 2: Line break, 3: Subscription name, 4: Expiration date */
				__( 'Hello %1$s,%2$sYour subscription for %3$s will renew on %4$s.', 'edd-recurring' ),
				'{name}',
				'<br><br>',
				'{subscription_name}',
				'{expiration}'
			),
			'status'  => 0,
			'period'  => '+1month',
			'type'    => 'renewal',
		);
	}

	/**
	 * The email properties that can be edited.
	 *
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'content',
			'subject',
			'status',
		);
	}

	/**
	 * Gets the row actions for the email.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	public function get_row_actions() {
		if ( ! $this->can_view ) {
			return array();
		}

		$row_actions          = parent::get_row_actions();
		$row_actions['trash'] = array(
			'text' => __( 'Delete', 'edd-recurring' ),
			'url'  => wp_nonce_url(
				edd_get_admin_url(
					array(
						'page'       => 'edd-emails',
						'edd-action' => 'recurring_delete_reminder_notice',
						'notice-id'  => $this->key,
					)
				)
			),
		);

		return $row_actions;
	}

	/**
	 * Gets the email preview data.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_preview_data() {
		$preview_data = PreviewData::get_notice_data();
		if ( ! empty( $preview_data ) ) {
			$preview_data[] = $this->get_email();
		}

		return $preview_data;
	}

	/* Legacy */
	/**
	 * Whether the email has legacy data.
	 *
	 * @since 2.12.4
	 * @var bool
	 */
	public function has_legacy_data(): bool {
		$notices = get_option( 'edd_recurring_reminder_notices', array() );

		return isset( $notices[ $this->key ] );
	}

	/**
	 * Removes the legacy data.
	 *
	 * @since 2.12.4
	 * @return void
	 */
	public function remove_legacy_data() {
		if ( ! $this->get_email()->id ) {
			return;
		}

		$notices = get_option( 'edd_recurring_reminder_notices', array() );
		if ( ! isset( $notices[ $this->key ] ) ) {
			return;
		}
		unset( $notices[ $this->key ] );
		if ( ! empty( $notices ) ) {
			update_option( 'edd_recurring_reminder_notices', $notices );
		} else {
			delete_option( 'edd_recurring_reminder_notices' );
		}
	}

	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_options(): array {
		return array();
	}

	/**
	 * Gets a legacy option.
	 *
	 * @since 2.12.4
	 * @param string $key The email template key.
	 * @return mixed
	 */
	protected function get_legacy( $key ) {
		$notices  = get_option( 'edd_recurring_reminder_notices', array() );
		$defaults = $this->defaults();
		if ( ! isset( $notices[ $this->key ] ) && array_key_exists( $key, $defaults ) ) {
			return $defaults[ $key ];
		}

		$legacy_reminders = new \EDD\Recurring\Legacy\Reminders();
		$notice           = $legacy_reminders->get_notice( absint( $this->key ) );
		if ( 'status' === $key ) {
			if ( empty( $notice['type'] ) ) {
				return false;
			}
			$enabled = $legacy_reminders->reminders_enabled();

			return array_key_exists( $notice['type'], $enabled ) ? (bool) $enabled[ $notice['type'] ] : false;
		}
		if ( 'content' === $key ) {
			return $notice['message'];
		}
		if ( 'period' === $key ) {
			return ! empty( $notice['send_period'] ) ? $notice['send_period'] : '+1month';
		}
		if ( 'type' === $key ) {
			return ! empty( $notice['type'] ) ? $notice['type'] : 'renewal';
		}

		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	}
}
