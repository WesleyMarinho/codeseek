<?php

namespace EDD\Recurring\Emails\Types;

defined( 'ABSPATH' ) || exit;

/**
 * Class PaymentFailed
 * This class extends the PaymentReceived class, because the only
 * difference between the two emails is the ID.
 *
 * @since 2.12.4
 * @package EDD
 * @subpackage Emails
 */
class PaymentFailed extends PaymentReceived {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $id = 'renewal_payment_failed';

	/**
	 * The email context.
	 *
	 * @var string
	 * @since 2.12.5
	 */
	protected $context = 'subscription';

	/**
	 * PaymentFailed constructor.
	 *
	 * @since 2.12.5
	 *
	 * @param int  $subscription_id The subscription ID.
	 * @param null $order_id        The order ID. For failed renewals, there will be no order ID.
	 */
	public function __construct( $subscription_id, $order_id = null ) {
		$this->subscription_id = $subscription_id;
		$this->subscription    = new \EDD_Subscription( $subscription_id );
		$this->email_object_id = $subscription_id;
	}

	/**
	 * Gets the legacy filters.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_legacy_filters() {
		return array(
			'subject' => 'edd_recurring_payment_failed_subject',
			'message' => 'edd_recurring_payment_failed_message',
		);
	}
}
