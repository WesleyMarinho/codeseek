<?php

namespace EDD\Recurring\Emails;

defined( 'ABSPATH' ) || exit;

use EDD\Recurring\Emails\Templates;

/**
 * Class Registry
 *
 * @since 2.12.4
 * @package EDD\Recurring\Admin\Emails
 */
class Registry {

	/**
	 * The notices.
	 *
	 * @since 2.12.4
	 * @var array
	 */
	private $notices;

	/**
	 * Registry constructor.
	 *
	 * @since 2.12.4
	 */
	public function __construct() {
		add_filter( 'edd_email_registered_templates', array( $this, 'register_email_templates' ) );
		add_filter( 'edd_email_registered_types', array( $this, 'register_email_types' ) );
		add_filter( 'edd_email_senders', array( $this, 'register_email_senders' ) );
		add_filter( 'edd_email_contexts', array( $this, 'register_email_contexts' ) );
		add_filter( 'edd_email_add_new_actions', array( $this, 'get_add_action' ) );
		add_action( 'edd_email_editor_form', array( $this, 'add_email_period' ) );
		add_filter( 'edd_email_manager_save_email_id', array( $this, 'save_id' ), 10, 3 );
		add_action( 'edd_email_added', array( $this, 'update_email_meta' ), 10, 2 );
		add_action( 'edd_email_updated', array( $this, 'update_email_meta' ), 10, 2 );
		add_filter( 'edd_emails_logs_table_object', array( $this, 'logs_table_object' ), 10, 2 );
		add_filter( 'edd_email_tags', array( $this, 'register_email_tags' ) );
	}

	/**
	 * Registers the email templates.
	 *
	 * @since 2.12.4
	 * @param array $emails
	 * @return array
	 */
	public function register_email_templates( $emails ) {
		$emails['renewal_payment_received']       = Templates\PaymentReceived::class;
		$emails['renewal_payment_received_admin'] = Templates\PaymentReceivedAdmin::class;
		$emails['renewal_payment_failed']         = Templates\PaymentFailed::class;
		$emails['subscription_cancelled']         = Templates\SubscriptionCancelled::class;
		$emails['subscription_cancelled_admin']   = Templates\SubscriptionCancelledAdmin::class;

		$notices = $this->get_notices();
		if ( ! empty( $notices ) ) {
			foreach ( $notices as $key ) {
				$emails[ $key ] = Templates\Notices::class;
			}
		}
		$emails['sub_new'] = Templates\Notices::class;

		return $emails;
	}

	/**
	 * Registers the email types.
	 *
	 * @since 2.12.4
	 * @param array $types
	 * @return array
	 */
	public function register_email_types( $types ) {
		$types['renewal_payment_received']       = Types\PaymentReceived::class;
		$types['renewal_payment_received_admin'] = Types\PaymentReceivedAdmin::class;
		$types['renewal_payment_failed']         = Types\PaymentFailed::class;
		$types['subscription_cancelled']         = Types\SubscriptionCancelled::class;
		$types['subscription_cancelled_admin']   = Types\SubscriptionCancelledAdmin::class;

		$notices = $this->get_notices();
		foreach ( $notices as $key ) {
			$types[ $key ] = Types\Notices::class;
		}

		return $types;
	}

	/**
	 * Registers the email senders.
	 *
	 * @since 2.12.4
	 * @param array $senders
	 * @return array
	 */
	public function register_email_senders( $senders ) {
		$senders['recurring'] = __( 'Recurring Payments', 'edd-recurring' );

		return $senders;
	}

	/**
	 * Registers the email contexts.
	 *
	 * @since 2.12.4
	 * @param array $contexts
	 * @return array
	 */
	public function register_email_contexts( $contexts ) {
		$contexts['subscription'] = __( 'Subscription', 'edd-recurring' );

		return $contexts;
	}

	/**
	 * Gets the action to add a new email.
	 *
	 * @since 2.12.4
	 * @param array $actions The array of "add new" actions.
	 */
	public function get_add_action( $actions ) {
		$actions['sub_new'] = __( 'Add Subscription Reminder', 'edd-recurring' );

		return $actions;
	}

	/**
	 * Adds the email period field.
	 *
	 * @since 2.12.4
	 * @param \EDD\Emails\Email $email
	 */
	public function add_email_period( $email ) {
		if ( 'recurring' !== $email->sender ) {
			return;
		}
		if ( ! array_key_exists( 'type', $email->meta ) ) {
			return;
		}
		$type        = $email->get_metadata( 'type' );
		$send_period = $email->get_metadata( 'period' );
		?>
		<div class="edd-form-group">
			<label for="edd-notice-period"><?php esc_html_e( 'Reminder Type', 'edd-recurring' ); ?></label>
			<div class="edd-form-group__control">
				<select name="type" id="edd-notice-type">
					<?php foreach ( edd_recurring()::$reminders->get_notice_types() as $notice_type => $label ) : ?>
						<option value="<?php echo esc_attr( $notice_type ); ?>"<?php selected( $type, $notice_type ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<p class="description"><?php esc_html_e( 'Renewal notices are sent only to active subscriptions.', 'edd-recurring' ); ?></p>
		</div>
		<div class="edd-form-group">
			<label for="edd-notice-period"><?php esc_html_e( 'Schedule Send', 'edd-recurring' ); ?></label>
			<div class="edd-form-group__control">
				<select name="period" id="edd-notice-period">
					<?php foreach ( edd_recurring()::$reminders->get_notice_periods() as $period => $label ) : ?>
						<option value="<?php echo esc_attr( $period ); ?>"<?php selected( $period, $send_period ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<?php
	}

	/**
	 * Saves the email ID. This only runs if the emails are registered with Berlin.
	 * This generates a unique ID for the new email.
	 *
	 * @since 2.12.4
	 * @param string                    $email_id
	 * @param \EDD\Emails\EmailTemplate $email_template
	 * @param array                     $data
	 * @return string|null
	 */
	public function save_id( $email_id, $email_template, $data ) {
		if ( 'recurring' !== $email_template->sender ) {
			return $email_id;
		}

		if ( 'sub_new' === $email_id ) {
			return \EDD\Admin\Emails\Manager::get_new_id( 'sub', $email_id );
		}

		return $email_id;
	}

	/**
	 * Updates the email meta when emails are registered with Berlin.
	 *
	 * @since 2.12.4
	 * @param int|string $id
	 * @param array      $data
	 */
	public function update_email_meta( $id, $data = array() ) {
		if ( empty( $data['sender'] ) || 'recurring' !== $data['sender'] ) {
			return;
		}
		if ( empty( $data['type'] ) ) {
			return;
		}
		$type = array_key_exists( $data['type'], edd_recurring()::$reminders->get_notice_types() ) ? $data['type'] : 'renewal';
		edd_update_email_meta( $id, 'type', $type );
		$period = array_key_exists( $data['period'], edd_recurring()::$reminders->get_notice_periods() ) ? $data['period'] : '+1month';
		edd_update_email_meta( $id, 'period', $period );
	}

	/**
	 * Modifies the object ID in the logs table.
	 *
	 * @since 2.12.4
	 * @param int                  $object_id
	 * @param \EDD\Emails\LogEmail $item
	 * @return string
	 */
	public function logs_table_object( $object_id, $item ) {
		if ( 'subscription' !== $item->object_type ) {
			return $object_id;
		}

		$subscription = new \EDD_Subscription( $item->object_id );
		$url          = edd_get_admin_url(
			array(
				'page' => 'edd-subscriptions',
				'id'   => absint( $subscription->id ),
			)
		);

		return sprintf(
			'<a href="%s">%s</a>',
			esc_url( $url ),
			/* translators: %s: Subscription ID */
			esc_html( sprintf( __( 'Subscription #%s', 'edd-recurring' ), $subscription->id ) )
		);
	}

	/**
	 * Adds the subscription context to some user email tags.
	 *
	 * @since 2.12.4
	 * @param array $tags An array of email tags.
	 */
	public function register_email_tags( $tags ) {
		$name_tags = array( 'fullname', 'username', 'user_email' );
		foreach ( $tags as &$tag ) {
			if ( in_array( $tag['tag'], $name_tags, true ) && isset( $tag['contexts'] ) ) {
				$tag['contexts'][] = 'subscription';
			}
		}

		return $tags;
	}

	/**
	 * Gets the notices.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	private function get_notices() {
		if ( ! isset( $this->notices ) ) {
			// Get notices from the database.
			$notices = $this->get_rows();

			// Get notices saved as options.
			$legacy_notices = get_option( 'edd_recurring_reminder_notices', array() );
			if ( $legacy_notices ) {
				foreach ( $legacy_notices as $key => $notice ) {
					if ( ! in_array( "sub_{$key}", $notices, true ) ) {
						$notices[] = "sub_{$key}";
					}
				}
			}
			$this->notices = $notices;
		}

		return $this->notices;
	}

	/**
	 * Gets the saved emails.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	private function get_rows() {
		$notices    = array();
		$new_emails = edd_get_emails(
			array(
				'sender'     => 'recurring',
				'context'    => 'subscription',
				'meta_query' => array(
					array(
						'key'     => 'type',
						'value'   => array( 'notice', 'renewal', 'expiration' ),
						'compare' => 'IN',
					),
				),
			)
		);
		if ( empty( $new_emails ) ) {
			return $notices;
		}

		foreach ( $new_emails as $email ) {
			if ( false !== strpos( $email->email_id, 'sub_' ) ) {
				$notices[] = $email->email_id;
			}
		}

		return $notices;
	}
}
