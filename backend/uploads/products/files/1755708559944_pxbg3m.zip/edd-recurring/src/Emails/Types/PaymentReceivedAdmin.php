<?php

namespace EDD\Recurring\Emails\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class PaymentReceived
 *
 * @since 2.12.5
 * @package EDD
 * @subpackage Emails
 */
class PaymentReceivedAdmin extends PaymentReceived {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.12.5
	 */
	protected $id = 'renewal_payment_received_admin';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 2.12.5
	 */
	protected $recipient_type = 'admin';

	/**
	 * Set the email to address.
	 *
	 * @since 2.12.5
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$this->send_to = $this->get_email()->get_admin_recipient_emails( $this->order );
	}

	/**
	 * Gets the legacy filters.
	 *
	 * @since 2.12.5
	 * @return array
	 */
	protected function get_legacy_filters() {
		return array();
	}
}
