<?php
/**
 * Payment Received Email
 *
 * @package   EDD\Recurring\Emails\Types
 * @copyright Copyright (c) 2024, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.12.4
 */

namespace EDD\Recurring\Emails\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Emails\Types\Email;

/**
 * Class PaymentReceived
 *
 * @since 2.12.4
 * @package EDD
 * @subpackage Emails
 */
class PaymentReceived extends Email {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $id = 'renewal_payment_received';

	/**
	 * The email context.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $context = 'order';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $recipient_type = 'customer';

	/**
	 * The subscription ID.
	 *
	 * @since 2.12.4
	 * @var int
	 */
	protected $subscription_id;

	/**
	 * The expiration date.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	private $expiration;

	/**
	 * The subscription object.
	 *
	 * @since 2.12.4
	 * @var \EDD_Subscription
	 */
	protected $subscription;

	/**
	 * The order ID.
	 *
	 * @since 2.12.4
	 * @var int
	 */
	protected $order_id;

	/**
	 * The order object.
	 *
	 * @since 2.12.4
	 * @var \EDD\Orders\Order
	 */
	protected $order;

	/**
	 * PaymentReceived constructor.
	 *
	 * @since 2.12.4
	 *
	 * @param int              $subscription_id The subscription ID.
	 * @param string           $expiration      The expiration date.
	 * @param \EDD_Subscription $subscription    The subscription object.
	 * @param int              $order_id        The order ID.
	 */
	public function __construct( $subscription_id, $order_id = null ) {
		$this->subscription_id = $subscription_id;
		$this->subscription    = new \EDD_Subscription( $subscription_id );
		if ( $order_id ) {
			$this->order_id        = $order_id;
			$this->order           = edd_get_order( $order_id );
			$this->email_object_id = $order_id;
		} else {
			// If no order ID is passed, use the subscription ID as the email object ID.
			$this->email_object_id = $subscription_id;
			$this->context         = 'subscription';
		}
	}

	/**
	 * Set the email to address.
	 *
	 * @since 2.12.4
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$this->send_to = $this->subscription->customer->email;
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.12.4
	 *
	 * @return void
	 */
	protected function set_subject() {
		$this->subject = $this->do_tags( 'subject', $this->get_email()->subject );
	}

	/**
	 * Set the email message.
	 *
	 * @since 2.12.4
	 *
	 * @return void
	 */
	protected function set_message() {
		$message       = $this->maybe_apply_autop( $this->get_raw_body_content() );
		$this->message = $this->do_tags( 'message', $message );
	}

	/**
	 * Gets the legacy filters.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_legacy_filters() {
		return array(
			'subject' => 'edd_recurring_payment_received_subject',
			'message' => 'edd_recurring_payment_received_message',
		);
	}

	/**
	 * Applies tags to the given property and content.
	 *
	 * @since 2.12.5
	 *
	 * @param string $property The property to apply tags to.
	 * @param string $content The content to apply tags to.
	 * @return void
	 */
	protected function do_tags( $property, $content ) {
		$content = $this->maybe_apply_legacy_filter( $property, $content );
		if ( $this->order_id ) {
			$content = $this->process_tags( $content, $this->order_id, $this->order, 'order' );
		} else {
			$customer = edd_get_customer( $this->subscription->customer_id );
			if ( $customer ) {
				$content = $this->process_tags( $content, $customer->user_id, null, 'user' );
			}
		}

		$content = $this->process_tags( $content, $this->subscription_id, $this->subscription, 'subscription' );
		if ( $this->order ) {
			/**
			 * Filters the payment received email template tags.
			 *
			 * @param string $content         The text to be parsed.
			 * @param string $amount          The payment amount.
			 * @param int    $subscription_id The subscription ID.
			 */
			return apply_filters( 'edd_recurring_payment_received_template_tags', $content, $this->order->total, $this->subscription->id );
		}

		return $content;
	}

	/**
	 * Maybe apply the legacy filter.
	 *
	 * @since 2.12.4
	 * @param string $property
	 * @param string $content
	 * @return string
	 */
	private function maybe_apply_legacy_filter( $property, $content ) {
		$legacy_filters = $this->get_legacy_filters();
		if ( array_key_exists( $property, $legacy_filters ) && has_filter( $legacy_filters[ $property ] ) ) {
			return apply_filters( $legacy_filters[ $property ], $content );
		}

		return $content;
	}
}
