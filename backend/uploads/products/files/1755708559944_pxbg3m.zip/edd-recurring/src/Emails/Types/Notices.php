<?php
/**
 * Recurring Notices Email Type.
 *
 * @package   EDD\Recurring\Emails\Types
 * @copyright Copyright (c) 2024, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.12.4
 */

namespace EDD\Recurring\Emails\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Emails\Types\Email;

/**
 * Class Notices
 *
 * @since 2.12.4
 * @package EDD\Recurring\Emails\Types
 */
class Notices extends Email {

	/**
	 * The email context.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $context = 'subscription';

	/**
	 * The email recipient type.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $recipient_type = 'customer';

	/**
	 * The reminders object.
	 *
	 * @since 2.12.4
	 * @var \EDD_Recurring_Reminders
	 */
	protected $reminders;

	/**
	 * The array key for the reminder.
	 *
	 * @since 2.12.4
	 * @var int
	 */
	protected $key;

	/**
	 * Subscription ID (for preview data).
	 * @var int
	 */
	private $subscription_id;

	/**
	 * Subscription object (for preview data).
	 * @var string
	 */
	private $subscription;

	/**
	 * Notices constructor.
	 *
	 * @param int               $subscription_id
	 * @param \EDD_Subscription $subscription
	 * @param \EDD\Emails\Email $notice
	 */
	public function __construct( $subscription_id, $subscription, $notice ) {
		$this->reminders       = edd_recurring()::$reminders;
		$this->subscription_id = $subscription_id;
		$this->subscription    = $subscription;
		$this->email           = $notice;
		$this->id              = $this->email->email_id;
		$this->email_object_id = $subscription_id;
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.12.5
	 * @return void
	 */
	protected function set_subject() {
		$this->subject = $this->process_tags( $this->get_email()->subject, $this->subscription_id, $this->subscription );
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.12.4
	 *
	 * @return void
	 */
	protected function set_message() {
		$message = $this->maybe_apply_autop( $this->get_raw_body_content() );
		$message = $this->process_tags( $message, $this->subscription_id, $this->subscription );

		/**
		 * Filter the reminder template tags.
		 *
		 * @param string $message The reminder message.
		 * @param int    $subscription_id The subscription ID.
		 */
		$this->message = apply_filters( 'edd_recurring_filter_reminder_template_tags', $message, $this->subscription_id );
	}

	/**
	 * Set the email to email.
	 *
	 * @since 2.12.4
	 * @return void
	 */
	protected function set_to_email() {
		if ( empty( $this->send_to ) ) {
			$customer      = edd_get_customer( $this->subscription->customer_id );
			$this->send_to = $customer->email;
		}
	}

	/**
	 * Whether the email should send.
	 *
	 * @return bool
	 */
	protected function should_send() {
		if ( ! parent::should_send() ) {
			return false;
		}

		return $this->can_send_reminder();
	}

	/**
	 * Whether a subscription reminder can be sent.
	 *
	 * @since 2.11.10
	 * @since 2.12.4 Added to email type class.
	 * @return bool
	 */
	private function can_send_reminder() {
		$status = $this->subscription->get_status();
		$type   = $this->get_notice_type();
		if ( 'cancelled' === $status ) {
			if ( 'renewal' === $type || $this->subscription_is_refunded() ) {
				edd_debug_log( 'Ignored renewal notice for subscription ID ' . $this->subscription_id . ' due to subscription being cancelled.' );

				return false;
			}
		}

		// Ensure the subscription should renew based on payments made and bill times.
		if ( 'renewal' === $type && ! empty( $this->subscription->bill_times ) && $this->subscription->get_total_payments() >= $this->subscription->bill_times ) {
			edd_debug_log( 'Ignored renewal notice for subscription ID ' . $this->subscription_id . ' due to billing times being complete.' );

			return false;
		}

		// Ensure an expiration notice isn't sent to an auto-renew subscription.
		if ( 'expiration' === $type && 'active' === $status && ( $this->subscription->get_total_payments() < $this->subscription->bill_times || empty( $this->subscription->bill_times ) ) ) {
			edd_debug_log( 'Ignored expiration notice for subscription ID ' . $this->subscription_id . ' due to subscription being active.' );

			return false;
		}

		// Ensure an expiration notice isn't sent to a still-trialling subscription.
		if ( 'expiration' === $type && 'trialling' === $status ) {
			edd_debug_log( 'Ignored expiration notice for subscription ID ' . $this->subscription_id . ' due to subscription still trialling.' );

			return false;
		}

		edd_debug_log( 'Renewal reminder not previously sent for subscription ID ' . $this->subscription_id . ' for reminder ' . $this->email->email_id );

		/**
		 * Filter whether a subscription reminder can be sent.
		 * This filter is used to determine if a subscription reminder should be sent.
		 * This is somewhat backwards compatible with the old filter, but the notice ID is now the email object ID.
		 *
		 * @since 2.12.4
		 * @param bool                               $can_send        Whether the reminder can be sent.
		 * @param int                                $subscription_id The subscription ID.
		 * @param int                                $notice_id       The notice ID.
		 * @param EDD\Recurring\Emails\Types\Notices $notices         The notices object.
		 */
		return apply_filters( 'edd_recurring_send_reminder', true, $this->subscription_id, $this->email->email_id, $this );
	}

	/**
	 * Get the notice type.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	private function get_notice_type() {
		$type = edd_get_email_meta( $this->email->id, 'type', true );

		return ! empty( $type ) ? $type : 'renewal';
	}

	/**
	 * Checks if a subscription is considered refunded based on the most recent order status.
	 *
	 * @since 2.11.10
	 * @since 2.12.4 Added to email type class.
	 * @return bool
	 */
	private function subscription_is_refunded() {

		// Get the most recent order for this subscription.
		$renewal_orders = $this->subscription->get_renewal_orders(
			array(
				'number'  => 1,
				'order'   => 'DESC',
				'orderby' => 'date_created',
			)
		);
		if ( ! empty( $renewal_orders ) ) {
			$order = reset( $renewal_orders );
			if ( in_array( $order->status, array( 'refunded', 'partially_refunded' ), true ) ) {
				return true;
			}
		}

		$original_order = edd_get_order( $this->subscription->parent_payment_id );

		return (bool) 'refunded' === $original_order->status;
	}
}
