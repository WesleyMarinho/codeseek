<?php
/**
 * Subscriptions trait for recurring email reminders.
 *
 * @package     EDD\Recurring\Emails\Traits
 * @copyright   Copyright (c) 2025, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.13.1
 */

namespace EDD\Recurring\Emails\Traits;

trait Subscriptions {

	/**
	 * Retrieve reminder notice periods.
	 *
	 * @since 2.4
	 * @return array Subscribers whose subscriptions are renewing or expiring within the defined period.
	 */
	public function get_reminder_subscriptions( $period = '+1month', $type = false ) {

		if ( ! $type ) {
			return array();
		}

		$args = array();

		switch ( $type ) {
			case 'renewal':
				$current_utc_datetime         = new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) );
				$target_start_datetime_string = '';

				if ( preg_match( '/^\\+(\\d+)months?$/', $period, $matches ) ) {
					$num_months = (int) $matches[1];

					$is_today_last_day_of_month = ( $current_utc_datetime->format( 'j' ) === $current_utc_datetime->format( 't' ) );

					// Determine the first day of the month for the current date, then add the specified number of months.
					// This gives us the first day of the target month.
					$first_day_of_target_month           = $current_utc_datetime->modify( 'first day of this month' )->modify( "+$num_months months" );
					$last_day_of_target_month_day_number = (int) $first_day_of_target_month->format( 't' );

					$target_day_number = 0;
					if ( $is_today_last_day_of_month ) {
						// If today is the last day of the current month, the target day is the last day of the target month.
						$target_day_number = $last_day_of_target_month_day_number;
					} else {
						// Otherwise, the target day is today's day number,
						// capped at the number of days in the target month.
						$target_day_number = (int) $current_utc_datetime->format( 'j' );
						if ( $target_day_number > $last_day_of_target_month_day_number ) {
							$target_day_number = $last_day_of_target_month_day_number;
						}
					}
					// Construct the target date string using the year and month from $first_day_of_target_month, and the calculated $target_day_number.
					$target_start_datetime_string = $first_day_of_target_month->format( 'Y-m-' ) . str_pad( (string) $target_day_number, 2, '0', STR_PAD_LEFT ) . ' 00:00:00';

				} else {
					// For other periods (e.g., +Ndays, +Nweeks), calculate normally relative to today (UTC).
					$target_start_datetime_object = $current_utc_datetime->modify( $period );
					// Ensure it's set to midnight for consistency with how DAY_IN_SECONDS is used later.
					$target_start_datetime_string = $target_start_datetime_object->format( 'Y-m-d' ) . ' 00:00:00';
				}

				$args['renewal'] = array(
					'number'     => 99999,
					'status'     => 'active',
					'expiration' => array(
						'start' => $target_start_datetime_string, // This is 'Y-m-d H:i:s' at midnight UTC.
						'end'   => gmdate( 'Y-m-d H:i:s', strtotime( $target_start_datetime_string ) + ( DAY_IN_SECONDS - 1 ) ),
					),
				);
				break;

			case 'expiration':
				$reference_datetime = new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) );
				$target_datetime    = $reference_datetime->modify( $period ); // e.g., today.modify('-1 week').

				// The $target_datetime is the date we are interested in (e.g., exactly one week ago).
				// We want to find subscriptions that expired on this $target_datetime, from its midnight to its 23:59:59.
				$query_start_time = $target_datetime->format( 'Y-m-d' ) . ' 00:00:00'; // Midnight UTC of the target date.

				$query_end_time_timestamp = strtotime( $query_start_time ) + ( DAY_IN_SECONDS - 1 );
				$query_end_time_formatted = gmdate( 'Y-m-d H:i:s', $query_end_time_timestamp ); // End of day UTC of the target date.

				$args['expiration'] = array(
					'number'     => 99999,
					'expiration' => array(
						'start' => $query_start_time,
						'end'   => $query_end_time_formatted,
					),
				);
				break;
		}

		$args = apply_filters( 'edd_recurring_reminder_subscription_args', $args );

		$subs_db       = new \EDD_Subscriptions_DB();
		$subscriptions = $subs_db->get_subscriptions( $args[ $type ] );

		if ( ! empty( $subscriptions ) ) {
			return $subscriptions;
		}

		return array();
	}
}
