<?php

namespace EDD\Recurring\Emails\Templates;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Class PaymentReceivedAdmin
 *
 * @since 2.12.5
 * @package EDD\Recurring\Templates\Emails
 */
class PaymentReceivedAdmin extends PaymentReceived {

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 2.12.5
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 2.12.5
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.12.5
	 * @var string
	 */
	protected $email_id = 'renewal_payment_received_admin';

	/**
	 * The email recipient.
	 *
	 * @since 2.12.5
	 * @var string
	 */
	protected $recipient = 'admin';

	/**
	 * The email meta.
	 *
	 * @since 2.12.4
	 * @var array
	 */
	protected $meta = array(
		'recipients' => '',
	);

	/**
	 * Name of the template.
	 *
	 * @since 2.12.5
	 * @return string
	 */
	public function get_name() {
		return __( 'Admin Renewal Notification', 'edd-recurring' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.12.5
	 * @return string
	 */
	public function get_description() {
		return __( 'This email is sent to an admin when a renewal order is successfully processed.', 'edd-recurring' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.12.5
	 * @return string
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Renewal Payment Received', 'edd-recurring' ),
			'content' => $this->get_default_content(),
			'status'  => 0,
		);
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 2.12.5
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
			'status',
			'recipient',
		);
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.12.5
	 * @return array
	 */
	protected function get_options(): array {
		return array();
	}

	/**
	 * Gets the default content for this email.
	 *
	 * @since 2.12.5
	 * @return string
	 */
	private function get_default_content() {
		$content  = __( 'A renewal order in the amount of {amount} for {subscription_name} has been successfully processed.', 'edd-recurring' );
		$content .= "\n\n";
		$content .= __( 'Subscription Details:', 'edd-recurring' );
		$content .= "\n";
		$content .= sprintf(
			/* translators: 1. the email tag for the link to the order details, 2. the order ID */
			__( '<a href="%1$s">Order ID</a>: %2$s', 'edd-recurring' ),
			'{order_details_link}',
			'{payment_id}'
		);
		$content .= "\n";
		$content .= __( 'Customer:', 'edd-recurring' ) . ' {fullname}';

		return $content;
	}
}
