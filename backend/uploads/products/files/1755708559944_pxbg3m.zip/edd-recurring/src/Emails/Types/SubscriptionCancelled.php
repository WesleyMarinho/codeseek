<?php

namespace EDD\Recurring\Emails\Types;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Types\Email;

/**
 * Class SubscriptionCancelled
 *
 * @since 2.12.4
 * @package EDD
 * @subpackage Emails
 */
class SubscriptionCancelled extends Email {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $id = 'subscription_cancelled';

	/**
	 * The email context.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $context = 'subscription';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $recipient_type = 'customer';

	/**
	 * The subscription ID.
	 *
	 * @since 2.12.4
	 * @var int
	 */
	protected $subscription_id;

	/**
	 * The subscription object.
	 *
	 * @since 2.12.4
	 * @var \EDD_Subscription
	 */
	protected $subscription;

	/**
	 * SubscriptionCancelled constructor.
	 *
	 * @since 2.12.4
	 *
	 * @param int                                       $subscription_id The subscription ID.
	 * @param \EDD\Recurring\Subscriptions\Subscription $subscription    The subscription object.
	 */
	public function __construct( $subscription_id, $subscription = null ) {
		$this->subscription_id = $subscription_id;
		if ( ! $subscription instanceof \EDD\Recurring\Subscriptions\Subscription ) {
			$this->subscription = new \EDD\Recurring\Subscriptions\Subscription( $subscription_id );
		} else {
			$this->subscription = $subscription;
		}
	}

	/**
	 * Set the email to address.
	 *
	 * @since 2.12.4
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$this->send_to = $this->subscription->customer->email;
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.12.4
	 *
	 * @return void
	 */
	protected function set_subject() {
		$subject       = $this->maybe_apply_legacy_filter( 'subject', $this->get_email()->subject );
		$subject       = $this->process_tags( $subject, $this->subscription->parent_payment_id, null, 'order' );
		$subject       = $this->process_tags( $subject, $this->subscription_id, $this->subscription, 'subscription' );
		$this->subject = $subject;
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.12.4
	 *
	 * @return void
	 */
	protected function set_message() {
		$message       = $this->maybe_apply_autop( $this->maybe_apply_legacy_filter( 'message', $this->get_raw_body_content() ) );
		$message       = $this->process_tags( $message, $this->subscription->parent_payment_id, null, 'order' );
		$message       = $this->process_tags( $message, $this->subscription_id, $this->subscription, 'subscription' );
		$this->message = $message;
	}

	/**
	 * Gets the legacy filters.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_legacy_filters() {
		return array(
			'subject' => 'edd_recurring_subscription_cancelled_subject',
			'message' => 'edd_recurring_subscription_cancelled_message',
		);
	}

	/**
	 * Maybe apply the legacy filter.
	 *
	 * @since 2.12.4
	 * @param string $property
	 * @param string $content
	 * @return string
	 */
	private function maybe_apply_legacy_filter( $property, $content ) {
		$legacy_filters = $this->get_legacy_filters();
		if ( array_key_exists( $property, $legacy_filters ) && has_filter( $legacy_filters[ $property ] ) ) {
			return apply_filters( $legacy_filters[ $property ], $content );
		}

		return $content;
	}
}
