<?php

namespace EDD\Recurring\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

/**
 * Class PaymentFailed
 *
 * @since 2.12.4
 * @package EDD\Recurring\Templates\Emails
 */
class PaymentFailed extends PaymentReceived {

	/**
	 * The email context.
	 *
	 * @since 2.12.5
	 * @var string
	 */
	protected $context = 'subscription';

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	protected $email_id = 'renewal_payment_failed';

	/**
	 * Name of the template.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_name() {
		return __( 'Renewal Payment Failed', 'edd-recurring' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_description() {
		return __( 'This email is sent when a renewal payment fails to be processed.', 'edd-recurring' );
	}

	/**
	 * Gets the email context label.
	 * The context for this email is actually a subscription, but the
	 * triggering event is an order, so we will show that instead.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_context_label(): string {
		return __( 'Renewal Order', 'edd-recurring' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Renewal Payment Failed', 'edd-recurring' ),
			'content' => __( "Hello {name}\n\nYour renewal payment in the amount of {amount} for {subscription_name} has been failed to be processed.", 'edd-recurring' ),
			'status'  => 0,
		);
	}

	/**
	 * Gets the email object.
	 *
	 * @since 2.12.5
	 * @return \EDD\Emails\Email
	 */
	public function get_email() {
		$this->email = parent::get_email();
		if ( 'order' === $this->email->context ) {
			edd_update_email(
				$this->email->id,
				array(
					'context' => 'subscription',
				)
			);
		}

		return $this->email;
	}

	/**
	 * Gets the preview data for this email.
	 *
	 * @since 2.12.5
	 * @return array
	 */
	protected function get_preview_data() {
		$subscription = PreviewData::get_subscription();

		return ! empty( $subscription ) ? array( $subscription->id ) : false;
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_options(): array {
		return array(
			'content'  => 'payment_failed_message',
			'subject'  => 'payment_failed_subject',
			'disabled' => 'enable_payment_failed_email',
		);
	}
}
