<?php

namespace EDD\Recurring\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

/**
 * Class PaymentReceived
 *
 * @since 2.12.4
 * @package EDD\Recurring\Templates\Emails
 */
class PaymentReceived extends EmailTemplate {

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 2.12.4
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 2.12.4
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $email_id = 'renewal_payment_received';

	/**
	 * The email recipient.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $recipient = 'customer';

	/**
	 * The email context.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $context = 'order';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 2.12.4
	 * @var string
	 */
	protected $sender = 'recurring';

	/**
	 * Name of the template.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_name() {
		return __( 'Renewal Payment Received', 'edd-recurring' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_description() {
		return __( 'This email is sent when a renewal order is successfully processed.', 'edd-recurring' );
	}

	/**
	 * Gets the email context label.
	 * The context for this email is actually a subscription, but the
	 * triggering event is an order, so we will show that instead.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function get_context_label(): string {
		return __( 'Renewal Order', 'edd-recurring' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.12.4
	 * @return string
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Renewal Payment Received', 'edd-recurring' ),
			'content' => __( "Hello {name}\n\nYour renewal payment in the amount of {amount} for {subscription_name} has been successfully processed.", 'edd-recurring' ),
			'status'  => 0,
		);
	}

	/**
	 * Gets a legacy option.
	 *
	 * @since 2.12.4
	 * @param string $key The email template key.
	 * @return mixed
	 */
	protected function get_legacy( $key ) {
		if ( 'status' === $key ) {
			$options = $this->get_options();
			if ( array_key_exists( 'disabled', $options ) ) {
				global $edd_options;
				return (bool) ! empty( $edd_options[ $options['disabled'] ] );
			}
		}

		return parent::get_legacy( $key );
	}

	/**
	 * Gets the preview data for this email.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_preview_data() {
		return PreviewData::get_subscription_data();
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
			'status',
		);
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.12.4
	 * @return array
	 */
	protected function get_options(): array {
		return array(
			'content'  => 'payment_received_message',
			'subject'  => 'payment_received_subject',
			'disabled' => 'enable_payment_received_email',
		);
	}
}
