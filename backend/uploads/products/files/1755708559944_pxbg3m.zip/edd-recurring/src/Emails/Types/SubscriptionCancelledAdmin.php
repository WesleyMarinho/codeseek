<?php

namespace EDD\Recurring\Emails\Types;

defined( 'ABSPATH' ) || exit;

/**
 * Class SubscriptionCancelled
 *
 * @since 2.12.4
 * @package EDD
 * @subpackage Emails
 */
class SubscriptionCancelledAdmin extends SubscriptionCancelled {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $id = 'subscription_cancelled_admin';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 2.12.4
	 */
	protected $recipient_type = 'admin';

	/**
	 * Set the email to address.
	 *
	 * @since 2.12.4
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$this->send_to = edd_get_admin_notice_emails();
	}
}
