<?php

namespace EDD\Recurring\Emails;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * The Recurring Reminders Class
 *
 * @since  2.4
 * @since 2.12.4 Moved from EDD_Recurring_Reminders
 */
class Reminders {
	use Traits\Subscriptions;

	/**
	 * The single instance of the class.
	 *
	 * @since 2.12.4
	 * @var EDD\Recurring\Emails\Reminders
	 */
	private static $instance;

	/**
	 * The class constructor.
	 */
	public function __construct() {
		add_action( 'edd_recurring_daily_scheduled_events', array( $this, 'scheduled_reminders' ) );
	}

	/**
	 * Get the singleton instance of our class.
	 *
	 * @since  2.4
	 * @return Reminders
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new Reminders();
		}

		return self::$instance;
	}

	/**
	 * Returns if renewals are enabled.
	 *
	 * @return array Array of defined reminders.
	 */
	public function reminders_enabled() {
		return true;
	}

	/**
	 * Retrieve reminder notices periods.
	 *
	 * @since 2.4
	 * @return array reminder notice periods
	 */
	public function get_notice_periods() {
		return apply_filters(
			'edd_recurring_get_reminder_notice_periods',
			array(
				'today'    => __( 'The day of the renewal/expiration', 'edd-recurring' ),
				'+1day'    => __( 'One day before renewal/expiration', 'edd-recurring' ),
				'+2days'   => __( 'Two days before renewal/expiration', 'edd-recurring' ),
				'+3days'   => __( 'Three days before renewal/expiration', 'edd-recurring' ),
				'+1week'   => __( 'One week before renewal/expiration', 'edd-recurring' ),
				'+2weeks'  => __( 'Two weeks before renewal/expiration', 'edd-recurring' ),
				'+1month'  => __( 'One month before renewal/expiration', 'edd-recurring' ),
				'+2months' => __( 'Two months before renewal/expiration', 'edd-recurring' ),
				'+3months' => __( 'Three months before renewal/expiration', 'edd-recurring' ),
				'-1day'    => __( 'One day after expiration', 'edd-recurring' ),
				'-2days'   => __( 'Two days after expiration', 'edd-recurring' ),
				'-3days'   => __( 'Three days after expiration', 'edd-recurring' ),
				'-1week'   => __( 'One week after expiration', 'edd-recurring' ),
				'-2weeks'  => __( 'Two weeks after expiration', 'edd-recurring' ),
				'-1month'  => __( 'One month after expiration', 'edd-recurring' ),
				'-2months' => __( 'Two months after expiration', 'edd-recurring' ),
				'-3months' => __( 'Three months after expiration', 'edd-recurring' ),
			)
		);
	}

	/**
	 * Retrieve the reminder label for a notice.
	 *
	 * @since 2.4
	 * @return string
	 */
	public function get_notice_period_label( $notice_id = 0 ) {

		$period = edd_get_email_meta( $notice_id, 'period', true );
		if ( empty( $period ) ) {
			$period = '+1month';
		}
		$periods = $this->get_notice_periods();
		$label   = $periods[ $period ];

		return apply_filters( 'edd_recurring_get_reminder_notice_period_label', $label, $notice_id );
	}

	/**
	 * Retrieve reminder notices types.
	 *
	 * @since 2.4
	 * @return array reminder notice types
	 */
	public function get_notice_types() {
		return apply_filters(
			'edd_recurring_get_reminder_notice_types',
			array(
				'renewal'    => __( 'Renewal', 'edd-recurring' ),
				'expiration' => __( 'Expiration', 'edd-recurring' ),
			)
		);
	}

	/**
	 * Retrieve the reminder type label for a notice.
	 *
	 * @since 2.4
	 * @return String
	 */
	public function get_notice_type_label( $notice_id = 0 ) {

		$type  = edd_get_email_meta( $notice_id, 'type', true );
		$types = $this->get_notice_types();
		$label = $types[ $type ] ?? __( 'Renewal', 'edd-recurring' );

		return apply_filters( 'edd_recurring_get_reminder_notice_type_label', $label, $notice_id );
	}

	/**
	 * Retrieve a reminder notice.
	 *
	 * @since 2.4
	 * @return array Reminder notice details
	 */
	public function get_notice( $notice_id = 0 ) {
		return edd_get_email( $notice_id );
	}

	/**
	 * Retrieve reminder notice periods.
	 *
	 * @since 2.4
	 * @param string $type         The type of reminder to retrieve.
	 * @return array Reminder notices defined in settings
	 */
	public function get_notices( $type = 'all' ) {
		$meta_value = array( 'renewal', 'expiration' );
		if ( 'all' !== $type ) {
			$meta_value = (array) $type;
		}
		$args = array(
			'sender'     => 'recurring',
			'context'    => 'subscription',
			'meta_query' => array(
				array(
					'key'     => 'type',
					'value'   => $meta_value,
					'compare' => 'IN',
				),
			),
			'status'     => 1,
		);

		return edd_get_emails( $args );
	}

	/**
	 * Send reminder emails.
	 *
	 * @since 2.4
	 * @return void
	 */
	public function scheduled_reminders() {

		$notices = $this->get_notices();
		if ( empty( $notices ) ) {
			return;
		}

		edd_debug_log( 'Running EDD_Recurring_Reminders::scheduled_reminders.' );

		foreach ( $notices as $notice ) {
			// This is technically a duplicate check but it's better to be safe than sorry.
			if ( ! $notice->is_enabled() ) {
				continue;
			}

			$send_period = edd_get_email_meta( $notice->id, 'period', true );

			edd_debug_log( 'Processing ' . $notice->email_id . ' reminder template.' );

			$type = edd_get_email_meta( $notice->id, 'type', true );
			if ( empty( $type ) ) {
				$type = 'renewal';
			}
			$subscriptions = $this->get_reminder_subscriptions( $send_period, $type );
			$sub_count     = count( $subscriptions );
			edd_debug_log( 'Found ' . $sub_count . ' subscriptions to send reminders for.' );

			if ( ! $subscriptions ) {
				continue;
			}

			$processed_subscriptions = 0;

			foreach ( $subscriptions as $subscription ) {
				$sent = $this->send( $subscription, $notice, $type );
				if ( $sent ) {
					++$processed_subscriptions;
				}
			}

			edd_debug_log( 'Finished processing ' . $processed_subscriptions . ' for ' . $notice->email_id . ' reminder template.' );
		}

		edd_debug_log( 'Finished EDD_Recurring_Reminders::scheduled_reminders.' );
	}

	/**
	 * Sends a reminder email.
	 *
	 * @since 2.12.4
	 * @param \EDD_Subscription $subscription The subscription object.
	 * @param \EDD\Emails\Email $notice       The email object.
	 * @return bool
	 */
	public function send( $subscription, $notice ) {

		$meta_key  = $this->get_user_meta_key( $subscription, $notice->email_id );
		$sent_time = get_user_meta( $subscription->customer->user_id, $meta_key, true );
		if ( $sent_time ) {
			$send_period = edd_get_email_meta( $notice->id, 'period', true );
			edd_debug_log( 'Skipping renewal reminder for subscription ID ' . $subscription->id . ' and reminder ' . $send_period . '. Previously sent on ' . date_i18n( get_option( 'date_format' ), $sent_time ), true );

			return false;
		}

		$email = \EDD\Emails\Registry::get(
			$notice->email_id,
			array(
				$subscription->id,
				$subscription,
				$notice,
			)
		);
		if ( ! $email ) {
			return false;
		}

		$sent = $email->send();
		if ( $sent ) {
			// Prevents reminder notices from being sent more than once.
			add_user_meta( $subscription->customer->user_id, $meta_key, time() );
		}

		return $sent;
	}

	/**
	 * Filter fields for test email for a reminder.
	 *
	 * @since 2.4
	 * @return string
	 */
	public function filter_test_notice( $text = null ) {
		$text = str_replace( '{name}', 'NAME GOES HERE', $text );
		$text = str_replace( '{subscription_name}', 'SUBSCRIPTION NAME', $text );
		$text = str_replace( '{expiration}', date( 'F j, Y', strtotime( 'today' ) ), $text );
		$text = str_replace( '{subscription_details}', 'SUBSCRIPTION DETAILS', $text );
		$text = str_replace( '{subscription_period}', 'SUBSCRIPTION PERIOD', $text );
		$text = str_replace( '{subscription_id}', 'SUBSCRIPTION ID', $text );

		return $text;
	}

	/**
	 * Retrieve the user meta key for a subscription reminder.
	 *
	 * @since 2.12.4
	 * @param \EDD_Subscription $subscription The subscription object.
	 * @param string            $email_id     The email ID. The prefix will be removed to be backwards compatible.
	 * @return string
	 */
	private function get_user_meta_key( $subscription, $email_id ) {
		$notice_id = str_replace( 'sub_', '', $email_id );

		return sanitize_key( '_edd_recurring_reminder_sent_' . $subscription->id . '_' . $notice_id . '_' . $subscription->get_total_payments() );
	}

	/**
	 * Setup and send test email for a reminder.
	 *
	 * @since 2.4
	 * @deprecated 2.12.4
	 * @return void
	 */
	public function send_test_notice( $notice_id = 0 ) {
		_edd_deprecated_function( __METHOD__, '2.12.4' );
	}
}
