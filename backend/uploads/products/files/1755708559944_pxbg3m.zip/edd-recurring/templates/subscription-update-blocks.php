<?php
/**
 * Block theme template for subscription payment method update page.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$token = sanitize_text_field( get_query_var( 'edd_recurring_update' ) );
$page  = new \EDD\Recurring\Subscriptions\Update\Page();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="wp-site-blocks edd-recurring__update">
	<header class="wp-block-template-part">
		<?php block_template_part( 'header' ); ?>
	</header>
	<main class="wp-block-group edd-recurring__update--page">
		<h1><?php esc_html_e( 'Update Payment Method', 'edd-recurring' ); ?></h1>
		<div class="wp-block-group edd-recurring__update--content">
			<?php $page->render_update_content( $token ); ?>
		</div>
	</main>
</div>

<footer class="wp-block-template-part site-footer">
	<?php block_template_part( 'footer' ); ?>
</footer>

<?php wp_footer(); ?>
</body>
</html>
