<?php
/**
 * Default template for subscription payment method update page.
 *
 * @package EDD\Recurring
 * @since 2.13.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

$token = sanitize_text_field( get_query_var( 'edd_recurring_update' ) );
$page  = new \EDD\Recurring\Subscriptions\Update\Page();
?>

<div class="edd-recurring__update--page">
	<header class="edd-recurring__update--header">
		<h1><?php esc_html_e( 'Update Payment Method', 'edd-recurring' ); ?></h1>
	</header>

	<div class="edd-recurring__update--content">
		<?php $page->render_update_content( $token ); ?>
	</div>
</div>

<?php
get_footer();
